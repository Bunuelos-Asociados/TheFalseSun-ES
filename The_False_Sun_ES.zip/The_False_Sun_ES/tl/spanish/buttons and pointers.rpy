﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/buttons and pointers.rpy:427
    old "{sc=8.0}ВЫХВАТИТЬ НОЖ{/sc}"
    new "{sc=8.0}AGARRA EL CUCHILLO{/sc}"

    # game/buttons and pointers.rpy:473
    old "{sc=8.0}БЕЖАТЬ{/sc}"
    new "{sc=8.0}CORRE{/sc}"

    # game/buttons and pointers.rpy:519
    old "НАПРАВО"
    new "DERECHA"

    # game/buttons and pointers.rpy:544
    old "НАЛЕВО"
    new "IZQUIERDA"

    # game/buttons and pointers.rpy:616
    old "ПОСЕРЕДИНЕ"
    new "CENTRO"

