﻿# TODO: Translation updated at 2026-06-25 20:17

# game/grazing_minigame.rpy:404
translate spanish mgherd_test_start_9ae38815:

    # "grazing_points = [grazing_points]"
    "grazing_points = [grazing_points]"

# game/grazing_minigame.rpy:405
translate spanish mgherd_test_start_9a0002cd:

    # "agi = [agi]"
    "agi = [agi]"

