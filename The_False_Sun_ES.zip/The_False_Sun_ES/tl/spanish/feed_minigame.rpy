﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/feed_minigame.rpy:202
    old "Каждому животному я даю один основной корм и одну прикормку.\nЛошади едят овёс. Я подкармливаю их яблоками.\nПопробуй накормить лошадь."
    new "Le doy a cada animal una ración principal y un premio.\nLos caballos comen avena. Les doy manzanas como premio.\nPrueba a darle de comer al caballo."

    # game/feed_minigame.rpy:202
    old "Овцы любят клевер. Иногда я даю им солевой лизунец.\nТеперь покорми овцу."
    new "A las ovejas les gusta el trébol. A veces les doy un bloque de sal.\nAhora dale de comer a las ovejas."

    # game/feed_minigame.rpy:202
    old "Коровы едят сено. Иногда можно дать им картошку.\nПопробуй накормить корову."
    new "Las vacas comen heno. A veces también puedes darles patatas.\nPrueba a darle de comer a la vaca."

    # game/feed_minigame.rpy:202
    old "Кур я кормлю зерном и иногда добавляю кормовой мел.\nТеперь твоя очередь."
    new "Les doy grano a las gallinas, y a veces añado un poco de polvo de calcio.\nAhora es tu turno."

