﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/memory_gallery.rpy:543
    old "<Сайлас>"
    new "<Silas>"

    # game/memory_gallery.rpy:545
    old "<Я>"
    new "<Yo>"

    # game/memory_gallery.rpy:547
    old "<Другие>"
    new "<Otros>"

