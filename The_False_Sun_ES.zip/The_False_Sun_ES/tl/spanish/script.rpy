﻿# TODO: Translation updated at 2026-06-25 20:17

# game/script.rpy:97
translate spanish start_4b2c2986:

    # b "Выберите ваш пол"
    b "Elige tu género."

# game/script.rpy:111
translate spanish start_46f6c05f:

    # p2 "Холодно...{w} Дышать тяжело..." (cps=50)
    p2 "Hace frío...{w} Cuesta respirar..." (cps=50)

# game/script.rpy:113
translate spanish start_d317dfa9:

    # p2 "Я уже видел[p2_verb_a()] этот сон несколько раз, это скорее не сон, а воспоминания."
    p2 "Ya he tenido este sueño varias veces. Aunque... se siente menos como un sueño y más como un recuerdo."

# game/script.rpy:114
translate spanish start_3d6101d5:

    # p2 "Мои единственные воспоминания с того лета, когда я был[p2_verb_a()] у дедушки."
    p2 "Los únicos recuerdos que tengo de aquel verano que pasé en casa de mi abuelo."

# game/script.rpy:117
translate spanish start_3043d36c:

    # p2 "Я не знаю, что там произошло, знаю только то, что чуть не утонул[p2_verb_a()]. В следующий раз я очнул[p2_verb_as()] уже в больнице. Родители увезли меня домой и больше не отпускали к дедушке."
    p2 "No sé qué pasó entonces. Solo sé que casi me ahogué. Lo siguiente que recuerdo es que desperté en un hospital. Después de eso, mis padres me llevaron a casa y nunca más me dejaron visitar al abuelo."

# game/script.rpy:118
translate spanish start_89cd5b59:

    # p2 "Но теперь я сам[p2_verb_a()] решаю, что мне делать, так что наконец-то могу снова с ним увидеться. После микроинсульта ему нужна помощь по ферме, так что двух зайцев одним выстрелом."
    p2 "Pero ahora yo decido lo que hago. Lo que significa que por fin puedo volver a verlo. Necesita ayuda en la granja después de un leve derrame, así que... mato dos pájaros de un tiro."

# game/script.rpy:122
translate spanish start_97183ab7:

    # k "Проснул[p2_verb_as()], выживш[p2_verb_aya_iy()]?"
    k "¿Despiert[letra], sobreviviente?"

# game/script.rpy:123
translate spanish start_141f1241:

    # p "Ага, нам долго еще ехать?"
    p "Sí. ¿Cuánto falta para llegar?"

# game/script.rpy:124
translate spanish start_dbdc110b:

    # k "Не терпится встретиться с дедом? Или ты уже не можешь выносить мою компанию?"
    k "¿Tienes ganas de ver a tu abuelo? ¿O ya estás hart[letra] de mi compañía?"

# game/script.rpy:125
translate spanish start_f3ce8ddb:

    # p2 "Я тихо посмеял[p2_verb_as()]."
    p2 "Solté una risa suave."

# game/script.rpy:128
translate spanish start_c4ef9848:

    # k "Старик тоже скучает по тебе, он вечно жалуется мне, что ты не приезжаешь, хотя и понимает причину."
    k "El viejo también te extraña. Siempre se queja de que nunca vas a visitarlo, aunque entiende por qué."

# game/script.rpy:131
translate spanish start_bfacb457:

    # k "Ты все так[p2_verb_aya_oy()] же язвительн[p2_verb_aya_iiy()], как в детстве."
    k "Sigues con la lengua tan afilada como de niñ[letra]."

# game/script.rpy:132
translate spanish start_7f053e19:

    # k "Хотя я уже начал забывать тебя, слишком давно ты здесь не появлял[p2_verb_as()]."
    k "Aunque estaba empezando a olvidar cómo eras. Ha pasado demasiado tiempo desde la última vez que viniste."

# game/script.rpy:133
translate spanish start_2a686266:

    # p "Я бы приехал[p2_verb_a()], если бы мог[p2_verb_la()], но родители не пускали после того случая."
    p "Habría venido si pudiera, pero mis padres no me dejaron después de lo que pasó."

# game/script.rpy:134
translate spanish start_a6b1971c:

    # k "Ты всполошил[p2_verb_a()] всю деревню тем летом, слух о том, что чудом выживший ребенок возвращается быстро разлетелся. "
    k "Aquel verano asustaste a todo el pueblo. No tardó en correrse la voz de que [arti] niñ[letra] que había sobrevivido por algún milagro iba a volver."

# game/script.rpy:135
translate spanish start_f97c847a:

    # p "Мне как-то неловко..."
    p "Esto es un poco vergonzoso..."

# game/script.rpy:136
translate spanish start_2cf6cf35:

    # k "Не переживай, все рады, что ты наш[p2_verb_elsya_las()] тогда."
    k "No te preocupes. Todo el mundo se alegra de que te encontraran en aquel entonces."

# game/script.rpy:137
translate spanish start_ea9d9a74:

    # p2 "Наш[p2_verb_elsya_las()]? Меня искали?"
    p2 "¿Encontraran? ¿Me estaban buscando?"

# game/script.rpy:138
translate spanish start_1c6c2214:

    # k "А как ты себя чувствуешь после произошедшего? Были какие-то последствия?"
    k "¿Cómo te sientes después de todo eso, por cierto? ¿Alguna secuela?"

# game/script.rpy:139
translate spanish start_bc68b204:

    # p "Ну... После произошедшего у меня появилась диссоциативная амнезия. Я могу забыть то, что произошло в состоянии стресса."
    p "Bueno... después de lo que pasó, desarrollé amnesia disociativa. Puedo olvidar cosas que suceden mientras estoy bajo estrés."

# game/script.rpy:140
translate spanish start_576f1b5e:

    # p "Однажды я приш[p2_verb_la_el()] на экзамен, а мне сказали, что я еще вчера его сдал[p2_verb_a()]. Я полностью забыл[p2_verb_a()] этот день."
    p "Una vez me presenté a un examen y me dijeron que ya lo había hecho el día anterior. Olvidé por completo ese día entero."

# game/script.rpy:141
translate spanish start_52193eb0:

    # k "Черт... Наверное это очень дезориентирует."
    k "Maldición... Eso debe ser muy desorientador."

# game/script.rpy:142
translate spanish start_5b06de7a:

    # p "Ага..."
    p "Sí..."

# game/script.rpy:144
translate spanish start_6feb0ab9:

    # k "Осталась пара миль и ты встретишься со своим стариком."
    k "Solo un par de millas más, y verás a tu abuelo."

# game/script.rpy:145
translate spanish start_a5e0e734:

    # p2 "Я приободрил[p2_verb_as()], но немного разволновал[p2_verb_as()]."
    p2 "Eso me animó un poco, aunque también me puso nervios[letra]."

# game/script.rpy:146
translate spanish start_5c6e979c:

    # k "Меня ты тоже не помнишь?"
    k "¿Tampoco te acuerdas de mí?"

# game/script.rpy:147
translate spanish start_a4b1cb7f:

    # p "Нет, простите..."
    p "No, lo siento..."

# game/script.rpy:148
translate spanish start_ac21c6dc:

    # k "Не помнишь даже как залез[p2_verb_la()] на дерево и орал[p2_verb_a()] как резанн[p2_verb_aya_iiy()], потому что не мог[p2_verb_la()] спуститься и мне пришлось тебя снимать?"
    k "¿Ni siquiera te acuerdas de cuando te subiste a un árbol y gritabas a todo pulmón porque no podías bajar, y tuve que ir a rescatarte?"

# game/script.rpy:149
translate spanish start_03605e9f:

    # p "Такое правда было!?"
    p "¿¡Eso pasó de verdad!?"

# game/script.rpy:150
translate spanish start_6864ecae:

    # k "Ага, а на следующий день ты снова туда залез[p2_verb_la()], но отдаю тебе должное, спустил[p2_verb_as()] сам[p2_verb_a()]."
    k "Sí. Y al día siguiente te subiste otra vez. Pero hay que reconocerlo, esa vez bajaste por tu cuenta."

# game/script.rpy:151
translate spanish start_b2cf7359:

    # p "Странный скачок уверенности с моей стороны."
    p "Un pequeño y extraño impulso de confianza de mi parte."

# game/script.rpy:152
translate spanish start_c25c9e3d:

    # k "Просто доказательство, что ты можешь все, если захочешь."
    k "Prueba de que puedes hacer cualquier cosa cuando te lo propones."

# game/script.rpy:159
translate spanish start_65f6b1d3:

    # p2 "Мы приехали к дому дедушки, я испытал[p2_verb_a()] странное чувство ностальгии, хотя и не помню, как тут был[p2_verb_a()]."
    p2 "Llegamos a casa del abuelo y sentí una extraña ola de nostalgia, aunque no recuerdo haber estado aquí antes."

# game/script.rpy:163
translate spanish start_b68c2730:

    # p2 "Дедушка крепко обнял меня, когда увидел и сразу усадил для разговора."
    p2 "El abuelo me abrazó fuerte en cuanto me vio, luego me sentó para que pudiéramos hablar."

# game/script.rpy:166
translate spanish start_283c7b67:

    # ded "Я так рад снова тебя увидеть."
    ded "Me alegra mucho verte de nuevo."

# game/script.rpy:167
translate spanish start_8b91cf27:

    # p "Я тоже, мы как будто сто лет не виделись."
    p "A mí también. Parece que no nos vemos en cien años."

# game/script.rpy:169
translate spanish start_ff51461b:

    # ded "Именно. Я даже немного рад микроинсульту, раз благодаря нему ты приехал[p2_verb_a()]."
    ded "Exacto. Casi me alegra de haber tenido ese mini derrame, ya que te trajo aquí."

# game/script.rpy:171
translate spanish start_de60c55d:

    # p "Дедушка! Не говори так! Я бы все равно приехал[p2_verb_a()]!"
    p "¡Abuelo! ¡No digas eso! ¡Habría venido de todos modos!"

# game/script.rpy:173
translate spanish start_549c597f:

    # ded happy "Ну конечно, просто шучу."
    ded happy "Claro, solo bromeo."

# game/script.rpy:174
translate spanish start_ee183b2d:

    # p "Глупые у тебя шутки..."
    p "Tus chistes son malísimos..."

# game/script.rpy:175
translate spanish start_398e259e:

    # p "Кстати, что мне нужно будет делать на ферме? Если у меня были какие-то навыки и знания тем летом, то помни, что я все забыл[p2_verb_a()], так что сейчас я новичок во всем."
    p "Por cierto, ¿qué se supone que debo hacer en la granja? Si tenía alguna habilidad o conocimiento aquel verano, solo recuerda que lo olvidé todo. Así que ahora mismo, soy [arti_2] complet[letra] principiante."

# game/script.rpy:176
translate spanish start_9dd6cfc4:

    # ded calm "Конечно, пойдем покажу."
    ded calm "Claro, vamos a enseñarte."

# game/script.rpy:179
translate spanish start_e6fcc2e3:

    # ded "Для начала, нужно загнать животных в амбар. Они упертые, так что, вероятно, тебе придется тащить их в загоны."
    ded "Primero, tienes que meter a los animales en el granero. Son tercos, así que probablemente tendrás que arrastrarlos a sus corrales."

# game/script.rpy:185
translate spanish start_3058556e:

    # ded "Теперь нужно их покормить."
    ded "Ahora hay que darles de comer."

# game/script.rpy:191
translate spanish start_df156434:

    # ded "В целом это все, но тебе еще нужно будет собирать яйца у куриц по утрам, справишься?"
    ded "Eso es básicamente todo, pero también tendrás que recoger los huevos de las gallinas por las mañanas. ¿Crees que puedes con eso?"

# game/script.rpy:192
translate spanish start_cfd69cb7:

    # p "Конечно, дедушка, я не настолько бесполез[p2_verb_na_en()], как ты думаешь."
    p "Claro que sí, abuelo. No soy tan inútil como crees."

# game/script.rpy:193
translate spanish start_59d02495:

    # ded "Как скажешь. Можешь пойти попытаться наладить контакт с курами, а я пойду прилягу, после приступа быстро утомляюсь."
    ded "Si tú lo dices. Puedes ir a intentar hacerte amig[letra] de las gallinas, y yo iré a acostarme. Me canso rápido después del ataque."

# game/script.rpy:194
translate spanish start_ffc55183:

    # p "Ага, тебе нужно беречь здоровье. "
    p "Sí, tienes que cuidarte."

# game/script.rpy:198
translate spanish start_04f28e2c:

    # p2 "Я направил[p2_verb_as()] к курочкам, они не были настроены агрессивно. Наверное, потому что я их покормил[p2_verb_a()]. "
    p2 "Me dirigí hacia las gallinas. No parecían agresivas. Probablemente porque les había dado de comer."

# game/script.rpy:199
translate spanish start_1e3ffab8:

    # p2 "Тут довольно приятно. Странно, что родители не пускали меня сюда."
    p2 "Es bastante bonito aquí. Extraño que mis padres no me dejaran volver."

# game/script.rpy:201
translate spanish start_33bffcce:

    # p2 "Яиц нет, наверное пойду в дом."
    p2 "No hay huevos. Supongo que volveré adentro."

# game/script.rpy:208
translate spanish start_2ceccaac:

    # b "ТЫ МЕНЯ ПОМНИШЬ!?"
    b "¿¡TE ACUERDAS DE MÍ!?"

# game/script.rpy:213
translate spanish start_e0a44d6e:

    # p "Ты меня напугал!!!"
    p "¡¡¡Me asustaste!!!"

# game/script.rpy:214
translate spanish start_11482249:

    # p "Кто ты вообще!?"
    p "¿¡Quién eres siquiera!?"

# game/script.rpy:217
translate spanish start_a15bc062:

    # b "Так ты... Вообще не помнишь..?"
    b "Así que... ¿de verdad no te acuerdas en absoluto..?"

# game/script.rpy:222
translate spanish start_2e978dc3:

    # p "Нет, я понятия не имею кто ты."
    p "No. No tengo idea de quién eres."

# game/script.rpy:225
translate spanish start_70850c55:

    # s "Я Сайлас! Мы дружили в детстве!"
    s "¡Soy Silas! ¡Éramos amigos cuando éramos niños!"

# game/script.rpy:226
translate spanish start_d0e5544d:

    # p "Прости... Я ничего не помню о том лете, когда был[p2_verb_a()] тут..."
    p "Lo siento... No recuerdo nada de aquel verano que pasé aquí..."

# game/script.rpy:227
translate spanish start_05beb747:

    # s shy "Ооох! Мы провели все лето вместе!!!"
    s shy "¡¡¡Ohhh! ¡¡¡Pasamos el verano entero juntos!!!"

# game/script.rpy:228
translate spanish start_522a0df0:

    # p "Прости, я не помню."
    p "Lo siento, no me acuerdo."

# game/script.rpy:229
translate spanish start_4da22ad0:

    # s "Может тогда станем друзьями заново?"
    s "¿Entonces tal vez podamos volver a ser amigos?"

# game/script.rpy:230
translate spanish start_a24233eb:

    # p2 "Звучит неплохо, к тому же друзья сейчас не помешают. Правда он какой-то бешенный..."
    p2 "Eso no suena nada mal. Además, me vendría bien un amigo ahora mismo. Aunque es un poco intenso..."

# game/script.rpy:231
translate spanish start_fe55f483:

    # p "Хорошо, я..."
    p "Bueno, yo..."

# game/script.rpy:232
translate spanish start_45704f5d:

    # s calm "[p]."
    s calm "[p]."

# game/script.rpy:234
translate spanish start_48368e51:

    # p "О, верно, ты должен помнить, раз мы дружили."
    p "Ah, cierto. Te acuerdas, ya que éramos amigos."

# game/script.rpy:235
translate spanish start_bf1bc2e7:

    # p "Почему ты примчался сюда в такое время? Мог бы прийти завтра."
    p "¿Por qué te apresuraste a venir a esta hora? Podrías haber venido mañana."

# game/script.rpy:236
translate spanish start_3699fcc2:

    # s calm "Я не мог!!! Я так скучал по тебе!"
    s calm "¡¡¡No podía!!! ¡¡¡Te eché muchísimo de menos!!!"

# game/script.rpy:237
translate spanish start_8c88ae89:

    # p "О... Ладно."
    p "Oh... Vale."

# game/script.rpy:238
translate spanish start_a80bdd0e:

    # p "Почему ты такой потный? Ты бежал сюда?"
    p "¿Por qué estás tan sudado? ¿Corriste todo el camino hasta aquí?"

# game/script.rpy:239
translate spanish start_e9362c94:

    # s "Да, не мог дождаться встречи с тобой!!!"
    s "¡¡¡Sí, estaba deseando verte!!!"

# game/script.rpy:240
translate spanish start_d1bdb7cd:

    # p "Может присядем на крыльцо и ты отдышишься?"
    p "¿Qué tal si nos sentamos en el porche para que recuperes el aliento?"

# game/script.rpy:241
translate spanish start_15cdda86:

    # s "Конечно!!!"
    s "¡¡¡Claro!!!"

# game/script.rpy:243
translate spanish start_a7e91d1e:

    # p2 "Мы прошли к домику и сели у крыльца. "
    p2 "Caminamos hacia la casa y nos sentamos en el porche."

# game/script.rpy:246
translate spanish start_61bc3613:

    # p2 "..."
    p2 "..."

# game/script.rpy:247
translate spanish start_4ca1fff2:

    # p2 "Неловко молчать... Нужно что-то сказать..."
    p2 "Este silencio es incómodo... Tengo que decir algo..."

# game/script.rpy:251
translate spanish start_c369cfc3:

    # s "Неа, мы были только вдвоем, проводили вместе время, очень много общались!"
    s "¡No, éramos solo nosotros dos! ¡Pasábamos tiempo juntos y hablábamos mucho!"

# game/script.rpy:252
translate spanish start_08c03f83:

    # s "Я помню, как ты рассказывал[p2_verb_a()], что хочешь стать [p2_verb_letchik()], или то, что ты не любишь груши."
    s "Recuerdo que dijiste que querías ser piloto, y que odiabas las peras."

# game/script.rpy:253
translate spanish start_816712c6:

    # p2 "Он и правда знает кое-что обо мне, похоже мы действительно дружили"
    p2 "De verdad sabe cosas sobre mí. Supongo que de verdad éramos amigos."

# game/script.rpy:255
translate spanish start_9d92d29e:

    # s pears "Кстати!"
    s pears "¡Por cierto!"

# game/script.rpy:256
translate spanish start_073d9756:

    # p "Это мне..?"
    p "¿Eso es para mí..?"

# game/script.rpy:257
translate spanish start_377f19d3:

    # s "Нет, это для твоего дедушки, мама иногда передает ему их, он любит."
    s "No, es para tu abuelo. Mamá le envía algunas a veces. A él le gustan."

# game/script.rpy:258
translate spanish start_9743950c:

    # p "О, спасибо, я передам ему."
    p "Oh, gracias. Se las daré."

# game/script.rpy:259
translate spanish start_9eaa1b38:

    # s happy "Ну ладно, мне пора домой, я обязательно приду завтра, хорошо?"
    s happy "Bueno, tengo que irme a casa, pero volveré mañana, ¿vale?"

# game/script.rpy:260
translate spanish start_b5332679:

    # p "Хорошо, буду ждать."
    p "Vale. Estaré esperando."

# game/script.rpy:262
translate spanish start_be2a216b:

    # p2 "Он обнял меня на прощание, я почувствовал[p2_verb_a()] что-то странное внутри. Возможно это мои органы двигались от того, как сильно он меня сжимал."
    p2 "Me abrazó para despedirse y sentí algo extraño por dentro. Tal vez solo eran mis órganos desplazándose por lo fuerte que me apretaba."

# game/script.rpy:263
translate spanish start_fb05e0c9:

    # s "Я безумно рад видеть тебя."
    s "Estoy locamente feliz de verte."

# game/script.rpy:265
translate spanish start_6ad9ed13:

    # s happy "Пока!"
    s happy "¡Adiós!"

# game/script.rpy:270
translate spanish start_d942b147:

    # p2 "Он ушел, а я отнес[p2_verb_la()] груши на кухню и оставил[p2_verb_a()] их на столе."
    p2 "Se marchó, llevé las peras a la cocina y las dejé sobre la mesa."

# game/script.rpy:273
translate spanish start_b5067d28:

    # p2 "Поездка вымотала меня и я сразу лег[p2_verb_la()] спать. Комната казалась знакомой, хоть я ее и не помню."
    p2 "El viaje me dejó agotad[letra], así que me fui directo a la cama. La habitación me resultaba familiar, aunque no la recordaba."

# game/script.rpy:286
translate spanish start_bc7e0521:

    # dream "Это..."
    dream "Esto es..."

# game/script.rpy:287
translate spanish start_defe76f0:

    # dream "Это место кажется знакомым..."
    dream "Este lugar me resulta familiar..."

# game/script.rpy:288
translate spanish start_43e4fe8e:

    # dream "Что-то указывает мне путь. Я думаю мне нужно идти туда."
    dream "Algo me muestra el camino. Creo que necesito ir allí."

# game/script.rpy:292
translate spanish start_df405dce:

    # dream "Это место тоже ощущается знакомым..."
    dream "Este lugar también me resulta familiar..."

# game/script.rpy:296
translate spanish start_0feae4d6:

    # dream "Куда оно меня ведет?"
    dream "¿A dónde me está llevando?"

# game/script.rpy:307
translate spanish start_eb8f9430:

    # p "Что это было... {w}Похоже на... {w}Короткий путь в деревню! Точно!"
    p "¿Qué fue eso...? {w}Parecía... {w}¡Un atajo hacia el pueblo! ¡Eso es!"

# game/script.rpy:308
translate spanish start_844f2d22:

    # p "Судя по всему, я начинаю медленно восстанавливать память, думаю, нахождение здесь помогает мне."
    p "Parece que mis recuerdos están empezando a regresar poco a poco. Creo que estar aquí está ayudando."

# game/script.rpy:309
translate spanish start_6d821305:

    # p2 "Умывшись и почистив зубы, я отправил[p2_verb_as()] на кухню к дедушке."
    p2 "Después de lavarme y cepillarme los dientes, me dirigí a la cocina a ver al abuelo."

# game/script.rpy:314
translate spanish start_25a0b726:

    # p "Доброе утро."
    p "Buenos días."

# game/script.rpy:315
translate spanish start_965b8d4c:

    # ded "Доброе, как спалось?"
    ded "Buenos días. ¿Dormiste bien?"

# game/script.rpy:318
translate spanish start_8649e028:

    # p "Мне снился сон, я ш[p2_verb_la_el()] по лесу за домом, там нужно было свернуть налево, в сторону раздвоенного дерева, потом в сторону плоского камня, посередине и налево."
    p "Tuve un sueño. Caminaba por el bosque detrás de la casa. Tenía que girar a la izquierda, hacia el árbol partido, luego hacia la roca plana, por el medio, y a la izquierda."

# game/script.rpy:319
translate spanish start_f73d8533:

    # ded "Да, это правда похоже на путь до деревни, но там еще нужно пройти через реку."
    ded "Sí, suena como si fuera el camino hacia el pueblo. Pero aún tienes que cruzar el río."

# game/script.rpy:320
translate spanish start_f76ab699:

    # p "Ой... А реку я не помню."
    p "Oh... No recuerdo el río."

# game/script.rpy:321
translate spanish start_5d1885c8:

    # ded eatrt "Неудивительно, учитывая... Ну... Тот случай..."
    ded eatrt "No es sorprendente, considerando... Bueno... Aquel incidente..."

# game/script.rpy:322
translate spanish start_ffc8cc2b:

    # p "Ага, похоже мозг решил вообще не вспоминать водоемы."
    p "Sí, parece que mi cerebro ha decidido no recordar en absoluto los cuerpos de agua."

# game/script.rpy:324
translate spanish start_3b21bcc4:

    # p "Я давно так хорошо не спал[p2_verb_a()]. Кровать жесткая, но кажется более удобной, чем у меня дома."
    p "No dormía tan bien desde hace años. La cama es dura, pero de alguna forma se siente más cómoda que la mía en casa."

# game/script.rpy:325
translate spanish start_76403121:

    # ded "Это все магия деревни, тут любой почувствует себя лучше."
    ded "Esa es la magia del pueblo. Cualquiera se sentiría mejor aquí."

# game/script.rpy:326
translate spanish start_6cd65d0f:

    # p "Думаю, ты прав, свежий воздух и тишина действительно обладают магическими свойствами."
    p "Creo que tienes razón. El aire fresco y la tranquilidad realmente tienen propiedades mágicas."

# game/script.rpy:327
translate spanish start_d5f981da:

    # p "А как твое здоровье?"
    p "¿Cómo estás de salud?"

# game/script.rpy:328
translate spanish start_52441b31:

    # ded "Чувствую себя хорошо, если не считать, что устаю от каждого действия."
    ded "Me siento bien, excepto de que me canso con el más mínimo movimiento."

# game/script.rpy:329
translate spanish start_1ff47488:

    # p "Тогда отдыхай, а я займусь утренними делами по ферме, ладно?"
    p "Entonces descansa, y yo me encargo de las tareas de la granja esta mañana, ¿vale?"

# game/script.rpy:330
translate spanish start_60426a61:

    # ded eat "Что бы я делал без тебя."
    ded eat "¿Qué haría yo sin ti?"

# game/script.rpy:331
translate spanish start_dbdf30db:

    # p2 "Я улыбнул[p2_verb_as()] и направил[p2_verb_as()] на ферму."
    p2 "Sonreí y me dirigí a la granja."

# game/script.rpy:333
translate spanish start_43945aa1:

    # p "Так... Сначала накормить."
    p "Vale... Lo primero es darles de comer."

# game/script.rpy:337
translate spanish start_ba35f4c9:

    # p "Выпустить животных на пастбище."
    p "Después, dejar salir a los animales al prado."

# game/script.rpy:342
translate spanish start_e75b1dcc:

    # p "Осталось только собрать яйца. Работа на ферме кажется легкой."
    p "Ahora solo queda recoger los huevos. El trabajo en la granja parece fácil."

# game/script.rpy:349
translate spanish start_8da84e8a:

    # p2 "Вот и все. Думаю, я [p2_verb_farm()]. Может, это мое призвание? {w}Работа в офисе кажется слишком скучной и бессмысленной, а тут я хотя бы получаю любовь животных и свежие продукты."
    p2 "Eso es todo. Creo que podría ser granjer[letra] de nacimiento. ¿Tal vez esta es mi vocación? {w}El trabajo de oficina me parece demasiado aburrido e inútil. Al menos aquí tengo el cariño de los animales y comida fresca."

# game/script.rpy:350
translate spanish start_ab6ed723:

    # p2 "Хотя Ной наверняка будет скучать и заставит меня вернуться."
    p2 "Aunque Noah seguro me extrañaría y me obligaría a volver."

# game/script.rpy:351
translate spanish start_60ad615c:

    # p2 "Нужно пойти похвастаться дедушке, думаю, что он будет горд."
    p2 "Debería ir a presumir con el abuelo. Creo que estará orgulloso."

# game/script.rpy:352
translate spanish start_4e7fa07d:

    # p2 "Довольн[p2_verb_aya_iiy()], я направил[p2_verb_as()] в дом, желая поделиться с дедушкой мыслями о жизни на ферме."
    p2 "Satisfech[letra] conmigo mism[letra], entré en la casa ansios[letra] por contarle al abuelo mis impresiones sobre la vida en la granja."

# game/script.rpy:362
translate spanish start_97f57392:

    # p "ДЕДУШКА!!!"
    p "¡¡¡ABUELO!!!"

# game/script.rpy:363
translate spanish start_a3d08efd:

    # p2 "Я проверил[p2_verb_a()] пульс, дед был жив, но без сознания..."
    p2 "Le tomé el pulso. El abuelo estaba vivo, pero inconsciente..."

# game/script.rpy:365
translate spanish start_149ce99f:

    # p2 "Я позвонил[p2_verb_a()] Кайлу, он сразу примчался и отвез нас в больницу."
    p2 "Llamé a Kyle, vino enseguida y nos llevó al hospital."

# game/script.rpy:373
translate spanish start_6c758a85:

    # k "Он в порядке, если можно так сказать..."
    k "Está bien, si es que se le puede llamar así..."

# game/script.rpy:374
translate spanish start_414566de:

    # k "Врачи предполагают, что это отравление какими-то химическими веществами, скорее всего избавлялся от вредителей и надышался чем-то."
    k "Los médicos creen que fue una especie de intoxicación química. Lo más probable es que estuviera eliminando plagas y aspiró algo."

# game/script.rpy:375
translate spanish start_975f370c:

    # p "Он поправится..?"
    p "¿Se recuperará..?"

# game/script.rpy:376
translate spanish start_0bbf7cf2:

    # k supporting "Да, обещаю, он поправится, ему просто нужно время."
    k supporting "Sí, te lo prometo, se pondrá bien, solo necesita tiempo."

# game/script.rpy:377
translate spanish start_c951be05:

    # p "Хорошо..."
    p "Vale..."

# game/script.rpy:378
translate spanish start_95d70634:

    # p2 "У дедушки итак проблемы со здоровьем, нужно было ему умудриться еще и отравиться... Не мог подождать, когда я приеду?"
    p2 "El abuelo ya tiene problemas de salud, y encima logra intoxicarse... ¿No podía haber esperado a que yo llegara?"

# game/script.rpy:379
translate spanish start_af578805:

    # k "Ладно, нам пора возвращаться, не волнуйся, о старике тут хорошо позаботятся."
    k "Muy bien, deberíamos volver. No te preocupes, aquí cuidarán muy bien al viejo."

# game/script.rpy:380
translate spanish start_6689803f:

    # k "И ты молодец, что сразу позвонил[p2_verb_a()] мне. Если что-то случится, всегда звони, ладно?"
    k "E hiciste bien en llamarme de inmediato. Si pasa cualquier cosa, llámame siempre, ¿vale?"

# game/script.rpy:386
translate spanish start_29939d69:

    # p2 "Я кивнул[p2_verb_a()] и мы поехали домой."
    p2 "Asentí y condujimos de vuelta a casa."

# game/script.rpy:391
translate spanish start_0230898d:

    # k "Тебе нужна помощь на ферме?"
    k "¿Necesitas ayuda en la granja?"

# game/script.rpy:392
translate spanish start_41999167:

    # p "Нет спасибо, ты итак очень помог."
    p "No, gracias. Ya has ayudado mucho."

# game/script.rpy:393
translate spanish start_668b6ee8:

    # k "Как скажешь, если что вдруг, обращайся."
    k "Si tú lo dices. Si surge algo, avísame."

# game/script.rpy:394
translate spanish start_33e65796:

    # p "До встречи!"
    p "¡Nos vemos!"

# game/script.rpy:396
translate spanish start_18279790:

    # p2 "Он уехал, а я направил[p2_verb_as()] к ферме."
    p2 "Se fue conduciendo, y me dirigí hacia la granja."

# game/script.rpy:398
translate spanish start_0202e03b:

    # s "Привет!!! Где ты был[p2_verb_a()]? И чего у тебя лицо такое грустное? Умер кто-то?"
    s "¡¡¡Hola!!! ¿Dónde estabas? ¿Y por qué te ves tan triste? ¿Se murió alguien?"

# game/script.rpy:399
translate spanish start_532ee667:

    # p "Дедушка..."
    p "El abuelo..."

# game/script.rpy:404
translate spanish start_2bd68f05:

    # s "Твой дедушка умер!?"
    s "¿¡Murió tu abuelo!?"

# game/script.rpy:405
translate spanish start_263b3f29:

    # p "А..? НЕТ!! СЛАВА БОГУ НЕТ!!"
    p "¿Eh...? ¡¡NO!! ¡¡GRACIAS A DIOS, NO!!"

# game/script.rpy:406
translate spanish start_05869006:

    # p "Он попал в больницу..."
    p "Está en el hospital..."

# game/script.rpy:409
translate spanish start_d3e0e36d:

    # s sorry "Ох... Мне очень жаль..."
    s sorry "Oh... Lo siento mucho..."

# game/script.rpy:410
translate spanish start_3bb341b6:

    # p "Врачи сказали, что все будет хорошо..."
    p "Los médicos dijeron que todo estará bien..."

# game/script.rpy:411
translate spanish start_0ab8c7f4:

    # s "Я уверен, что все будет хорошо, можешь не волноваться, твой дед еще нас всех переживет!"
    s "Estoy seguro de que todo estará bien. No te preocupes, ¡tu abuelo va a vivir mucho más que todos nosotros!"

# game/script.rpy:412
translate spanish start_1524bd44:

    # p2 "Я слегка улыбнул[p2_verb_as()]."
    p2 "Sonreí débilmente."

# game/script.rpy:413
translate spanish start_570d6065:

    # s nya "Тебе нужно отвлечься. Может прогуляемся?"
    s nya "Necesitas distraerte. ¿Qué tal si vamos a pasear?"

# game/script.rpy:414
translate spanish start_0233b9fc:

    # p "Да, покажи мне округу, пожалуйста."
    p "Sí, enséñame el lugar, por favor."

# game/script.rpy:415
translate spanish start_6cb024cf:

    # p2 "Сайлас взял меня за руку и повел по разным местам."
    p2 "Silas me tomó de la mano y me llevó por algunos lugares."

# game/script.rpy:423
translate spanish start_5117a3f8:

    # s "Мы вместе построили этот шалаш, помнишь?"
    s "Construimos este escondite juntos, ¿te acuerdas?"

# game/script.rpy:424
translate spanish start_d3cf414c:

    # p "Нет, но выглядит круто."
    p "No, pero se ve genial."

# game/script.rpy:430
translate spanish start_b75be995:

    # s "А это? Это помнишь?"
    s "¿Y esto? ¿Te acuerdas?"

# game/script.rpy:431
translate spanish start_3d3f5aa9:

    # p "Нет..."
    p "No..."

# game/script.rpy:432
translate spanish start_f4d93d94:

    # s "Мы однажды прятались тут от дождя. "
    s "Una vez nos escondimos de la lluvia aquí."

# game/script.rpy:433
translate spanish start_e924635e:

    # s "Смотри тут осталась даже зола от костра, у которого мы грелись!"
    s "¡Mira, hasta quedan cenizas de la hoguera con la que nos calentamos!"

# game/script.rpy:434
translate spanish start_dbb635f5:

    # p2 "Он так бережно хранит воспоминания о том лете. Даже неловко, что я ничего не помню..."
    p2 "Él atesora con tanto cuidado los recuerdos de aquel verano. Casi me da vergüenza no recordar nada de aquello..."

# game/script.rpy:435
translate spanish start_f0ad156c:

    # s "О! И еще кое-что!"
    s "¡Ah! ¡Y una cosa más!"

# game/script.rpy:444
translate spanish start_08c645c3:

    # s "Мы хотели починить эту лодку и уплыть вместе!"
    s "¡Queríamos arreglar este bote y zarpar juntos!"

# game/script.rpy:445
translate spanish start_89754256:

    # p "И куда мы собирались уплыть?"
    p "¿Y adónde planeábamos navegar?"

# game/script.rpy:446
translate spanish start_46464822:

    # s calm "Да куда угодно! Мы могли бы покорять новые земли!"
    s calm "¡A cualquier sitio! ¡Podríamos conquistar nuevas tierras!"

# game/script.rpy:447
translate spanish start_94afda45:

    # p2 "Я хихикнул[p2_verb_a()]."
    p2 "Solté una risita."

# game/script.rpy:448
translate spanish start_68eafb2a:

    # p "Думаешь еще есть неизведанные земли?"
    p "¿Crees que aún quedan tierras por descubrir?"

# game/script.rpy:449
translate spanish start_f44853ec:

    # s "Конечно! Мы однажды нашли место в лесу, в котором точно никого до нас не было!!"
    s "¡Claro que sí! ¡Una vez encontramos un lugar en el bosque donde seguro que nadie había estado jamás!!"

# game/script.rpy:451
translate spanish start_47421cba:

    # extend "А потом нашли там старую покрышку..."
    extend "Y luego encontramos un neumático viejo allí..."

# game/script.rpy:452
translate spanish start_4168b688:

    # p2 "Я снова посмеял[p2_verb_as()]."
    p2 "Volví a reír."

# game/script.rpy:453
translate spanish start_a534eea1:

    # s calm "Уже вечереет, хочешь проводить солнце? "
    s calm "Se está haciendo tarde, ¿quieres ver la puesta del sol?"

# game/script.rpy:454
translate spanish start_d1e4568a:

    # p "Да, конечно."
    p "Sí, claro."

# game/script.rpy:455
translate spanish start_a5e410b1:

    # s "Пойдем на пристань! Оттуда самый лучший вид!"
    s "¡Vamos al muelle! ¡Tiene la mejor vista!"

# game/script.rpy:456
translate spanish start_1fac48a6:

    # p "Я... Не хочу на пристань..."
    p "Yo... no quiero ir al muelle..."

# game/script.rpy:457
translate spanish start_c94e7a68:

    # s shy "Почему?"
    s shy "¿Por qué?"

# game/script.rpy:458
translate spanish start_1e253539:

    # p "Я боюсь снова оказаться в воде... У меня после того случая появился сильный страх водоемов..."
    p "Me da miedo terminar en el agua otra vez... Después de lo que pasó, desarrollé un miedo terrible al agua..."

# game/script.rpy:459
translate spanish start_2186eb89:

    # s "О... Но я буду рядом, тебе нечего бояться!"
    s "Oh... Pero yo estaré ahí contigo. ¡No tienes que tener miedo!"

# game/script.rpy:466
translate spanish start_13a5a20f:

    # p2 "Страшно... Но он будет рядом, он не даст мне утонуть или даже упасть в воду... {w}Надеюсь..."
    p2 "Tengo miedo... Pero él estará ahí. No dejará que me ahogue, ni siquiera que me caiga... {w}Eso espero..."

# game/script.rpy:467
translate spanish start_11d8dabd:

    # p "Хорошо, пойдем туда, но ты обещаешь, что со мной ничего не случится, да?"
    p "Vale, vamos. Pero me prometes que no me pasará nada, ¿verdad?"

# game/script.rpy:468
translate spanish start_55fdbad8:

    # s calm "Конечно! Клянусь, с тобой ничего плохого не случится!!!"
    s calm "¡Por supuesto! ¡¡¡Te lo juro, no te pasará nada malo!!!"

# game/script.rpy:469
translate spanish start_64bbba9d:

    # s shy "Я могу держать тебя за руку все время, если так ты почувствуешь себя в большей безопасности..."
    s shy "Puedo tomarte de la mano todo el tiempo si eso te hace sentir más segur[letra]..."

# game/script.rpy:471
translate spanish start_a7aafe1f:

    # p "Ладно..."
    p "Vale..."

# game/script.rpy:490
translate spanish marina_a1a2fdbc:

    # p2 "Сайлас отвел меня на пристань, я вцепил[p2_verb_as()] в него, как будто от этого зависела моя жизнь."
    p2 "Silas me llevó al muelle y yo me aferré a él como si mi vida dependiera de ello."    

# game/script.rpy:491
translate spanish marina_c365c344:

    # p "Она точно развалится под нами... "
    p "Definitivamente se va a derrumbar bajo nosotros..."

# game/script.rpy:492
translate spanish marina_687c6357:

    # s "Да ладно тебе, эта пристань стоит тут давно и простоит еще столько же."
    s "Vamos, este muelle lleva aquí toda la vida, y seguirá aquí toda la vida."

# game/script.rpy:497
translate spanish marina_89838998:

    # p2 "Закат отвлек меня от мыслей о пристани."
    p2 "El atardecer me distrajo de pensar en el muelle."

# game/script.rpy:498
translate spanish marina_257d4958:

    # p "Вау... "
    p "Guau..."

# game/script.rpy:499
translate spanish marina_900a2254:

    # s "Ага. Знаешь, я тебе даже завидую, я бы не отказался потерять память, чтобы снова увидеть этот закат как впервые."
    s "Sí. ¿Sabes? Casi te envidio. No me importaría perder la memoria si eso significara ver este atardecer por primera vez de nuevo."

# game/script.rpy:500
translate spanish marina_f0f812f9:

    # p "Я сейчас сам[p2_verb_a()] себе завидую..."
    p "Ahora mismo, yo también me envidio un poco..."

# game/script.rpy:506
translate spanish marina_cde078a3:

    # p2 "Я любовал[p2_verb_as()] закатом солнца, это было красивое зрелище, но похоже мое лицо было красивее, потому что Сайлас смотрел только на меня."
    p2 "Contemplé el atardecer. Era un paisaje precioso, pero al parecer mi rostro era más bonito, porque Silas no me quitaba la vista de encima."

# game/script.rpy:511
translate spanish marina_a7589e8a:

    # p2 "Он внезапно поцеловал меня, краска прилила к лицу, я совсем этого не ожидал[p2_verb_a()]."
    p2 "De repente, me besó y sentí cómo las mejillas se me enrojecían. No me lo esperaba para nada."

# game/script.rpy:512
translate spanish marina_0293d760:

    # p "С-Сайлас..?"
    p "¿S-Silas..?"

# game/script.rpy:516
translate spanish marina_237bdc6f:

    # s "Что?"
    s "¿Qué?"

# game/script.rpy:517
translate spanish marina_efa40143:

    # p "Зачем ты поцеловал меня?"
    p "¿Por qué me besaste?"

# game/script.rpy:518
translate spanish marina_0efa3f1f:

    # s kissshy2 "Я просто очень соскучился."
    s kissshy2 "Es que te echaba muchísimo de menos."

# game/script.rpy:519
translate spanish marina_abce87aa:

    # p "Настолько сильно, что лезешь целоваться? "
    p "¿Tanto como para empezar a besarme así sin más?"

# game/script.rpy:520
translate spanish marina_2e6c59d0:

    # s "Прости, но сложно сдерживаться, когда ты сидишь тут так[p2_verb_aya_oy()] мил[p2_verb_aya_iiy()] в лучах солнца..."
    s "Lo siento, pero es difícil contenerse cuando estás ahí sentad[letra], luciendo tan lind[letra] a la luz del sol..."

# game/script.rpy:521
translate spanish marina_dcf52782:

    # s "И я всего лишь поцеловал тебя в щеку, в этом нет ничего странного, многие люди так выражают привязанность и..."
    s "Y solo te he besado en la mejilla. No hay nada raro en eso. Mucha gente demuestra cariño así, y..."

# game/script.rpy:524
translate spanish marina_59a099f1:

    # p "Ладно, успокойся, все в порядке. "
    p "Vale, cálmate. Está bien."

# game/script.rpy:525
translate spanish marina_3466bcbd:

    # s "Ага... Прости еще раз..."
    s "Sí... Perdona otra vez..."

# game/script.rpy:532
translate spanish marina_0ab16323:

    # s "!!!"
    s "!!!"

# game/script.rpy:535
translate spanish marina_cecd2987:

    # s "Т-ты правда так думаешь!?"
    s "¿¡D-de verdad lo crees!?"

# game/script.rpy:536
translate spanish marina_a6388287:

    # p "Да, это как-то даже по-детски. В хорошем смысле!"
    p "Sí. Es casi infantil, ¡en el buen sentido!"

# game/script.rpy:537
translate spanish marina_1ce98061:

    # s "Тогда я могу сделать это снова..?"
    s "Entonces... ¿puedo volver a hacerlo?"

# game/script.rpy:540
translate spanish marina_0d546a44:

    # p "Ээ... Ну да... Наверное, да..."
    p "Eh... Bueno, sí... Supongo que sí..."

# game/script.rpy:541
translate spanish marina_5398e2bd:

    # s "Тогда я..."
    s "Entonces voy a..."

# game/script.rpy:553
translate spanish marina_646ccbb1:

    # p2 "Щеки начали гореть сильнее, наверное его губы были слишком теплыми... Другой причины быть не может..."
    p2 "Mis mejillas empezaron a arder aún más. Seguramente sus labios estaban demasiado cálidos... No podía haber otra razón..."

# game/script.rpy:559
translate spanish marina_83969b1c:

    # s "Да... Я понимаю, мне стоило спросить..."
    s "Sí... Lo sé. Debería haber preguntado..."

# game/script.rpy:560
translate spanish marina_2ee5dc06:

    # p "Я не злюсь, просто предупреди в следующий раз."
    p "No estoy enfadad[letra]. Solo avísame la próxima vez."

# game/script.rpy:566
translate spanish marina_2a15990d:

    # p2 "Я посмотрел[p2_verb_a()] на реку, тревога нахлынула как вода, которой я так боюсь."
    p2 "Miré el río y la ansiedad me invadió como el agua que tanto me asusta."

# game/script.rpy:574
translate spanish marina_5578f159:

    # p "Слушай... А как я в тот день я оказал[p2_verb_as()] в воде..?"
    p "Oye... ¿Cómo acabé en el agua ese día...?"

# game/script.rpy:602
translate spanish marina_7dcd6804:

    # s "Я не хочу об этом говорить. Меня там не было."
    s "No quiero hablar de eso, yo no estaba allí."

# game/script.rpy:622
translate spanish marina_727f96d8:

    # p2 "Почему он так помрачнел? Может быть он винит себя за то, что его не было рядом и он не смог меня спасти?"
    p2 "¿Por qué se ha puesto tan sombrío? ¿Tal vez se culpa por no estar allí, por no haber podido salvarme?"

# game/script.rpy:626
translate spanish marina_69f589f1:

    # p "Прости..."
    p "Lo siento..."

# game/script.rpy:627
translate spanish marina_828093ec:

    # s marina "Ты меня прости, что не был рядом в тот момент."
    s marina "Soy yo quien debería disculparse por no haber estado allí para ti."

# game/script.rpy:633
translate spanish marina_1a1be043:

    # p "Но.."
    p "Pero..."

# game/script.rpy:635
translate spanish marina_3bde88b5:

    # s angryc "Ты правда хочешь это обсуждать сейчас!? Это единственное, что тебе лучше не вспоминать!!"
    s angryc "¿¡De verdad quieres hablar de eso ahora!? ¡¡Es lo único que deberías haber olvidado!!"

# game/script.rpy:636
translate spanish marina_69f589f1_1:

    # p "Прости..."
    p "Lo siento..."

# game/script.rpy:644
translate spanish marina_d464bf9e:

    # s "Ээ... Не хотел тебя напугать или расстроить... "
    s "Eh... No era mi intención asustarte ni molestarte..."

# game/script.rpy:645
translate spanish marina_e325771d:

    # s "Просто мы оба чувствуем себя не очень хорошо от того случая..."
    s "Es solo que... ese día no trae buenos recuerdos a ninguno de los dos..."

# game/script.rpy:649
translate spanish marina_9802a5bb:

    # p "Этот закат правда очень красивый..."
    p "Este atardecer es realmente precioso..."

# game/script.rpy:650
translate spanish marina_a4fb64f4:

    # s kissshy "Как ты."
    s kissshy "Igual que tú."

# game/script.rpy:651
translate spanish marina_d2b176fb:

    # p2 "Краска резко прилила к моему лицу."
    p2 "Sentí cómo se sonrojaba mi cara de golpe."

# game/script.rpy:652
translate spanish marina_3cc77d4a:

    # p "Что ты... Не говори так!"
    p "¿Qué estás...? ¡No digas cosas así!"

# game/script.rpy:655
translate spanish marina_d8796351:

    # p2 "Не хочу спрашивать об этом... Боюсь разволноваться..."
    p2 "No quiero preguntar sobre eso... Me da miedo que me sienta mal..."

# game/script.rpy:664
translate spanish marina_9a45ee24:

    # s "Мы ловили светлячков в банку."
    s "Atrapábamos luciérnagas en un tarro."

# game/script.rpy:665
translate spanish marina_9871f474:

    # s "Ты называл[p2_verb_a()] их переносными звёздами!"
    s "¡Tú las llamabas estrellas portátiles!"

# game/script.rpy:666
translate spanish marina_6a580d4d:

    # s "А ещё мы часто собирали грибы, ты не любишь их есть, но тебе нравится их собирать, верно?"
    s "Y a menudo recogíamos setas. No te gusta comerlas, pero te gusta recolectarlas, ¿verdad?"

# game/script.rpy:667
translate spanish marina_92fc7e0d:

    # p "Ага. Ты слишком хорошо меня помнишь."
    p "Sí. Me recuerdas demasiado bien."

# game/script.rpy:675
translate spanish marina_321b1a9e:

    # s marinanya "Не волнуйся, он крепкий. Он всегда говорил, что ты у нас тревожн[p2_verb_aya_iiy()], слишком много думаешь."
    s marinanya "No te preocupes, es fuerte. Siempre decía que eras muy ansios[letra], que le dabas demasiadas vueltas a las cosas."

# game/script.rpy:676
translate spanish marina_a1cb6c51:

    # p "Я надеюсь на это..."
    p "Eso espero..."

# game/script.rpy:685
translate spanish marina_13170404:

    # s "Я...{w} Я просто был здесь. {w}Ждал."
    s "Yo...{w} Estaba aquí. {w}Esperando."

# game/script.rpy:687
translate spanish marina_974a219f:

    # extend " Иногда казалось, будто я слышу твой голос, мне снилось, что ты снова приезжаешь."
    extend "A veces me parecía oír tu voz. Soñaba que volverías."

# game/script.rpy:689
translate spanish marina_00699485:

    # extend " Было грустно просыпаться..."
    extend "Era triste despertar..."

# game/script.rpy:695
translate spanish marina_27fd558f:

    # s kissshy "Знаешь, я думал, что уже никогда не увижу тебя."
    s kissshy "¿Sabes? Pensé que nunca más te volvería a ver."

# game/script.rpy:696
translate spanish marina_9184c4ce:

    # p "Я хотел[p2_verb_a()] вернуться, но родители не позволяли, говорили, что дедушке нельзя доверять мою сохранность."
    p "Quería volver, pero mis padres no me dejaron. Decían que el abuelo no podía garantizar mi seguridad."

# game/script.rpy:697
translate spanish marina_31aa147f:

    # s sad "Твой дед правда заботился о тебе, он не мог предвидеть того, что произошло."
    s sad "Tu abuelo te apreciaba mucho, pero no podía prever lo que sucedió."

# game/script.rpy:699
translate spanish marina_cc7ddca7:

    # p "Я знаю... Вообще не виню его, но родители этого не понимают..."
    p "Lo sé... No lo culpo en absoluto, pero mis padres no entienden eso..."

# game/script.rpy:702
translate spanish marina_b6377491:

    # p "Почему ты так на меня смотришь? "
    p "¿Por qué me miras así?"

# game/script.rpy:703
translate spanish marina_7c558ab3:

    # s "Я вспоминаю наш первый поцелуй."
    s "Me estoy acordando de nuestro primer beso."

# game/script.rpy:705
translate spanish marina_bb35acc5:

    # p "ЧТО!?"
    p "¿¡QUÉ!?"

# game/script.rpy:709
translate spanish tree_931569d7:

    # p "Ты не понимаешь! Пристань развалится!"
    p "¡No lo entiendes! ¡El muelle se va a derrumbar!"

# game/script.rpy:710
translate spanish tree_df2a6e0a:

    # s "Ладно, я понял. Не сегодня, да? "
    s "Vale, lo entiendo. Hoy no, ¿verdad?"

# game/script.rpy:711
translate spanish tree_f6f69d94:

    # s calm "Можем пойти в другое место! Оно тоже очень особенное!"
    s calm "¡Podemos ir a otro sitio! ¡También es muy especial!"

# game/script.rpy:712
translate spanish tree_8bcbb6e7:

    # p "Оно не у воды?"
    p "¿No está cerca del agua?"

# game/script.rpy:713
translate spanish tree_16df7786:

    # s shy "Нет, ну... Как бы не так близко, как пристань. Не волнуйся, там тебе ничего не угрожает, особенно вода."
    s shy "No, bueno... No está tan cerca como el muelle. No te preocupes, no corres ningún peligro, especialmente por el agua."

# game/script.rpy:714
translate spanish tree_9056d43b:

    # p "Хорошо, веди меня туда."
    p "Vale, guía el camino."

# game/script.rpy:720
translate spanish tree_71bf280a:

    # p2 "Он провел меня вдоль реки, но на безопасном расстоянии, чтобы мне не было страшно. Вскоре, мы оказались у одинокого дерева..."
    p2 "Me guio a lo largo del río, pero a una distancia prudencial para no asustarme. Pronto, llegamos a un árbol solitario..."

# game/script.rpy:722
translate spanish tree_b9457478:

    # p "Тут что-то вырезано. "
    p "Hay algo tallado aquí."

# game/script.rpy:732
translate spanish tree_a49cbf5a:

    # p "C и С? что это значит?"
    p "¿S y G? ¿Qué significa eso?"

# game/script.rpy:736
translate spanish tree_5f47400b:

    # s "Солнце и Страж. Это наши кодовые имена, ты не помнишь?"
    s "Sol y Guardián. Esos eran nuestros nombres en clave. ¿No te acuerdas?"

# game/script.rpy:737
translate spanish tree_af9b0c5b:

    # p "Оо, понятно. А почему тут сердечко?"
    p "Ohh, ya veo. ¿Y por qué hay un corazón aquí?"

# game/script.rpy:738
translate spanish tree_44ac253d:

    # s kissshy2 "Ну... Это потому что... Мы... Мы были влюблены друг в друга..."
    s kissshy2 "Bueno... Es porque... Nosotros... Estábamos enamorados el uno del otro..."

# game/script.rpy:739
translate spanish tree_61bc3613:

    # p2 "..."
    p2 "..."

# game/script.rpy:744
translate spanish tree_4e2057ac:

    # s sad "Да, но... Первая любовь самая сильная... Так что сложно сказать, что все в прошлом..."
    s sad "Sí, pero... El primer amor es el más fuerte... Así que es difícil decir que todo eso quedó en el pasado..."

# game/script.rpy:749
translate spanish tree_8e0b6e60:

    # s "Наверное я просто романтик..?"
    s "¿Quizás solo soy un romántico..?"

# game/script.rpy:750
translate spanish tree_8e74ac3e:

    # p "Мило конечно, но жизнь редко похожа на романтический фильм."
    p "Eso es muy bonito, pero la vida rara vez funciona como una película romántica."

# game/script.rpy:751
translate spanish tree_edde0b6b:

    # s "Ты прав[p2_verb_a()], но всегда хочется верить в красивую картинку."
    s "Tienes razón, pero siempre buscas ver el lado bonito de las cosas."

# game/script.rpy:752
translate spanish tree_f594fbf3:

    # s sly "Я помню одну очень красивую картинку..."
    s sly "Yo guardo el recuerdo de algo muy hermoso..."

# game/script.rpy:753
translate spanish tree_9143743f:

    # p "Да? И что это?"
    p "¿Ah, sí? ¿Y cuál es?"

# game/script.rpy:756
translate spanish tree_c6e28713:

    # s kissshy "Я просто надеюсь, что ты вспомнишь. То, что было между нами сложно забыть, даже если тебе отшибло память."
    s kissshy "Solo espero que lo recuerdes. Lo que pasó entre nosotros es difícil de olvidar, aunque hayas perdido la memoria."

# game/script.rpy:757
translate spanish tree_a944ca9e:

    # p "Я бы точно не отказал[p2_verb_as()] все вспомнить, понимаешь, картинка в голове плохо складывается."
    p "Desde luego, no diría que no a recordar todo. ¿Sabes? La imagen que tengo en la cabeza no acaba de encajar."

# game/script.rpy:758
translate spanish tree_924245e4:

    # s ask "Какая картинка..?"
    s ask "¿Qué imagen?"

# game/script.rpy:759
translate spanish tree_c324786e:

    # p "Тот случай, когда я чуть не утонул[p2_verb_a()]. Ощущение, что все скрывают от меня что-то, что-то недоговаривают."
    p "Aquel día, cuando casi me ahogo. Tengo la sensación de que todos me están ocultando algo. Como si se les olvidara mencionar algo."

# game/script.rpy:760
translate spanish tree_79439a6a:

    # s "Зачем кому-то врать об этом?"
    s "¿Por qué iba alguien a mentir sobre eso?"

# game/script.rpy:761
translate spanish tree_d88b3ed4:

    # p "Не думаю, что кто-то делает это из собственной выгоды, возможно не хотят, чтобы я снова \"проживал[p2_verb_a()] травму\"."
    p "No creo que nadie lo haga por interés propio. Quizás solo no quieren que \"reviva el trauma\"."

# game/script.rpy:762
translate spanish tree_8fae4c4f:

    # s kissshy "Разве что это, но знай, я от тебя ничего не скрываю. Я хочу, чтобы ты вспомнил[p2_verb_a()] все правильно."
    s kissshy "Más o menos eso, pero quiero que sepas que no te oculto nada. Quiero que lo recuerdes todo correctamente."

# game/script.rpy:763
translate spanish tree_f6380a92:

    # p "А разве я могу вспомнить все неправильно?"
    p "¿Es posible que lo recuerde todo mal?"

# game/script.rpy:771
translate spanish tree_e37f1f66:

    # s "Н-ну... Мозг сложная штука... Вымысел может смешаться с реальными воспоминаниями..."
    s "B-bueno... El cerebro es complicado... La ficción puede mezclarse con los recuerdos reales..."

# game/script.rpy:772
translate spanish tree_6c5ad7df:

    # p "Наверное ты прав, но я не знаю, как избежать ложных воспоминаний."
    p "Quizás tengas razón, pero no sé cómo evitar los falsos recuerdos."

# game/script.rpy:773
translate spanish tree_861bed81:

    # s "Я буду тебе помогать! Я все то лето был рядом и очень хорошо все помню, так что могу сказать тебе, что действительно было, а что нет!"
    s "¡Yo te ayudaré! Estuve contigo todo aquel verano y lo recuerdo todo muy bien, así que puedo decirte qué pasó de verdad y qué no!"

# game/script.rpy:774
translate spanish tree_c11891c6:

    # s "Ты конечно не обязан[p2_verb_a()] верить, но... Я просто хочу помочь..."
    s "No tienes que creerme, por supuesto, pero... solo quiero ayudar..."

# game/script.rpy:775
translate spanish tree_63b4069c:

    # s "Знаешь, с чего я начну? Это очень важное воспоминание!"
    s "¿Sabes por dónde voy a empezar? ¡Este es un recuerdo muy importante!"

# game/script.rpy:776
translate spanish tree_e5a30ec8:

    # p "И что это?"
    p "¿Y cuál es?"

# game/script.rpy:785
translate spanish tree_91ef13a2:

    # s "Ты правда так думаешь??"
    s "¿¿De verdad lo crees??"

# game/script.rpy:786
translate spanish tree_60a3deb5:

    # p "Ага, детская любовь милая. Жаль, что я ничего не помню, а ведь скорее всего это была моя первая влюбленность, потому что первое, что я помню, было уже после того лета. "
    p "Sí, los amores de la infancia son tiernos. Es una lástima que no recuerde nada de eso. Probablemente fue mi primer amor, dado que mis recuerdos comienzan justo después de ese verano."

# game/script.rpy:787
translate spanish tree_0215af00:

    # s "Да! Так и было! Ты говорил[p2_verb_a()], что я первый, кто вызывает в тебе такие чувства! "
    s "¡Sí! ¡Exacto! ¡Me dijiste que yo era la primera persona que te hacía sentir así!"

# game/script.rpy:788
translate spanish tree_59f343dd:

    # p "Ого, похоже я действительно был[p2_verb_a()] по уши в тебя влюблен[p2_verb_a()]. "
    p "Vaya. Parece que de verdad estaba perdidamente enamorad[letra] de ti."

# game/script.rpy:789
translate spanish tree_175c5973:

    # s "Именно так! "
    s "¡Exacto!"

# game/script.rpy:790
translate spanish tree_d7866575:

    # s "Я понимаю, что ты ничего не помнишь, но я помню все... Я помню тебя..."
    s "Sé que no recuerdas nada, pero yo lo recuerdo todo... Te recuerdo a ti..."

# game/script.rpy:791
translate spanish tree_c7cb4c00:

    # s "Ты вырос[p2_verb_la()], но остаешься человеком, которого я полюбил."
    s "Has crecido, pero sigues siendo la persona de la que me enamoré."

# game/script.rpy:792
translate spanish tree_1bf49b28:

    # p2 "Это звучит так трогательно, видно, что он не лжет..."
    p2 "Eso suena muy conmovedor. Se nota que no miente..."

# game/script.rpy:793
translate spanish tree_ac867f4a:

    # s "А... У тебя сейчас кто-то есть..?"
    s "Eh... ¿Estás saliendo con alguien ahora mismo..?"

# game/script.rpy:794
translate spanish tree_e35e9c93:

    # p2 "Его вопрос немного выбил меня из колеи."
    p2 "Su pregunta me descolocó un poco."

# game/script.rpy:795
translate spanish tree_85f71583:

    # p "Партнер? Нет."
    p "¿Una pareja? No."

# game/script.rpy:796
translate spanish tree_7db04786:

    # s shyya "А вообще кто-нибудь был?"
    s shyya "¿Has tenido alguna vez pareja?"

# game/script.rpy:801
translate spanish tree_213578bb:

    # p "У меня были отношения, но продлились недолго..."
    p "He estado en algunas relaciones, pero no duraron mucho..."

# game/script.rpy:803
translate spanish tree_011942ee:

    # s ask "Насколько вы были близки?"
    s ask "¿Qué tan cercanos eran?"

# game/script.rpy:804
translate spanish tree_4befca47:

    # p "Что ты имеешь ввиду?"
    p "¿Qué quieres decir?"

# game/script.rpy:805
translate spanish tree_a2f5b8e0:

    # s "Ну... У вас были... Поцелуи..? И... Ну... То самое..?"
    s "Bueno... ¿Has... besado? Y... bueno... ¿esas cosas...?"

# game/script.rpy:809
translate spanish tree_ce865a4e:

    # p2 "Не знаю почему, но мне хочется говорить ему правду."
    p2 "No sé por qué, pero quiero decirle la verdad."

# game/script.rpy:810
translate spanish tree_05f96452:

    # p "Нет, ничего не было."
    p "No, no pasó nada."

# game/script.rpy:812
translate spanish tree_1b999c94:

    # s sly "А у нас с тобой было."
    s sly "Y nosotros tuvimos algo."

# game/script.rpy:813
translate spanish tree_b127474f:

    # p "Ч-Что..?"
    p "¿Q-qué..?"

# game/script.rpy:814
translate spanish tree_158713b6:

    # p2 "Он сказал это так легко, как будто нет ничего странного в двенадцатилетках, занимающихся... Таким..."
    p2 "Lo dijo con tanta naturalidad, como si no hubiera nada extraño en que unos niños de doce años hicieran... Eso..."

# game/script.rpy:820
translate spanish tree_33df50b9:

    # p "Ээ... Да... Было... Всё было..."
    p "Eh... Sí... Pasaron... Pasaron cosas..."

# game/script.rpy:821
translate spanish tree_fffca572:

    # p "Но в этом ведь нет ничего плохого!"
    p "¡Pero no hay nada de malo en eso!"

# game/script.rpy:822
translate spanish tree_624403e8:

    # s sad2 "Я знаю..."
    s sad2 "Lo sé..."

# game/script.rpy:823
translate spanish tree_d4b9465c:

    # s "Но я ревную..."
    s "Pero estoy celoso..."

# game/script.rpy:824
translate spanish tree_69ea2fce:

    # p "Но это в прошлом, сейчас у меня никого нет, нет смысла в ревности!"
    p "Pero eso ya pasó, ahora estoy solter[letra], así que no hay motivo para estar celoso."

# game/script.rpy:825
translate spanish tree_01966855:

    # s angryc "Мне неприятно думать, что кто-то до меня тебя касался, кто-то делал то, что я должен был делать..."
    s angryc "No soporto la idea de que alguien te haya tocado antes que yo, de que haya hecho lo que me correspondía a mí..."

# game/script.rpy:826
translate spanish tree_bbc0db22:

    # s sly "Хотя я могу гордиться свои достижением."
    s sly "Aunque puedo estar orgulloso de mi logro."

# game/script.rpy:827
translate spanish tree_fe34e721:

    # p "Каким достижением?"
    p "¿Qué logro?"

# game/script.rpy:830
translate spanish tree_eb10dab8:

    # s "Я рад, что после меня у тебя никого не было."
    s "Me alegra que no hayas tenido a nadie después de mí."

# game/script.rpy:831
translate spanish tree_88a0ce75:

    # p "А между нами действительно было что-то..?"
    p "¿De verdad hubo algo entre nosotros?"

# game/script.rpy:834
translate spanish tree_48cb1d05:

    # s kissshy "Ага... Я никогда не забывал о своих чувствах к тебе..."
    s kissshy "Sí... Nunca he olvidado mis sentimientos por ti..."

# game/script.rpy:835
translate spanish tree_188bffde:

    # s "А ты..?"
    s "¿Y tú..?"

# game/script.rpy:839
translate spanish tree_c8a5200b:

    # s "Я так рад..."
    s "Me alegra mucho..."

# game/script.rpy:840
translate spanish tree_192c1550:

    # s "Я сделаю все, чтобы ты снова влюбил[p2_verb_as()] в меня!"
    s "¡Haré cualquier cosa para que te vuelvas a enamorar de mí!"

# game/script.rpy:841
translate spanish tree_a261374c:

    # p2 "Я слегка покраснел[p2_verb_a()], конечно, я ничего не помню, но чувствую что-то похожее на бабочек в животе..."
    p2 "Me sonrojé un poco. Por supuesto, no recuerdo nada, pero siento mariposas en el estómago..."

# game/script.rpy:842
translate spanish tree_ce235776:

    # s "Ты когда-нибудь хочешь повторить то, что было между нами под этим деревом...?"
    s "¿Alguna vez quieres repetir lo que pasó entre nosotros bajo ese árbol..?"

# game/script.rpy:843
translate spanish tree_26e19a4b:

    # p "А что тут было?"
    p "¿Qué pasó aquí?"

# game/script.rpy:844
translate spanish tree_c684e53e:

    # s "Наш первый поцелуй."
    s "Nuestro primer beso."

# game/script.rpy:845
translate spanish tree_e7e0838e:

    # p2 "ЧТО!?"
    p2 "¡¿QUÉ!?"

# game/script.rpy:849
translate spanish tree_dcbae537:

    # s sad "Я уверен, что ты вспомнишь однажды... Ты можешь полностью забыть что угодно, кроме чувств..."
    s sad "Estoy seguro de que algún día lo recordarás... Puedes olvidar cualquier cosa, menos tus sentimientos..."

# game/script.rpy:850
translate spanish tree_725acf28:

    # s "Чувства всегда возвращаются... "
    s "Los sentimientos siempre vuelven..."

# game/script.rpy:851
translate spanish tree_1cbfaa5c:

    # s "Тебе просто нужно вспомнить кое-что."
    s "Solo necesitas recordar una cosa."

# game/script.rpy:852
translate spanish tree_c9f6d919:

    # p "Что например?"
    p "¿Como qué?"

# game/script.rpy:856
translate spanish kissnya_63d7cadd:

    # s sly "Твой первый поцелуй был со мной."
    s sly "Tu primer beso fue conmigo."

# game/script.rpy:858
translate spanish kissnya_bb35acc5:

    # p "ЧТО!?"
    p "¡¿QUÉ!?"

# game/script.rpy:859
translate spanish kissnya_2dbd988b:

    # p "Ты сейчас не шутишь..?"
    p "¿Hablas en serio ahora mismo?"

# game/script.rpy:860
translate spanish kissnya_858fb030:

    # s kissshy "Не шучу. Это был прекрасный день, мы долго плавали в реке, а потом грелись у костра, говорили о наших чувствах и поцеловались."
    s kissshy "Hablo en serio. Fue un día precioso, pasamos un buen rato nadando en el río, y luego nos calentamos junto al fuego, hablamos de nuestros sentimientos y nos besamos."

# game/script.rpy:861
translate spanish kissnya_2c00a853:

    # p2 "Даже не знаю, что ему ответить…"
    p2 "Ni siquiera sé qué decirle..."

# game/script.rpy:867
translate spanish kissnya_ad3e2b68:

    # s chu "Да нет же! Именно так все и было..."
    s chu "¡No! Fue exactamente así..."

# game/script.rpy:868
translate spanish kissnya_d9878751:

    # p2 "Не особо верится ему, думаю он многое преувеличивает."
    p2 "La verdad no le creo, creo que está exagerando mucho."

# game/script.rpy:869
translate spanish kissnya_7178f091:

    # p "Ладно, ладно, как скажешь."
    p "Vale, vale, lo que tú digas."

# game/script.rpy:870
translate spanish kissnya_120fb4c2:

    # s "Ты мне не веришь. Почему!? Это не так странно, чтобы не верить!"
    s "No me crees. ¿¡Por qué!? ¡No es para tanto!"

# game/script.rpy:871
translate spanish kissnya_d12cd5a0:

    # p "Ну понимаешь… В двенадцать лет меня интересовали покемоны, а не романтика."
    p "Bueno, ya sabes... Cuando tenía doce años, me gustaba Pokémon, no el romance."

# game/script.rpy:872
translate spanish kissnya_de8f9baf:

    # s chuang "Да всех в двенадцать лет интересуют покемоны!!! Но это не значит, что ребенок не может чувствовать влюбленность и желание романтики!!!"
    s chuang "¡¡¡A todos les gusta Pokémon a los doce años!!! ¡¡¡Eso no significa que un niño no pueda gustarle alguien o querer algo romántico!!!"

# game/script.rpy:873
translate spanish kissnya_cdb733e1:

    # p2 "Его голос становился громче и выше с каждой фразой, это начало меня напрягать…"
    p2 "Su voz se volvía más fuerte y aguda con cada frase. Empezaba a ponerme nervios[letra]..."

# game/script.rpy:874
translate spanish kissnya_e088b4ae:

    # p "Мне просто сложно в это верится."
    p "Simplemente me cuesta creerlo."

# game/script.rpy:875
translate spanish kissnya_38d3c630:

    # s "Я бы не стал тебя обманывать! Зачем мне это!?"
    s "¡No te mentiría! ¿¡Para qué lo haría!?"

# game/script.rpy:876
translate spanish kissnya_941a8aa6:

    # p "Не знаю, может ты просто видел это иначе, чем я."
    p "No lo sé. Quizás tú lo viste de forma distinta a como lo vi yo."

# game/script.rpy:877
translate spanish kissnya_533336fa:

    # s "Может быть! Но поцелуй был! Я клянусь! "
    s "¡Puede ser! ¡Pero el beso ocurrió! ¡Lo juro!"

# game/script.rpy:883
translate spanish kissnya_207ec20c:

    # p "Мамой клянешься? "
    p "¿Júralo por tu madre?"

# game/script.rpy:888
translate spanish kissnya_81adee56:

    # s "Чт… Мамой..?"
    s "¿Q-qué...? ¿Mi madre..?"

# game/script.rpy:889
translate spanish kissnya_ffc6b05d:

    # p2 "Он посмотрел так растеряно, я подумал[p2_verb_a()], что не уверен[p2_verb_a()], есть ли у него мама…"
    p2 "Parecía tan confundido que, por un segundo, ni siquiera estuve segur[letra] de que tuviera madre..."

# game/script.rpy:890
translate spanish kissnya_3b1701b6:

    # p "Ээ… Ну я имею ввиду…"
    p "Eh... O sea..."

# game/script.rpy:891
translate spanish kissnya_74bebea1:

    # s chuang "Да, я клянусь своей мамой, что не обманываю тебя и поцелуй был. "
    s chuang "Sí, lo juro por mi madre que no te miento, y que ese beso ocurrió de verdad."

# game/script.rpy:894
translate spanish kissnya_29f356f5:

    # p2 "Похоже его это расстроило… Черт… Я же пытал[p2_verb_as()] разрядить обстановку…"
    p2 "Parece que eso le ha disgustado... Maldición... Solo intentaba aligerar el ambiente..."

# game/script.rpy:895
translate spanish kissnya_d54a9b2c:

    # p2 "Пока солнце не село окончательно, мы сидели там, но он был слишком тихим…"
    p2 "Nos quedamos sentados allí hasta que casi se fue el sol, pero él estaba demasiado callado..."

# game/script.rpy:898
translate spanish kissnya_8c64fdd1:

    # s "Мы можем повторить."
    s "Podríamos repetirlo."

# game/script.rpy:899
translate spanish kissnya_0a789b76:

    # p2 "Я резко смутил[p2_verb_as()], словно не ожидал[p2_verb_a()] этого, хотя он всем видом показывал, что ждет момента, чтобы предложить это."
    p2 "Me sonrojé de golpe, como si no lo hubiera visto venir, aunque todo en él decía que había estado esperando el momento justo para sugerirlo."

# game/script.rpy:900
translate spanish kissnya_f8c14bce:

    # p "Ну... Вряд ли мы сможем повторить... Я теперь боюсь водоемов и все такое, так что плавать целый день не выйдет, ха-ха..."
    p "Bueno... No creo que podamos repetirlo tal cual... Ahora le tengo miedo a los cuerpos de agua y todo eso, así que nadar todo el día está un poco fuera de lugar, jaja..."

# game/script.rpy:901
translate spanish kissnya_98ad17c4:

    # s "Ты прав[p2_verb_a()], нужно будет придумать другую романтическую ситуацию."
    s "Tienes razón. Tendremos que idear una situación romántica distinta."

# game/script.rpy:902
translate spanish kissnya_76a469c7:

    # p "Ага… Нужно будет другую романтическую ситуацию…"
    p "Sí... Una situación romántica distinta..."

# game/script.rpy:903
translate spanish kissnya_bc7c8e84:

    # p2 "Я так засмущал[p2_verb_as()], что не понял[p2_verb_a()], как буквально согласил[p2_verb_as()] поцеловаться…"
    p2 "Me avergoncé tanto que ni siquiera me di cuenta de que básicamente había aceptado besarlo..."

# game/script.rpy:904
translate spanish kissnya_9e033e29:

    # p2 "Уже темнело, нужно было возвращаться домой."
    p2 "Ya estaba oscureciendo. Teníamos que volver a casa."

# game/script.rpy:912
translate spanish kissnya_1ac0b468:

    # p2 "Мы направились к дому дедушки, Сайлас молчал, он выглядел так, словно его голова полна мыслей."
    p2 "Nos dirigimos hacia casa del abuelo. Silas estaba callado, como si tuviera la cabeza llena de pensamientos."

# game/script.rpy:913
translate spanish kissnya_6b58522d:

    # p "Все в порядке?"
    p "¿Está todo bien?"

# game/script.rpy:914
translate spanish kissnya_ffb35a29:

    # s "Ага…"
    s "Sí..."

# game/script.rpy:920
translate spanish kissnya_c2bd4d58:

    # p2 "Я взял[p2_verb_a()] его за руку, она была такой теплой."
    p2 "Le tomé la mano. Estaba muy cálida."

# game/script.rpy:921
translate spanish kissnya_2de7301a:

    # p2 "Было видно, как он рад. Он словно не пытался скрыть этого, его лицо светилось улыбкой. На сердце стало теплее, как будто его пронзил теплый луч солнца."
    p2 "Era evidente lo feliz que estaba. Ni siquiera intentaba ocultarlo. Toda su cara se iluminó con una sonrisa. Mi corazón se sintió más cálido, como si un rayo de sol lo hubiera atravesado."

# game/script.rpy:930
translate spanish kissnya_c0cf086e:

    # p2 "Мы направились к дому дедушки, Сайлас не отпускал мою руку, Я не был[p2_verb_a()] против."
    p2 "Nos dirigimos hacia casa del abuelo. Silas no me soltó la mano, y no me importó."

# game/script.rpy:931
translate spanish kissnya_8f1d56e5:

    # s "Мы всегда ходили за руку тем летом."
    s "Solíamos tomarnos de la mano todo el tiempo aquel verano."

# game/script.rpy:932
translate spanish kissnya_b7ad8341:

    # p "Правда? Даже когда только познакомились?"
    p "¿En serio? ¿Incluso cuando acabábamos de conocernos?"

# game/script.rpy:933
translate spanish kissnya_3e7dd044:

    # s "Ага, я постоянно вспоминал тепло твоих рук."
    s "Sí. No dejaba de recordar lo cálidas que eran tus manos."

# game/script.rpy:934
translate spanish kissnya_f435a2f5:

    # p "Ты безнадежный романтик."
    p "Eres un romántico empedernido."

# game/script.rpy:935
translate spanish kissnya_20b1dff6:

    # s "Не отрицаю."
    s "No lo niego."

# game/script.rpy:942
translate spanish kissnya_e406819c:

    # p2 "Сайлас шел, засунув руки в карманы, мы почти ничего не сказали друг другу."
    p2 "Silas caminaba con las manos metidas en los bolsillos. Apenas nos dijimos nada."

# game/script.rpy:943
translate spanish kissnya_fbfb51cc:

    # p2 "Было неловко, но я не знал[p2_verb_a()], как завязать хоть какой-то разговор."
    p2 "Era incómodo, pero no tenía ni idea de cómo iniciar cualquier tipo de conversación."

# game/script.rpy:948
translate spanish kissnya_e88b0d62:

    # p2 "Мы пришли на ферму, было довольно темно, нужно было заняться животными."
    p2 "Volvimos a la granja. Ya estaba bastante oscuro, y los animales todavía necesitaban cuidados."

# game/script.rpy:950
translate spanish kissnya_98ed0101:

    # p "Мне нужно загнать животных в амбар, накормить их и собрать яйца."
    p "Tengo que meter a los animales en el granero, darles de comer y recoger los huevos."

# game/script.rpy:951
translate spanish kissnya_75d74eb5:

    # s "Я могу помочь!"
    s "¡Puedo ayudar!"

# game/script.rpy:952
translate spanish kissnya_1b49f72e:

    # p "Ты уверен? Не хочу напрягать тебя."
    p "¿Estás seguro? No quiero ponerte a trabajar."

# game/script.rpy:953
translate spanish kissnya_41798d1e:

    # s fcl "Я хочу тебе помочь! Могу вообще все за тебя сделать!"
    s fcl "¡Quiero ayudarte! ¡Podría incluso hacerlo todo por ti!"

# game/script.rpy:959
translate spanish kissnya_bd30620b:

    # "Нужно выбрать, что он мог бы сделать..."
    "Tengo que decidir qué podría hacer él..."

# game/script.rpy:971
translate spanish kissnya_9c96a1f7:

    # p "Тогда ты можешь загнать животных."
    p "Entonces puedes meter a los animales."

# game/script.rpy:973
translate spanish kissnya_9b6d73db:

    # p "Еще можешь загнать животных."
    p "También puedes meter a los animales."

# game/script.rpy:979
translate spanish kissnya_6727991f:

    # p "Тогда ты мог бы собрать яйца."
    p "Entonces podrías recoger los huevos."

# game/script.rpy:981
translate spanish kissnya_329e33b2:

    # p "И собрать яйца."
    p "Y recoger los huevos."

# game/script.rpy:988
translate spanish kissnya_abcd65fc:

    # p "Тогда ты можешь накормить скот."
    p "Entonces puedes dar de comer a los animales."

# game/script.rpy:990
translate spanish kissnya_61915dd4:

    # p "И покормить скот."
    p "Y dar de comer a los animales."

# game/script.rpy:999
translate spanish kissnya_2895e819:

    # s "Ого, решил[p2_verb_a()] все дела на меня перекинуть?"
    s "Vaya, ¿me estás dejando todas las tareas a mí?"

# game/script.rpy:1000
translate spanish kissnya_1a2203f0:

    # s "Я совсем не против! Мне в радость помогать тебе!"
    s "¡No es que me importe! ¡Ayudarte me hace feliz!"

# game/script.rpy:1001
translate spanish kissnya_7535b97b:

    # p "Спасибо..."
    p "Gracias..."

# game/script.rpy:1003
translate spanish kissnya_ab50aeaa:

    # p "На этом думаю все. Не против сделать это?"
    p "Creo que eso es todo. ¿No te importa hacerlo?"

# game/script.rpy:1004
translate spanish kissnya_a0ffacf4:

    # s "Конечно! Я всегда рад тебе помочь, к тому же ты остал[p2_verb_as()] тут совсем од[p2_verb_na_in()], неопытн[p2_verb_aya_iiy()] и беззащитн[p2_verb_aya_iiy()]."
    s "¡Por supuesto! Siempre estoy encantado de ayudarte. Además, estás sol[letra] aquí, sin experiencia e indefens[letra]."

# game/script.rpy:1005
translate spanish kissnya_b1360769:

    # p "Спасибо!"
    p "¡Gracias!"

# game/script.rpy:1007
translate spanish kissnya_2647a478:

    # p "Думаю, я все сделаю сам[p2_verb_a()]."
    p "Creo que lo haré todo yo mism[letra]."

# game/script.rpy:1008
translate spanish kissnya_c0288793:

    # s fsad "Но почему?? Я же хочу помочь!"
    s fsad "¿¿Pero por qué?? ¡Quiero ayudar!"

# game/script.rpy:1009
translate spanish kissnya_f269c92c:

    # p "Мне само[p2_verb_y_mu()] хочется сделать это."
    p "Simplemente me apetece hacerlo yo mism[letra]."

# game/script.rpy:1010
translate spanish kissnya_c5e1cc72:

    # s "Ну ладно..."
    s "Bueno, vale..."

# game/script.rpy:1014
translate spanish kissnya_9355c1d4:

    # p2 "Сайлас пошел заниматься делами, а я наблюдал[p2_verb_a()] за ним. Было немного неловко, что он работает за меня, но он сам предложил и выглядит счастливым."
    p2 "Silas se fue a hacer las tareas y lo observé. Me sentía un poco incómod[letra] teniendo a alguien trabajando para mí, pero él se ofreció y se veía feliz."

# game/script.rpy:1019
translate spanish kissnya_02b1a7d1:

    # p2 "Я пош[p2_verb_la_el()] загонять животных."
    p2 "Fui a meter a los animales."

# game/script.rpy:1029
translate spanish kissnya_49145647:

    # p2 "Мне нравится смотреть, как животные радуются, когда я их кормлю."
    p2 "Me gusta ver cómo se emocionan los animales cuando les doy de comer."

# game/script.rpy:1033
translate spanish kissnya_ab1a41fd:

    # p2 "Собирать яйца довольно интересно, иногда курицы откладывают их в неочевидных местах."
    p2 "Recoger huevos es bastante interesante. A veces las gallinas los ponen en los lugares más extraños."

# game/script.rpy:1039
translate spanish kissnya_f5d901a1:

    # p2 "Когда все дела были выполнены, он странно посмотрел куда-то."
    p2 "Una vez terminadas todas las tareas, él miró hacia otro lado con una expresión extraña."

# game/script.rpy:1040
translate spanish kissnya_1430ab9d:

    # p "Что?"
    p "¿Qué?"

# game/script.rpy:1041
translate spanish kissnya_04c07aa9:

    # s "Могу я..."
    s "¿Puedo..."

# game/script.rpy:1042
translate spanish kissnya_f730dfe8:

    # s "Ну..."
    s "Bueno..."

# game/script.rpy:1043
translate spanish kissnya_c797b50b:

    # s fshy2 "Остаться у тебя..? Мой дом далеко, а уже так поздно..."
    s fshy2 "¿Quedarme contigo..? Mi casa está lejos, y ya es muy tarde..."

# game/script.rpy:1047
translate spanish kissnya_8dc0d556:

    # p2 "Почему бы и нет? Давно я не устраивал[p2_verb_a()] ночевки."
    p2 "¿Por qué no? Hace mucho que no me quedo a dormir con alguien."

# game/script.rpy:1048
translate spanish kissnya_9d33e605:

    # p "Да, конечно, можешь остаться."
    p "Sí, claro. Puedes quedarte."

# game/script.rpy:1050
translate spanish kissnya_f2424319:

    # s fcalm "Правда! Спасибо!"
    s fcalm "¿En serio? ¡Gracias!"

# game/script.rpy:1051
translate spanish kissnya_19d03059:

    # p "Не думаю, что дедушка будет против."
    p "No creo que al abuelo le importe."

# game/script.rpy:1057
translate spanish kissnya_111dea31:

    # p "Не думаю, что это хорошая идея..."
    p "No creo que sea buena idea..."

# game/script.rpy:1059
translate spanish kissnya_58221c54:

    # s fsad "Но почему?"
    s fsad "¿Pero por qué?"

# game/script.rpy:1060
translate spanish kissnya_98e6e7ad:

    # s "Ты разве не боишься остаться од[p2_verb_na_in()] в этом доме ночью? "
    s "¿No te da miedo quedarte en esta casa completamente sol[letra] de noche?"

# game/script.rpy:1061
translate spanish kissnya_e92ad82e:

    # p2 "А ведь правда. Я не ночевал[p2_verb_a()] тут од[p2_verb_na_in()], не знаю, чего ожидать. Вдруг в дом ворвется медведь?"
    p2 "Tenía razón. Nunca había pasado la noche aquí sol[letra]. No tenía ni idea de qué esperar. ¿Y si un oso entraba en la casa?"

# game/script.rpy:1062
translate spanish kissnya_f3096939:

    # p "Ну вообще-то да... Я об этом не подумал[p2_verb_a()]."
    p "Bueno... sí, la verdad. No había pensado en eso."

# game/script.rpy:1063
translate spanish kissnya_73061984:

    # s fshy2 "Я останусь с тобой и тебе не будет так страшно!"
    s fshy2 "¡Me quedaré contigo y no dará tanto miedo!"

# game/script.rpy:1064
translate spanish kissnya_1ae7df84:

    # p2 "Я подумал[p2_verb_a()] над его словами. Я не знаю, с чем могу столкнуться тут, так что пусть лучше рядом будет кто-то, кому я хоть как-то доверяю."
    p2 "Pensé en lo que dijo. No sabía con qué me podría topar aquí, así que probablemente era mejor tener a alguien cerca. Alguien de quien me fiara, al menos un poco."

# game/script.rpy:1065
translate spanish kissnya_ee0a9882:

    # p "Хорошо, оставайся."
    p "Vale. Quédate."

# game/script.rpy:1072
translate spanish kissnya_07a35e13:

    # p2 "Мы вошли внутрь, было тихо, я вспомнил[p2_verb_a()] о дедушке. Нужно будет позвонить ему утром, он наверняка придет в себя. "
    p2 "Entramos. Reinaba el silencio, y pensé en el abuelo. Debería llamarlo por la mañana. Probablemente ya estará despierto."

# game/script.rpy:1073
translate spanish kissnya_6e06ada6:

    # p2 "Я начал[p2_verb_a()] думать, куда положить его спать."
    p2 "Empecé a pensar dónde podría dormir él."

# game/script.rpy:1075
translate spanish kissnya_a69f882b:

    # s "Мы можем спать вместе, в детстве мы помещались на твоей кровати."
    s "Podríamos dormir juntos. Cuando éramos niños, cabíamos los dos en tu cama."

# game/script.rpy:1076
translate spanish kissnya_e3304509:

    # s "Да, мы выросли, "
    s "Sí, ahora somos más grandes,"

# game/script.rpy:1078
translate spanish kissnya_8b0e2c18:

    # extend " особенно здесь,"
    extend "sobre todo aquí,"

# game/script.rpy:1081
translate spanish kissnya_e4c02c09:

    # extend " но думаю нам не будет особенно тесно."
    extend "pero no creo que vayamos a estar muy apretados."

# game/script.rpy:1082
translate spanish kissnya_4b1d2cbc:

    # p "Хорошо... Можем спать в одной кровати..."
    p "Vale... Podemos dormir en la misma cama..."

# game/script.rpy:1087
translate spanish kissnya_ef1937cf:

    # p2 "Когда мы оказались под одеялом, он обнял меня."
    p2 "En cuanto nos metimos bajo la manta, me rodeó con sus brazos"

# game/script.rpy:1088
translate spanish kissnya_32404560:

    # s "Комфортно?"
    s "¿Estás cómod[letra]?"

# game/script.rpy:1089
translate spanish kissnya_5b06de7a:

    # p "Ага..."
    p "Sí..."

# game/script.rpy:1091
translate spanish kissnya_6f97b368:

    # p2 "Он сжал меня чуть крепче, голова начала кружиться."
    p2 "Me abrazó un poco más fuerte y sentí que me daba vueltas la cabeza."

# game/script.rpy:1092
translate spanish kissnya_52b5d52c:

    # p2 "Я чувствовал[p2_verb_a()] его напряженное дыхание на своей шее..."
    p2 "Podía sentir su respiración entrecortada en mi cuello..."

# game/script.rpy:1093
translate spanish kissnya_e28e6d63:

    # p2 "Внизу живота стало теплеть..."
    p2 "Empecé a sentir un calor que se acumulaba en lo más bajo de mi estómago..."

# game/script.rpy:1094
translate spanish kissnya_ff0a6383:

    # p2 "Сайлас не предпринимает попыток сделать что-то еще... Нужно заснуть скорее..."
    p2 "Silas no intentaba hacer nada más... Yo necesitaba dormirme pronto..."

# game/script.rpy:1099
translate spanish kissnya_d42661cb:

    # p "Ты можешь спать на диване, я принесу тебе постельное белье."
    p "Puedes dormir en el sofá. Te traeré sábanas y una manta."

# game/script.rpy:1100
translate spanish kissnya_1f848b75:

    # s hangry "Но как я буду защищать тебя из другой комнаты?"
    s hangry "Pero, ¿cómo se supone que voy a protegerte desde otra habitación?"

# game/script.rpy:1101
translate spanish kissnya_635d9e76:

    # p2 "Он просто хочет спать со мной… Он не должен получать все так легко…"
    p2 "Solo busca meterse en mi cama... No voy a ponérselo tan fácil..."

# game/script.rpy:1102
translate spanish kissnya_57bedfa9:

    # p "Но в моей только одна кровать."
    p "Pero en mi habitación solo hay una cama."

# game/script.rpy:1103
translate spanish kissnya_264c41d4:

    # s hcalm "Я могу поспать на полу, я не прихотливый."
    s hcalm "Puedo dormir en el suelo. No soy exigente."

# game/script.rpy:1104
translate spanish kissnya_893f3a1d:

    # p "Ладно, спи на полу, раз так хочешь."
    p "Vale. Duerme en el suelo si tanto quieres."

# game/script.rpy:1109
translate spanish kissnya_9b19a1ab:

    # p2 "Я постелил[p2_verb_a()] ему на полу в своей комнате, он казался довольным."
    p2 "Le preparé una cama en el suelo de mi habitación. Parecía complacido."

# game/script.rpy:1110
translate spanish kissnya_63e39f1c:

    # s "Я вспомнил ночевки, которые мы устраивали тем летом."
    s "Acabo de recordar las pijamadas que tuvimos aquel verano."

# game/script.rpy:1111
translate spanish kissnya_a1d0e632:

    # p "Мы часто делали это?"
    p "¿Hacíamos eso a menudo?"

# game/script.rpy:1112
translate spanish kissnya_bc3c7b39:

    # s "Да, ты боял[p2_verb_as()] спать од[p2_verb_na_in()] и всегда просил[p2_verb_a()] меня остаться. "
    s "Sí. Te daba miedo dormir sol[letra] y siempre me pedías que me quedara."

# game/script.rpy:1113
translate spanish kissnya_0aa4a7bf:

    # p "Я правда был[p2_verb_a()] так труслив[p2_verb_a()]?"
    p "¿De verdad era tan cobarde?"

# game/script.rpy:1114
translate spanish kissnya_1dbcbf9b:

    # s "После моих историй о призраках особенно."
    s "Especialmente después de mis historias de fantasmas."

# game/script.rpy:1115
translate spanish kissnya_3cbae6ec:

    # p "Так значит ты специально пугал меня, чтобы я просил[p2_verb_a()] тебя остаться на ночь?"
    p "¿Así que me asustabas a propósito para que te pidiera que pasaras la noche aquí?"

# game/script.rpy:1116
translate spanish kissnya_a874c7a7:

    # s "{i}Смешок.{/i}"
    s "{i}Una risita.{/i}"

# game/script.rpy:1117
translate spanish kissnya_109766e5:

    # s "Может быть. "
    s "Quizás."

# game/script.rpy:1118
translate spanish kissnya_2d85836a:

    # p "Ты такой хитрец."
    p "Eres muy tramposo."

# game/script.rpy:1119
translate spanish kissnya_70ca91af:

    # s "Не могу ничего с собой поделать."
    s "No puedo evitarlo."

# game/script.rpy:1120
translate spanish kissnya_f3ce8ddb:

    # p2 "Я тихо посмеял[p2_verb_as()]."
    p2 "Solté una risa suave."

# game/script.rpy:1122
translate spanish kissnya_3719c60f:

    # p "Спокойной ночи, хитрый Страж."
    p "Buenas noches, Guardián tramposo."

# game/script.rpy:1124
translate spanish kissnya_b73c8ec6:

    # p "Спокойной ночи."
    p "Buenas noches."

# game/script.rpy:1125
translate spanish kissnya_e1554201:

    # s "..."
    s "..."

# game/script.rpy:1126
translate spanish kissnya_469e5a90:

    # s "Спокойной ночи, Солнышко."
    s "Buenas noches, Solecito."

# game/script.rpy:1129
translate spanish kissnya_3ef24a28:

    # p2 "Что это... {w}Почему мое сердце пропустило удар..?"
    p2 "¿Qué fue eso... {w}¿Por qué me acaba de dar un vuelco el corazón..?"

# game/script.rpy:1130
translate spanish kissnya_e90dd948:

    # p2 "Нужно срочно заснуть..."
    p2 "De verdad necesito dormirme..."

# game/script.rpy:1131
translate spanish kissnya_0e931e06:

    # p2 "Много времени не потребовалось, мысли начали сбиваться и забываться, как обычно бывает перед тем, как заснешь… Однако…"
    p2 "No tardé mucho. Mis pensamientos empezaron a desdibujarse y desvanecerse, como siempre hacen justo antes de dormir... Pero..."

# game/script.rpy:1132
translate spanish kissnya_24b1105b:

    # p2 "Однако, что?"
    p2 "¿Pero qué?"

# game/script.rpy:1133
translate spanish kissnya_ce046504:

    # p2 "О чем я хотел[p2_verb_a()]…"
    p2 "¿Qué estaba intentando..."

# game/script.rpy:1137
translate spanish kissnya_d42661cb_1:

    # p "Ты можешь спать на диване, я принесу тебе постельное белье."
    p "Puedes dormir en el sofá. Te traeré sábanas y una manta."

# game/script.rpy:1138
translate spanish kissnya_a3b49cfa:

    # s "Ладно..."
    s "Vale..."

# game/script.rpy:1139
translate spanish kissnya_b73c8ec6_1:

    # p "Спокойной ночи."
    p "Buenas noches."

# game/script.rpy:1140
translate spanish kissnya_773d48db:

    # s hcalm "Спокойной ночи, надеюсь ты хорошо выспишься, потому что у меня планы на тебя завтра."
    s hcalm "Buenas noches. Espero que duermas bien, porque mañana tengo planes para ti"

# game/script.rpy:1141
translate spanish kissnya_ee00a067:

    # p "Я постараюсь."
    p "Lo intentaré."

# game/script.rpy:1143
translate spanish kissnya_e40023ee:

    # p2 "Я улыбнул[p2_verb_as()] и отправил[p2_verb_as()] в спальню."
    p2 "Sonreí y me fui al dormitorio."

# game/script.rpy:1146
translate spanish kissnya_6ecf19c5:

    # p2 "Сон быстро накатывал. Раньше у меня бывали проблемы с засыпанием, но тут я чувствую приятную усталость к вечеру."
    p2 "El sueño me venció rápido. Antes me costaba conciliar el sueño, pero aquí, al caer la tarde, me sentía agradablemente cansad[letra]."

# game/script.rpy:1162
translate spanish kissnya_c4b5250b:

    # dream "Я… {w} Под водой..?"
    dream "Estoy... {w}¿bajo el agua..?"

# game/script.rpy:1168
translate spanish kissnya_ce6c670e:

    # dream "Почему!? Что происходит!?"
    dream "¡¿Por qué!? ¡¿Qué está pasando!?"

# game/script.rpy:1170
translate spanish kissnya_7f449762:

    # dream "Мне нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться."
    dream "Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir."

# game/script.rpy:1172
translate spanish kissnya_e77f1735:

    # dream "Я не могу двигаться… Но… Что-то толкает меня вверх."
    dream "No puedo moverme... Pero... algo me empuja hacia arriba."

# game/script.rpy:1185
translate spanish kissnya_c4b5250b_1:

    # dream "Я… {w} Под водой..?"
    dream "Estoy... {w}¿bajo el agua..?"

# game/script.rpy:1191
translate spanish kissnya_3f1d5049:

    # dream "Почему!? Что происходит!? "
    dream "¡¿Por qué!? ¡¿Qué está pasando!?"

# game/script.rpy:1192
translate spanish kissnya_7f449762_1:

    # dream "Мне нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться."
    dream "Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir."

# game/script.rpy:1193
translate spanish kissnya_38e4602e:

    # dream "Что-то держит меня… Но я не могу… Я не могу остаться тут!"
    dream "Hay algo que me retiene... ¡Pero no puedo... No puedo quedarme aquí!"

# game/script.rpy:1194
translate spanish kissnya_73baa00a:

    # dream "Я обязан[p2_verb_a()] выбраться!"
    dream "¡Tengo que salir!"

# game/script.rpy:1207
translate spanish kissnya_c4b5250b_2:

    # dream "Я… {w} Под водой..?"
    dream "Estoy... {w}¿bajo el agua..?"

# game/script.rpy:1213
translate spanish kissnya_3f1d5049_1:

    # dream "Почему!? Что происходит!? "
    dream "¡¿Por qué!? ¡¿Qué está pasando!?"

# game/script.rpy:1220
translate spanish kissnya_7f449762_2:

    # dream "Мне нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться. Нужно выбраться."
    dream "Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir. Tengo que salir."

# game/script.rpy:1221
translate spanish kissnya_d8be4516:

    # dream "Что-то держит меня… Я не могу… Я не…"
    dream "Algo me está reteniendo. No puedo... No puedo..."

# game/script.rpy:1232
translate spanish kissnya_ab8a467b:

    # dream "Это тот самый рисунок Сайласа. "
    dream "Es el dibujo de Silas."

# game/script.rpy:1234
translate spanish kissnya_0cbb88e7:

    # dream "Не могу отрицать, что это мило и романтично."
    dream "No puedo negar que es bonito y romántico."

# game/script.rpy:1246
translate spanish kissnya_e7629067:

    # dream "Это тот самый рисунок Сайласа."
    dream "Es el dibujo de Silas."

# game/script.rpy:1249
translate spanish kissnya_bd873aef:

    # dream "Подождите… Что это… "
    dream "Espera... ¿Qué es eso...?"

# game/script.rpy:1251
translate spanish kissnya_012e44db:

    # dream "Почему из дерева течет… Кровь..?"
    dream "¿Por qué sangra el árbol...?"

# game/script.rpy:1253
translate spanish kissnya_67d8cf39:

    # dream "Или это древесный сок..?"
    dream "¿O es savia del árbol...?"

# game/script.rpy:1264
translate spanish kissnya_e7629067_1:

    # dream "Это тот самый рисунок Сайласа."
    dream "Es el dibujo de Silas."

# game/script.rpy:1267
translate spanish kissnya_bd873aef_1:

    # dream "Подождите… Что это… "
    dream "Espera... ¿Qué es eso...?"

# game/script.rpy:1269
translate spanish kissnya_012e44db_1:

    # dream "Почему из дерева течет… Кровь..?"
    dream "¿Por qué sangra el árbol...?"

# game/script.rpy:1272
translate spanish kissnya_e3d04d05:

    # dream "Ее так много…"
    dream "Hay muchísima..."

# game/script.rpy:1284
translate spanish kissnya_cc191b33:

    # dream "Что это..? Я хочу, чтобы оно прекратилось!!!"
    dream "¿Qué es esto...? ¡¡¡Quiero que pare!!!"

# game/script.rpy:1295
translate spanish kissnya_af7955a4:

    # p2 "Такое неприятное чувство..."
    p2 "Qué sensación tan horrible..."

# game/script.rpy:1296
translate spanish kissnya_a9b44044:

    # p2 "Хотя сон вроде не такой уж и плохой..."
    p2 "Aunque el sueño ni siquiera era tan malo..."

# game/script.rpy:1297
translate spanish kissnya_817442b6:

    # p2 "А где Сайлас?"
    p2 "¿Dónde está Silas?"

# game/script.rpy:1298
translate spanish kissnya_08ce606d:

    # p2 "В комнате его не было, я пош[p2_verb_la_el()] на кухню, наверное он где-то там."
    p2 "No estaba en la habitación, así que fui a la cocina. Seguramente estaría por allí."

# game/script.rpy:1300
translate spanish kissnya_71a8a3e8:

    # p2 "Почему ощущение, как будто я еще больше вымотал[p2_verb_as()] от этого сна..."
    p2 "¿Por qué me siento aún más agotad[letra] por culpa de ese sueño...?"

# game/script.rpy:1301
translate spanish kissnya_1293050c:

    # p2 "Сайласа уже нет, наверное ждет меня на первом этаже."
    p2 "Silas ya se ha ido. Probablemente me esté esperando abajo."

# game/script.rpy:1304
translate spanish kissnya_c3e14bd6:

    # p2 "Что это было..?"
    p2 "¿Qué fue eso..?"

# game/script.rpy:1305
translate spanish kissnya_7d93a0a9:

    # p2 "Словно это не просто сон..."
    p2 "Parecía que no era solo un sueño..."

# game/script.rpy:1306
translate spanish kissnya_46a5b61d:

    # p2 "Надо сделать пару вдохов..."
    p2 "Necesito respirar un poco..."

# game/script.rpy:1307
translate spanish kissnya_649290d1:

    # p2 "Надо пойти, посмотреть, как там Сайлас..."
    p2 "Debería ir a ver cómo está Silas..."

# game/script.rpy:1308
translate spanish kissnya_6f0988ae:

    # p2 "Почему я сразу подумал[p2_verb_a()] о нем? Может быть мне станет легче рядом с ним, поэтому я о нем думаю..?"
    p2 "¿Por qué fue él la primera persona en la que pensé? ¿Quizás sigo pensando en él porque estar a su lado me haría sentir mejor...?"

# game/script.rpy:1319
translate spanish kitcen_day_3_ec268559:

    # s "Доброе утро, соня. "
    s "Buenos días, [sleepyhead]."

# game/script.rpy:1320
translate spanish kitcen_day_3_a2c701ad:

    # p2 "Потерев сонные глаза, я сел[p2_verb_a()] за стол. "
    p2 "Frotándome los ojos somnolientos, me senté junto a la mesa."

# game/script.rpy:1321
translate spanish kitcen_day_3_6a1956ca:

    # p "Я долго спал[p2_verb_a()]?"
    p "¿He dormido tanto?"

# game/script.rpy:1322
translate spanish kitcen_day_3_9b360bdb:

    # s "По деревенским меркам - да."
    s "¿Según los estándares del campo? Sí."

# game/script.rpy:1323
translate spanish kitcen_day_3_12ed6590:

    # s "Тут все встают с восходом солнца."
    s "Aquí todo el mundo se levanta al amanecer."

# game/script.rpy:1329
translate spanish kitcen_day_3_b0715a12:

    # p "Ну я еще не настроил[p2_verb_as()] на такой режим, думаю меня можно простить."
    p "Bueno, es que aún no me he adaptado al horario, así que supongo que tengo excusa."

# game/script.rpy:1330
translate spanish kitcen_day_3_fc74f634:

    # s "Ну конечно, не смею винить тебя."
    s "Por supuesto. No me atrevería a culparte."

# game/script.rpy:1331
translate spanish kitcen_day_3_01ce94e2:

    # p "Тебе что-нибудь снилось?"
    p "¿Has soñado con algo?"

# game/script.rpy:1332
translate spanish kitcen_day_3_0987c42f:

    # s "Да, кое-что было."
    s "Sí, con una cosita."

# game/script.rpy:1337
translate spanish kitcen_day_3_3e10e0b8:

    # s khappy "Конечно, про тебя, теперь в моих снах будешь только ты!"
    s khappy "¡Claro que era sobre ti! ¡A partir de ahora, solo tú puedes salir en mis sueños!"

# game/script.rpy:1338
translate spanish kitcen_day_3_c97a5a3a:

    # p2 "Хоть я этого ожидал[p2_verb_a()], но все равно немного смутил[p2_verb_as()]."
    p2 "En cierto modo me lo esperaba, pero aun así me dejó un poco desconcertad[letra]."

# game/script.rpy:1341
translate spanish kitcen_day_3_b8bf3991:

    # s "Мы с тобой сидели на крыше и высматривали птичек, а потом ты начал[p2_verb_a()] падать, я пытался тебя поймать, стал падать вместе с тобой, но под нами оказалось облако. Я упал на тебя, а ты…"
    s "Tú y yo estábamos sentados en un tejado, observando pájaros. Entonces empezaste a caer, e intenté atraparte, así que caí contigo... pero había una nube debajo de nosotros. Aterricé encima de ti, y tú..."

# game/script.rpy:1345
translate spanish kitcen_day_3_f8a27f91:

    # s kserious "Эротический."
    s kserious "Erótico."

# game/script.rpy:1347
translate spanish kitcen_day_3_60f93d72:

    # p2 "Я поперхнул[p2_verb_as()] воздухом от его ответа."
    p2 "Me atraganté con el aire ante su respuesta."

# game/script.rpy:1348
translate spanish kitcen_day_3_f4894691:

    # s "Ты в порядке!?"
    s "¡¿Estás bien!?"

# game/script.rpy:1349
translate spanish kitcen_day_3_e6a1ca12:

    # s "Прости!! Я просто пошутил!!"
    s "¡¡Perdón!! ¡¡Solo bromeaba!!"

# game/script.rpy:1350
translate spanish kitcen_day_3_4c47f5bf:

    # p "Я… кхм… В порядке…"
    p "Estoy... Ejem... estoy bien..."

# game/script.rpy:1351
translate spanish kitcen_day_3_3e02f536:

    # s kshy "Хорошо… Да… Сон был романтическим."
    s kshy "Bueno... Sí... Fue un sueño romántico."

# game/script.rpy:1352
translate spanish kitcen_day_3_c3079210:

    # p "И что там было?"
    p "¿Y qué pasó en él?"

# game/script.rpy:1353
translate spanish kitcen_day_3_b8bf3991_1:

    # s "Мы с тобой сидели на крыше и высматривали птичек, а потом ты начал[p2_verb_a()] падать, я пытался тебя поймать, стал падать вместе с тобой, но под нами оказалось облако. Я упал на тебя, а ты…"
    s "Tú y yo estábamos sentados en un tejado, observando pájaros. Entonces empezaste a caer, e intenté atraparte, así que caí contigo... pero había una nube debajo de nosotros. Aterricé encima de ti, y tú..."

# game/script.rpy:1356
translate spanish kitcen_day_3_85d6b57a:

    # s khappy "Ты притянул[p2_verb_a()] меня к себе и поцеловал[p2_verb_a()]…"
    s khappy "Me atrajiste hacia ti y me besaste..."

# game/script.rpy:1360
translate spanish kitcen_day_3_6e1de1ca:

    # s "Клянусь, я это не контролирую!"
    s "¡Te lo juro, no puedo controlarlo!"

# game/script.rpy:1361
translate spanish kitcen_day_3_0ed7e95e:

    # s kcalm "Твои губы выглядят такими вкусными, дай мне насладиться ими хотя бы во снах."
    s kcalm "Tus labios son tan tentadores. Al menos déjame disfrutarlos en mis sueños."

# game/script.rpy:1362
translate spanish kitcen_day_3_8ca94f64:

    # p "Ты можешь хоть немного сбавить напор флирта?"
    p "¿Podrías dejar de coquetear un poco?"

# game/script.rpy:1363
translate spanish kitcen_day_3_8c4cf946:

    # s khappy "Неа, не могу и не хочу! Ты долж[p2_verb_na_en()] знать, что я чувствую к тебе!"
    s khappy "¡No, no puedo y no quiero! ¡Necesitas saber lo que siento por ti!"

# game/script.rpy:1364
translate spanish kitcen_day_3_fb3c127a:

    # p "Да я уже понял[p2_verb_a()]… "
    p "Sí, eso ya lo tengo claro..."

# game/script.rpy:1365
translate spanish kitcen_day_3_2c6f664b:

    # s "Но еще не ответил[p2_verb_a()] взаимностью!"
    s "¡Pero aún no me has correspondido!"

# game/script.rpy:1366
translate spanish kitcen_day_3_daba47d8:

    # p "Это не работает так быстро…"
    p "Eso no funciona tan rápido..."

# game/script.rpy:1367
translate spanish kitcen_day_3_479c9107:

    # s kcalm "Понимаю, я тебя не тороплю, но останавливаться не буду."
    s kcalm "Lo sé. No te estoy presionando, pero tampoco me voy a detener."

# game/script.rpy:1370
translate spanish kitcen_day_3_8ffad9fb:

    # s "Мягко, но знаешь, что еще мягче?"
    s "Fue suave. ¿Pero sabes qué es aún más suave?"

# game/script.rpy:1373
translate spanish kitcen_day_3_48649f40:

    # s "Твои губы!"
    s "¡Tus labios!"

# game/script.rpy:1374
translate spanish kitcen_day_3_1d19a25c:

    # s kshock "Ой. "
    s kshock "Oh."

# game/script.rpy:1375
translate spanish kitcen_day_3_053fcc9f:

    # s "Ты понимаешь, что только что произошло?"
    s "¿Te das cuenta de lo que acaba de pasar?"

# game/script.rpy:1376
translate spanish kitcen_day_3_b5cb7c11:

    # p "Нет, что?"
    p "No, ¿qué?"

# game/script.rpy:1377
translate spanish kitcen_day_3_181aab5d:

    # s "Ты начал[p2_verb_a()] читать мои мысли! А это происходит, когда люди становятся очень близки друг с другом!"
    s "¡Has empezado a leerme la mente! ¡Eso pasa cuando la gente se vuelve muy cercana!"

# game/script.rpy:1378
translate spanish kitcen_day_3_9514665f:

    # p "Ты все еще помнишь, что мы встретились два дня назад?"
    p "Te acuerdas de que nos conocimos hace dos días, ¿verdad?"

# game/script.rpy:1379
translate spanish kitcen_day_3_26388f4a:

    # s kcalm "А ты помнишь, что не помнишь целое лето, которое мы провели вместе?"
    s kcalm "¿Y te acuerdas de que no recuerdas todo el verano que pasamos juntos?"

# game/script.rpy:1380
translate spanish kitcen_day_3_1b828101:

    # p "Да, но как это связано?"
    p "Sí, pero ¿qué tiene que ver eso?"

# game/script.rpy:1381
translate spanish kitcen_day_3_5c568ea1:

    # s "Подсознательно ты чувствуешь все, что было между нами, так что эта связь есть! "
    s "En el fondo, puedes sentir todo lo que hubo entre nosotros, ¡así que el vínculo está ahí!"

# game/script.rpy:1382
translate spanish kitcen_day_3_386d9638:

    # p "Ну, возможно."
    p "Bueno, quizás."

# game/script.rpy:1384
translate spanish kitcen_day_3_a6e7d93b:

    # s kshock "Ой! блинчики горят!"
    s kshock "¡Oh! ¡Se están quemando los panqueques!"

# game/script.rpy:1387
translate spanish kitcen_day_3_885342d1:

    # s "Ну… Можно и так сказать. Мне снил[p2_verb_as()] ты и…"
    s "Bueno... Se podría decir que sí. Te he soñado y..."

# game/script.rpy:1388
translate spanish kitcen_day_3_a283a639:

    # p "Ты меня съел!?"
    p "¿¡Me comiste!?"

# game/script.rpy:1389
translate spanish kitcen_day_3_dce3474c:

    # s kshy "К сожалению нет… Но мы там целовались, так что можно сказать, я попробовал кусочек тебя."
    s kshy "Por desgracia, no... Pero nos besamos, así que se podría decir que he probado un poco de ti"

# game/script.rpy:1390
translate spanish kitcen_day_3_747f398e:

    # p "Только если слюны попил немного. "
    p "Solo si cuentas haber probado un poco de saliva."

# game/script.rpy:1391
translate spanish kitcen_day_3_17e327dc:

    # s khappy "Но вкусно же было! Я бы попросил добавки, но ты ведь откажешься. "
    s khappy "¡Pero estaba sabroso! Pediría repetición, pero tú dirías que no."

# game/script.rpy:1392
translate spanish kitcen_day_3_ba51c717:

    # p "Фу, конечно я откажусь, это противно."
    p "Puaj, claro que diría que no. Eso es asqueroso."

# game/script.rpy:1393
translate spanish kitcen_day_3_cb7ffd8b:

    # s kserious "Ты считаешь, что поцелуи — это противно?"
    s kserious "¿Crees que besar es asqueroso?"

# game/script.rpy:1394
translate spanish kitcen_day_3_adee472b:

    # p "Нет, но, когда мы говорим именно о слюне, как-то противненько, понимаешь? "
    p "No, pero cuando hablamos específicamente de saliva, se vuelve un poco asqueroso, ¿sabes?"

# game/script.rpy:1395
translate spanish kitcen_day_3_bee92f4c:

    # s khappy "Но если ты любишь человека, то тебе не противны любые его телесные жидкости."
    s khappy "Pero si amas a alguien, ninguno de sus fluidos corporales te da asco."

# game/script.rpy:1396
translate spanish kitcen_day_3_d51b65bc:

    # p "Боже, Сайлас, умоляю прекрати, мы же завтракать собираемся…"
    p "Dios, Silas, por favor para. Estamos a punto de desayunar..."

# game/script.rpy:1397
translate spanish kitcen_day_3_82b9e206:

    # s "Ладно, ладно, прекращаю."
    s "Vale, vale, pararé."

# game/script.rpy:1404
translate spanish kitcen_day_3_bd4f3ef5:

    # p "Дедушка очнулся, я позвоню ему."
    p "El abuelo está despierto. Voy a llamarlo."

# game/script.rpy:1406
translate spanish kitcen_day_3_dd4157ce:

    # p "Доброе утро, дедушка."
    p "Buenos días, abuelo."

# game/script.rpy:1407
translate spanish kitcen_day_3_ecea8b7f:

    # ded "Утро?? Уже полдень! Почти вечер!"
    ded "¿¿Buenos días?? ¡Ya es mediodía! ¡Casi de noche!"

# game/script.rpy:1408
translate spanish kitcen_day_3_ca3a1da9:

    # p2 "Я тихо хихикнул[p2_verb_a()], уже второй раз за пару минут меня отчитывают за мое абсолютно человеческое желание поспать немного дольше."
    p2 "Solté una risita. Era la segunda vez en solo unos minutos que me regañaban por el deseo perfectamente humano de dormir un poco más."

# game/script.rpy:1409
translate spanish kitcen_day_3_6d3b790b:

    # p "Ну конечно, как скажешь."
    p "Claro, lo que tú digas."

# game/script.rpy:1410
translate spanish kitcen_day_3_74fd64f6:

    # p "Как твое самочувствие?"
    p "¿Cómo te sientes?"

# game/script.rpy:1411
translate spanish kitcen_day_3_6d774dca:

    # ded "Прихожу в норму, скоро вернусь на ферму, передай коровам, что я скучаю по ним."
    ded "Estoy volviendo a la normalidad. Pronto volveré a la granja. Dile a las vacas que las echo de menos."

# game/script.rpy:1412
translate spanish kitcen_day_3_64fce607:

    # p "Обязательно передам, но не уверен[p2_verb_a()], что они станут меня слушать."
    p "Me aseguraré de decirles eso, pero no estoy segur[letra] de que me hagan caso."

# game/script.rpy:1413
translate spanish kitcen_day_3_07ac4fe5:

    # ded "А ты там как? Я слышу кого-то на фоне, это Кайл?"
    ded "¿Qué tal por ahí? Oigo a alguien de fondo. ¿Es Kyle?"

# game/script.rpy:1415
translate spanish kitcen_day_3_817d2d7e:

    # p "Нет, это Сайлас, ты ведь знаешь его, да?"
    p "No, es Silas. Lo conoces, ¿verdad?"

# game/script.rpy:1416
translate spanish kitcen_day_3_9b916816:

    # ded "Сайлас? Почему он с тобой?"
    ded "¿Silas? ¿Por qué está contigo?"

# game/script.rpy:1419
translate spanish kitcen_day_3_f33af6a8:

    # p "Он узнал, что я приехал[p2_verb_a()] и мы снова подружились."
    p "Se enteró de que había regresado y volvimos a ser amigos."

# game/script.rpy:1422
translate spanish kitcen_day_3_36030e48:

    # ded "Не знал, что вы подружитесь, ты избегал[p2_verb_a()] его в детстве."
    ded "No pensé que se harían amigos. Solías evitarlo cuando eran niños"

# game/script.rpy:1424
translate spanish kitcen_day_3_badf854e:

    # p2 "Избегал[p2_verb_a()]? Странно. Наверное, я просто стеснял[p2_verb_as()]."
    p2 "¿Lo evitaba? Qué raro. Quizás solo era tímid[letra]."

# game/script.rpy:1426
translate spanish kitcen_day_3_0c41ac23:

    # p "Ты уверен? Мы вроде хорошо ладим."
    p "¿Estás seguro? Parece que nos llevamos bastante bien."

# game/script.rpy:1428
translate spanish kitcen_day_3_1d471997:

    # p2 "Я напряг[p2_verb_las_sya()]… Что-то было не так… Этому были объяснения, но интуиция подсказывала мне что-то…"
    p2 "Me puse tens[letra]... Algo no me parecía bien... Había explicaciones para eso, pero mi instinto me decía algo..."

# game/script.rpy:1436
translate spanish kitcen_day_3_c4ff9ce5:

    # s "Здравствуйте!"
    s "¡Hola!"

# game/script.rpy:1437
translate spanish kitcen_day_3_dc43d655:

    # s "[p] еще не завтракал[p2_verb_a()], а вы понимаете, насколько это важно! Но он[p2_verb_a()] еще позвонит вам позже!"
    s "¡[p] aún no ha desayunado, y estoy seguro de que entiendes lo importante que es! ¡Pero [p] te llamará más tarde!"

# game/script.rpy:1438
translate spanish kitcen_day_3_9c10d87f:

    # s "Выздоравливайте! "
    s "¡Que te mejores!"

# game/script.rpy:1441
translate spanish kitcen_day_3_a241951e:

    # p2 "Он странно себя ведет. Зачем он отобрал у меня телефон? Ему не терпелось позавтракать со мной?"
    p2 "Está actuando raro. ¿Por qué me quitó el teléfono? ¿Tantas ganas tenía de desayunar conmigo?"

# game/script.rpy:1443
translate spanish kitcen_day_3_0c8e9530:

    # p2 "Он боится, что дедушка расскажет что-то, что я не долж[p2_verb_na_en()] знать?"
    p2 "¿Tiene miedo de que el abuelo me cuente algo que no debería saber?"

# game/script.rpy:1448
translate spanish kitcen_day_3_408bfa40:

    # s "Ты сегодня спал[p2_verb_a()] в смешной позе."
    s "Hoy dormiste en una postura graciosa."

# game/script.rpy:1449
translate spanish kitcen_day_3_964e8ab6:

    # p2 "Его вопрос вывел меня из размышлений."
    p2 "Su comentario me sacó de mis pensamientos."

# game/script.rpy:1451
translate spanish kitcen_day_3_a23833d7:

    # p "Но мы спали в разных комнатах, откуда ты знаешь?"
    p "Pero dormimos en habitaciones diferentes. ¿Cómo lo sabes?"

# game/script.rpy:1452
translate spanish kitcen_day_3_fe36c9fd:

    # s kshy2 "А-ээ... Я утром зашел проверить, не проснул[p2_verb_as()] ли ты..."
    s kshy2 "E-eh... Entré esta mañana para ver si estabas despiert[letra]..."

# game/script.rpy:1453
translate spanish kitcen_day_3_fefe64a8:

    # p2 "Чувствую себя странно от того, что он без моего ведома наблюдал за тем, как я сплю…"
    p2 "Se siente raro saber que me vio dormir sin que yo lo supiera..."

# game/script.rpy:1454
translate spanish kitcen_day_3_8efb1792:

    # p "Ну ладно..."
    p "Bueno, vale..."

# game/script.rpy:1456
translate spanish kitcen_day_3_fd9acf73:

    # p "Правда? И в какой позе я спал[p2_verb_a()]?"
    p "¿En serio? ¿En qué postura estaba durmiendo?"

# game/script.rpy:1457
translate spanish kitcen_day_3_a4d81beb:

    # s "Похоже на черепаху, которую сбила машина."
    s "Parecías una tortuga atropellada."

# game/script.rpy:1458
translate spanish kitcen_day_3_edc017df:

    # p "О боже..."
    p "Dios mío..."

# game/script.rpy:1459
translate spanish kitcen_day_3_7ed66561:

    # p "Это жестокое описание…"
    p "Esa es una brutal descripción..."

# game/script.rpy:1460
translate spanish kitcen_day_3_362e25f7:

    # s khappy "Да, понимаю, но именно на это ты был[p2_verb_a()] похож[p2_verb_a()]."
    s khappy "Sí, lo sé, pero es exactamente así como te veías."

# game/script.rpy:1461
translate spanish kitcen_day_3_54f8108a:

    # s "Маленькая дохлая черепашка."
    s "Una tortuguita muerta."

# game/script.rpy:1462
translate spanish kitcen_day_3_4b98bd8c:

    # p "Не называй это так, мне жалко черепашку."
    p "No la llames así. Me da pena la tortuga."

# game/script.rpy:1463
translate spanish kitcen_day_3_fcae5aac:

    # s "Ладно, ладно, не буду, раз ты так[p2_verb_aya_oy()] чувствительн[p2_verb_aya_iiy()]."
    s "Vale, vale, no lo haré, ya que eres tan sensible."

# game/script.rpy:1464
translate spanish kitcen_day_3_977df97b:

    # p "Спасибо…"
    p "Gracias..."

# game/script.rpy:1465
translate spanish kitcen_day_3_e242b4d1:

    # p2 "Мы закончили завтракать, нужно было идти заниматься фермой."
    p2 "Terminamos de desayunar. Era hora de ocuparse de la granja."

# game/script.rpy:1473
translate spanish kitcen_day_3_8269c20d:

    # s "Позволишь мне помочь тебе?"
    s "¿Me dejarás ayudarte?"

# game/script.rpy:1480
translate spanish kitcen_day_3_1914e581:

    # "Нужно выбрать, дать ли ему дела в этот раз?"
    "Tengo que decidir si darle tareas esta vez."

# game/script.rpy:1492
translate spanish kitcen_day_3_bca0d638:

    # "Можешь выпустить животных."
    "Puedes soltar a los animales."

# game/script.rpy:1494
translate spanish kitcen_day_3_b4ccaca4:

    # "и выпустить животных."
    "y soltar a los animales."

# game/script.rpy:1500
translate spanish kitcen_day_3_11053dcc:

    # "Можешь собрать яйца."
    "Puedes recoger los huevos."

# game/script.rpy:1502
translate spanish kitcen_day_3_6d3cd8b1:

    # "И собрать яйца."
    "Y recoger los huevos."

# game/script.rpy:1509
translate spanish kitcen_day_3_3b66fdf0:

    # "Можешь накормить скот."
    "Puedes dar de comer a los animales."

# game/script.rpy:1511
translate spanish kitcen_day_3_f46802a1:

    # "И покормить скот."
    "Y dar de comer a los animales."

# game/script.rpy:1520
translate spanish kitcen_day_3_46f3f193:

    # s "Хорошо! Я все сделаю!"
    s "¡Vale! ¡Lo haré todo!"

# game/script.rpy:1522
translate spanish kitcen_day_3_99e07518:

    # p "На этом все, сделаешь это?"
    p "Eso es todo. ¿Puedes hacer eso?"

# game/script.rpy:1523
translate spanish kitcen_day_3_c46b09f0:

    # s "Конечно! Я бы никогда не отказался помочь тебе!"
    s "¡Por supuesto! ¡Nunca rechazaría la oportunidad de ayudarte!"

# game/script.rpy:1524
translate spanish kitcen_day_3_b64fd888:

    # p "Спасибо."
    p "Gracias."

# game/script.rpy:1525
translate spanish kitcen_day_3_d2e7b0d2:

    # p "Я улыбнул[p2_verb_as()] ему."
    p "Le sonreí."

# game/script.rpy:1527
translate spanish kitcen_day_3_7c32c7c0:

    # p "Хочу сделать все сам[p2_verb_a()]"
    p "Quiero hacerlo todo yo mism[letra]."

# game/script.rpy:1528
translate spanish kitcen_day_3_35db2d1a:

    # s "Если вдруг понадобится помощь, то я рядом!"
    s "¡Si necesitas ayuda, estaré justo aquí!"

# game/script.rpy:1532
translate spanish kitcen_day_3_d0f776e6:

    # p2 "Сайлас пошел заниматься делами, а я наблюдал[p2_verb_a()] за ним. Видно, что он привык к работе на ферме, он ловко справляется, а выглядит при этом как модель."
    p2 "Silas se fue a hacer las tareas y lo observé. Era evidente que estaba acostumbrado al trabajo de la granja. Lo manejaba todo con facilidad y, de algún modo, parecía un modelo mientras lo hacía."

# game/script.rpy:1540
translate spanish kitcen_day_3_79886a7b:

    # p "Так, нужно всех накормить."
    p "Bien, tengo que dar de comer a todos."

# game/script.rpy:1544
translate spanish kitcen_day_3_96519a24:

    # p "Выпускать животных довольно легко, они такие послушные, когда идут гулять."
    p "Soltar a los animales es bastante fácil. Se portan muy bien cuando salen a pastar."

# game/script.rpy:1550
translate spanish kitcen_day_3_caaa5f46:

    # p "К утру курочки несут меньше яиц, но не могу их винить, кто бы захотел всю ночь рожать детей."
    p "Las gallinas ponen menos huevos por la mañana, pero no puedo culparlas. ¿Quién iba a querer pasarse toda la noche sacando pollitos?"

# game/script.rpy:1560
translate spanish kitcen_day_3_cbb19bf4:

    # p2 "После утренних хлопот мы сели на скамью у крыльца. Она была горячей от ярких солнечных лучей."
    p2 "Después de las tareas de la mañana, nos sentamos en el banco del porche. Estaba cálido por la brillante luz del sol."

# game/script.rpy:1562
translate spanish kitcen_day_3_9b8f5a30:

    # p "Люблю ясную погоду, ощущаю себя ящерицей, которая вылазит на теплый камешек, чтобы погреться."
    p "Me encanta el tiempo despejado. Me hace sentir como una lagartija arrastrándose sobre una roca cálida para calentarse."

# game/script.rpy:1563
translate spanish kitcen_day_3_ae2dc5d3:

    # s "Очень хороший день. Он идеально подходит для одного веселого занятия."
    s "Es un día realmente agradable. Perfecto para una actividad muy divertida."

# game/script.rpy:1564
translate spanish kitcen_day_3_83db8b9d:

    # p "И что это за занятие?"
    p "¿Y qué actividad es esa?"

# game/script.rpy:1565
translate spanish kitcen_day_3_e8714645:

    # s phappy2 "Рыбалка! Хочешь пойти на рыбалку сегодня?"
    s phappy2 "¡Pescar! ¿Quieres ir a pescar hoy?"

# game/script.rpy:1566
translate spanish kitcen_day_3_cb6059ee:

    # p2 "Рыбалка..? Но… Это опасно, там вода рядом… Слишком рядом…"
    p2 "¿Pescar..? Pero... eso es peligroso. El agua estaría cerca... Demasiado cerca..."

# game/script.rpy:1567
translate spanish kitcen_day_3_1c05e384:

    # p "Это не самая лучшая идея..."
    p "No es la mejor idea..."

# game/script.rpy:1568
translate spanish kitcen_day_3_266facd0:

    # s pnya "Да ладно тебе! "
    s pnya "¡Oh, vamos!"

# game/script.rpy:1569
translate spanish kitcen_day_3_a5d9970a:

    # s "Наловим свежей рыбки и сразу приготовим ее."
    s "Pescaremos pescado fresco y lo cocinaremos enseguida."

# game/script.rpy:1570
translate spanish kitcen_day_3_6b2dac5f:

    # p "Свежая рыбка..."
    p "Pescado fresco..."

# game/script.rpy:1571
translate spanish kitcen_day_3_8e09a2b9:

    # p2 "Мой живот заурчал. Не понятно из-за недавно съеденных блинчиков или от мыслей о свежей рыбе."
    p2 "Me rugió el estómago. No sabía si era por los panqueques que acababa de comer o porque estaba pensando en pescado fresco."

# game/script.rpy:1572
translate spanish kitcen_day_3_fe6498a0:

    # p "Хорошо, но я не буду подходить к воде."
    p "Vale, pero no me voy a acercar al agua."

# game/script.rpy:1573
translate spanish kitcen_day_3_9417f0f6:

    # s "Как скажешь."
    s "Lo que tú digas."

# game/script.rpy:1574
translate spanish kitcen_day_3_30e78406:

    # s "Я схожу домой за удочкой, подождешь меня тут?"
    s "Iré a casa a por mi caña de pescar. ¿Puedes esperarme aquí?"

# game/script.rpy:1575
translate spanish kitcen_day_3_51c53af8:

    # p "Я могу пойти с тобой."
    p "Puedo ir contigo."

# game/script.rpy:1576
translate spanish kitcen_day_3_9d48636a:

    # s pserious "Нет, не стоит, побудь здесь, я быстро."
    s pserious "No, no lo hagas. Quédate aquí. Seré rápido."

# game/script.rpy:1587
translate spanish kitcen_day_3_6ffd6b52:

    # p2 "Я остал[p2_verb_as()] сидеть там, ожидая его и думая о том, действительно ли рыбалка того стоит. Но рыбка… Я очень хотел[p2_verb_a()] рыбку…"
    p2 "Me quedé allí, esperándolo y preguntándome si la pesca valía realmente la pena. Pero el pescado... de verdad quería pescado..."

# game/script.rpy:1592
translate spanish kitcen_day_3_b10bbcf3:

    # p2 "Ко мне пришла кошечка."
    p2 "Una gata se me acercó."

# game/script.rpy:1593
translate spanish kitcen_day_3_2bbe9f80:

    # p2 "Не видел[p2_verb_a()] ее раньше, да и дедушка не говорил, что у него есть кошка. Может, конечно, это кошка соседей, но тогда она прошла довольно большой путь сюда."
    p2 "No la había visto antes, y el abuelo nunca mencionó tener una gata. Quizás era de los vecinos, pero si así fuera, habría venido desde bastante lejos."

# game/script.rpy:1594
translate spanish kitcen_day_3_cadf93fb:

    # k "Милая, да?"
    k "Es linda, ¿no?"

# game/script.rpy:1605
translate spanish kitcen_day_3_b269b73f:

    # p2 "Я удивил[p2_verb_as()] его появлению, но не подал[p2_verb_a()] виду."
    p2 "Me sorprendió su repentina aparición, pero no lo demostré."

# game/script.rpy:1606
translate spanish kitcen_day_3_a3594e8b:

    # p "Привет. Да, она милашка."
    p "Hola. Sí, es adorable."

# game/script.rpy:1607
translate spanish kitcen_day_3_1f8fc688:

    # k pcalm2 "Ее зовут Кейси."
    k pcalm2 "Se llama Casey."

# game/script.rpy:1608
translate spanish kitcen_day_3_29c7027b:

    # p "Кейси? Странное имя для кошки. Почему не Миссис Пушистолапка или что-то в этом роде?"
    p "¿Casey? Nombre raro para una gata. ¿Por qué no Señora PatitasdePeluche o algo así?"

# game/script.rpy:1609
translate spanish kitcen_day_3_1041cea7:

    # k pprost "Кто знает, как твой дед выбирает имена. "
    k pprost "Quién sabe cómo elige los nombres tu abuelo."

# game/script.rpy:1610
translate spanish kitcen_day_3_164007df:

    # k "Он нашел ее в лесу и забрал сюда. Она иногда пропадает на несколько дней, а потом как ни в чем не бывало возвращается. Делает, что хочет."
    k "La encontró en el bosque y la trajo aquí. A veces desaparece por unos días, luego vuelve como si nada. Hace lo que le da la gana."

# game/script.rpy:1611
translate spanish kitcen_day_3_6e0d48b3:

    # p "Хотел[p2_verb_a()] бы я быть так[p2_verb_oy_im()] свободн[p2_verb_oy_iim()] и беззаботн[p2_verb_oy_iim()]."
    p "Ojalá pudiera ser tan libre y despreocupad[letra]."

# game/script.rpy:1614
translate spanish kitcen_day_3_10a34276:

    # k pcat "Ага, все мы хотим и в тайне завидуем кошкам."
    k pcat "Sí, todos lo deseamos. En el fondo, todo el mundo envidia a los gatos."

# game/script.rpy:1615
translate spanish kitcen_day_3_05103d3c:

    # p "Похоже она тебя любит."
    p "Parece que le gustas."

# game/script.rpy:1616
translate spanish kitcen_day_3_6100b658:

    # k "Да, животные почему-то любят меня."
    k "Sí, por alguna razón los animales me tienen cariño."

# game/script.rpy:1619
translate spanish kitcen_day_3_5b173397:

    # k pcat2 "Ну уж не знаю."
    k pcat2 "Quién sabe."

# game/script.rpy:1621
translate spanish kitcen_day_3_41d823b5:

    # k pcat2 "Ну да, не могу удержаться и даю им что-то вкусное."
    k pcat2 "Bueno, sí. No puedo evitar darles algo rico."

# game/script.rpy:1622
translate spanish kitcen_day_3_f24debb3:

    # p "А почему ты здесь? "
    p "Entonces, ¿por qué estás aquí?"

# game/script.rpy:1623
translate spanish kitcen_day_3_21bf8b3c:

    # k pcat "Старик просил проверить как ты там."
    k pcat "Tu abuelo me pidió que viniera a ver cómo estabas."

# game/script.rpy:1624
translate spanish kitcen_day_3_1a07d4b6:

    # p "Я же не ребенок, почему он переживет!"
    p "No soy [arti_2] niñ[letra]. ¡¿Por qué está preocupado?!"

# game/script.rpy:1626
translate spanish kitcen_day_3_fc8965bb:

    # k pcat3 "Может он переживает не за тебя, а за сохранность своей фермы."
    k pcat3 "Quizás no está preocupado por ti. Quizás está preocupado por la supervivencia de su granja."

# game/script.rpy:1627
translate spanish kitcen_day_3_c974c110:

    # k "Ты уже пытал[p2_verb_as()] однажды поджечь амбар."
    k "Una vez intentaste prenderle fuego al granero."

# game/script.rpy:1628
translate spanish kitcen_day_3_3fc292fd:

    # p "Я?? Зачем??"
    p "¿¿Yo?? ¿¿Por qué??"

# game/script.rpy:1630
translate spanish kitcen_day_3_52ee535b:

    # k pcat2 "Баловал[p2_verb_as()] с огнем и решил[p2_verb_a()] проверить, как горит сено. Повезло, что мы были рядом."
    k pcat2 "Estabas jugando con fuego y decidiste ver lo bien que ardía el heno. Menos mal que estábamos cerca."

# game/script.rpy:1631
translate spanish kitcen_day_3_d59dc021:

    # p "Мне сильно влетело?"
    p "¿Me metí en problemas?"

# game/script.rpy:1632
translate spanish kitcen_day_3_b4ea9edc:

    # k pcat "Старик заставил тебя чистить загон с коровами."
    k pcat "Tu abuelo te hizo limpiar el establo de las vacas."

# game/script.rpy:1633
translate spanish kitcen_day_3_cf2c4ab7:

    # p "Заслуженно..."
    p "Me lo merecía..."

# game/script.rpy:1634
translate spanish kitcen_day_3_d2fb05ed:

    # k pcat3 "Тебе нужна какая-то помощь по ферме? "
    k pcat3 "¿Necesitas ayuda en la granja?"

# game/script.rpy:1635
translate spanish kitcen_day_3_5993846b:

    # p "Нет, спасибо, пока справляюсь."
    p "No, gracias. Me las estoy arreglando bien hasta ahora."

# game/script.rpy:1636
translate spanish kitcen_day_3_6e2b1c29:

    # k "Ладно, раз ты в порядке, я пойду."
    k "Muy bien. Ya que estás bien, me voy."

# game/script.rpy:1637
translate spanish kitcen_day_3_f4b185eb:

    # k pcat2 "Если что-то понадобится, звони."
    k pcat2 "Llama si necesitas algo."

# game/script.rpy:1638
translate spanish kitcen_day_3_4b7d76c4:

    # p "Спасибо, до встречи!"
    p "Gracias, ¡nos vemos!"

# game/script.rpy:1647
translate spanish kitcen_day_3_1990e93c:

    # p2 "Он ушел. С ним было приятно говорить, но скоро должен был вернуться Сайлас."
    p2 "Se fue. Fue agradable hablar con él, pero Silas debería volver pronto."

# game/script.rpy:1656
translate spanish kitcen_day_3_2db8c021:

    # s "Ну что, готов[p2_verb_a()]?"
    s "Entonces, ¿list[letra]?"

# game/script.rpy:1657
translate spanish kitcen_day_3_188622c1:

    # p "Надеюсь, что да…"
    p "Eso espero..."

# game/script.rpy:1658
translate spanish kitcen_day_3_50f6ce95:

    # s "Тогда пошли!"
    s "¡Entonces vamos!"

# game/script.rpy:1669
translate spanish fishing_2558e845:

    # p2 "Наблюдать за ним было интересно, ловля рыбы похожа на лотерею, где от тебя что-то зависит. И призы приятные."
    p2 "Observarlo era interesante. Pescar es como una lotería donde tus decisiones sí importan. Y los premios son bastante buenos."

# game/script.rpy:1674
translate spanish fishing_431f5a11:

    # p2 "Я снова задумал[p2_verb_as()] о рыбе, которую мы потом съедим. Я бы даже сказал[p2_verb_a()], что замечтал[p2_verb_as()]."
    p2 "Volví a pensar en el pescado que comeríamos más tarde. Puede que incluso empezara a soñar despiert[letra] con eso."

# game/script.rpy:1678
translate spanish fishing_6d752453:

    # s "Тебе тоже стоит попробовать."
    s "Tú también deberías intentarlo."

# game/script.rpy:1685
translate spanish fishing_37f0b463:

    # p "…"
    p "..."

# game/script.rpy:1686
translate spanish fishing_194741d4:

    # p "Нет, спасибо."
    p "No, gracias."

# game/script.rpy:1687
translate spanish fishing_168223cb:

    # s "Да ладно тебе! Я обещаю, это будет весело!"
    s "¡Vamos! ¡Te prometo que será divertido!"

# game/script.rpy:1688
translate spanish fishing_d6780e80:

    # p "Я вижу, что это весело, но мне как-то некомфортно стоять у воды…"
    p "Veo que es divertido, pero estar cerca del agua me hace sentir incómod[letra]..."

# game/script.rpy:1689
translate spanish fishing_bc79b6c6:

    # s "Тебе ведь не нужно прыгать в воду, просто закидывай удочку, а с остальным я помогу."
    s "No tienes que tirarte al agua. Solo lanza la caña, y yo te ayudo con lo demás."

# game/script.rpy:1690
translate spanish fishing_a7aafe1f:

    # p "Ладно..."
    p "Vale..."

# game/script.rpy:1695
translate spanish fishing_42190f16:

    # p2 "Я пытал[p2_verb_as()] закидывать удочку дальше, но крючок едва касался реки…"
    p2 "Traté de lanzar el hilo más lejos, pero el anzuelo apenas llegó al río..."

# game/script.rpy:1696
translate spanish fishing_4bf76a8e:

    # s "Встань ближе, ты даже до воды не достаешь."
    s "Acércate más. Ni siquiera llegas al agua desde ahí."

# game/script.rpy:1697
translate spanish fishing_5cab212e:

    # s "Давай, не волнуйся, я рядом."
    s "Vamos, no te preocupes. Estoy justo aquí."

# game/script.rpy:1702
translate spanish fishing_543fa56d:

    # p2 "Я подош[p2_verb_la_el()] ближе к воде, Сайлас стоял позади и направлял мои движения."
    p2 "Di un paso más cerca del agua. Silas se puso detrás de mí, guiando mis movimientos."

# game/script.rpy:1706
translate spanish fishing_4171827b:

    # p "Оно тянет!!!"
    p "¡¡¡Está tirando!!!"

# game/script.rpy:1707
translate spanish fishing_45ab7ec6:

    # s "Тяни на себя!"
    s "¡Sácalo!"

# game/script.rpy:1714
translate spanish fishing_fad55198:

    # p "Ого! Моя первая рыба!"
    p "¡Guau! ¡Mi primer pez!"

# game/script.rpy:1717
translate spanish fishing_187e6242:

    # s "АХАХАХАХАХА ПОЧЕМУ ТЫ ТАК ЕЕ ДЕРЖИШЬ?"
    s "JAJAJAJAJAJA ¿POR QUÉ LO AGARRAS ASÍ?"

# game/script.rpy:1720
translate spanish fishing_b60ff493:

    # p "ОНА СКОЛЬЗКАЯ!!!"
    p "¡¡¡ESTÁ RESBALADIZO!!!"

# game/script.rpy:1722
translate spanish fishing_7de045e6:

    # p2 "Эта маленькая рыба так обрадовала меня, мне захотелось больше. Я был[p2_verb_a()] прав[p2_verb_a()], называя это лотереей, рыбалка – это настоящее казино, от нее появляется зависимость с первого раза."
    p2 "Ese pececito me hizo tan feliz que quise más. Tenía razón al llamarlo lotería. Pescar es básicamente un casino. Te enganchan desde la primera vez."

# game/script.rpy:1727
translate spanish fishing_d4167a97:

    # p2 "Азарт добавил мне уверенности, я начал[p2_verb_a()] рыбачить без помощи Сайласа."
    p2 "La emoción me dio confianza, y empecé a pescar sin la ayuda de Silas."

# game/script.rpy:1731
translate spanish fishing_964694f5:

    # p2 "У меня хорошо получалось, я даже встал[p2_verb_a()] на пристань, Сайлас был рядом, так что мне не было страшно."
    p2 "Lo estaba haciendo bastante bien. Incluso me paré en el muelle. Silas estaba cerca, así que no tenía miedo."

# game/script.rpy:1738
translate spanish fishing_b8c5731d:

    # p2 "Внезапно что-то сильно потянуло удочку."
    p2 "De repente, algo tiró con fuerza de la caña."

# game/script.rpy:1740
translate spanish fishing_8b08f91f:

    # p2 "Я этого не ожидал[p2_verb_a()], было сложно удержаться на месте, Рыба была очень сильная, раз мне даже стоять было сложно."
    p2 "No me lo esperaba. Me costaba mucho mantenerme en mi lugar. El pez debía de ser muy fuerte si me costaba tanto siquiera mantenerme de pie."

# game/script.rpy:1741
translate spanish fishing_17dce39a:

    # p "САЙЛАС!! "
    p "¡¡SILAS!!"

# game/script.rpy:1747
translate spanish fishing_39b8aa5d:

    # p2 "Не могу пошевелиться..."
    p2 "No puedo moverme..."

# game/script.rpy:1748
translate spanish fishing_8dc4c6b6:

    # p2 "Не могу дышать..."
    p2 "No puedo respirar..."

# game/script.rpy:1749
translate spanish fishing_fbf1db6a:

    # p2 "Я..."
    p2 "Yo..."

# game/script.rpy:1750
translate spanish fishing_cba429a7:

    # p2 "Нет..."
    p2 "No..."

# game/script.rpy:1755
translate spanish fishing_8b8f9c94:

    # s "[p.upper()], ПРОСТИ!!"
    s "¡¡[p.upper()], LO SIENTO!!"

# game/script.rpy:1756
translate spanish fishing_adf78427:

    # s "Я отошел за наживкой на несколько секунд!"
    s "¡Solo me alejé unos segundos para ir a buscar el cebo!"

# game/script.rpy:1757
translate spanish fishing_5101f6bc:

    # s "Прости меня, пожалуйста..."
    s "Por favor, perdóname..."

# game/script.rpy:1758
translate spanish fishing_3d51713f:

    # p "Сайлас..."
    p "Silas..."

# game/script.rpy:1759
translate spanish fishing_0e3a36bd:

    # s sky3 "Я рядом, я не дал бы тебе утонуть..."
    s sky3 "Ya estoy aquí. No te habría dejado ahogarte..."

# game/script.rpy:1760
translate spanish fishing_d770f88a:

    # p2 "Слезы навернулись на глазах."
    p2 "Se me llenaron los ojos de lágrimas."

# game/script.rpy:1761
translate spanish fishing_d93671da:

    # s "Прости меня..."
    s "Lo siento..."

# game/script.rpy:1762
translate spanish fishing_085617e1:

    # p "Я не хочу тут быть..."
    p "No quiero estar aquí..."

# game/script.rpy:1763
translate spanish fishing_355fcd2e:

    # s "Мы сейчас уйдем, не волнуйся..."
    s "Nos iremos ahora mismo. No te preocupes..."

# game/script.rpy:1774
translate spanish fishing_e2e0b932:

    # s "Прости... Я должен был быть рядом, я обещал..."
    s "Lo siento... Debería haberme quedado cerca. Lo prometí..."

# game/script.rpy:1778
translate spanish fishing_8581d940:

    # p2 "Это не его вина, я сам[p2_verb_a()] согласил[p2_verb_as()] рыбачить, сам[p2_verb_a()] вышел[p2_verb_a()] на пристань, он не обязан все время держать меня за руку."
    p2 "No es su culpa. Yo mism[letra] acepté ir a pescar. Yo mism[letra] me subí al muelle. No tiene que tomarme de la mano todo el tiempo."

# game/script.rpy:1779
translate spanish fishing_1b093b2e:

    # p "Все в порядке, ты не виноват... И спасибо, что вытащил меня..."
    p "Está bien. No es tu culpa... Y gracias por sacarme..."

# game/script.rpy:1782
translate spanish fishing_58815db7:

    # s psad "Я больше никогда не подвергну тебя опасности... Обещаю..."
    s psad "Nunca más te pondré en peligro... Te lo prometo..."

# game/script.rpy:1783
translate spanish fishing_5e4e2f3a:

    # p2 "Я чувствовал[p2_verb_a()] себя жалк[p2_verb_oy_im()]. Почему я не могу быть как нормальные люди... Там даже не было настолько глубоко… Держу пари, я бы и в луже умудрил[p2_verb_as()] утонуть…"
    p2 "Me sentí patétic[letra]. Por qué no puedo ser como la gente normal... Ni siquiera era tan profundo... Apuesto a que lograría ahogarme en un charco..."

# game/script.rpy:1784
translate spanish fishing_2e63b23e:

    # p "Я хочу избавиться от этого..."
    p "Quiero deshacerme de eso..."

# game/script.rpy:1787
translate spanish fishing_79d7a8ac:

    # s pskr "Избавиться от чего..?"
    s pskr "¿Deshacerte de qué..?"

# game/script.rpy:1788
translate spanish fishing_3ab00c46:

    # p "От страха перед водой..."
    p "Mi miedo al agua..."

# game/script.rpy:1795
translate spanish fishing_6f9f5b64:

    # p2 "Он обещал быть рядом, но оставил меня… Даже не предупредил…"
    p2 "Prometió que se quedaría cerca, pero me dejó... Ni siquiera me avisó..."

# game/script.rpy:1796
translate spanish fishing_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:1797
translate spanish fishing_f0d33def:

    # s psad "Знаешь... Тебе пора победить этот страх..."
    s psad "Sabes... Es hora de que superes ese miedo..."

# game/script.rpy:1798
translate spanish fishing_c86ff01a:

    # p "Но он слишком сильный... Я не могу..."
    p "Pero es demasiado fuerte... No puedo..."

# game/script.rpy:1799
translate spanish fishing_8c69f7d2:

    # s pplav "Я буду рядом, у тебя все получится. Мы будем действовать постепенно."
    s pplav "Estaré justo ahí contigo. Puedes hacerlo. Lo haremos paso a paso."

# game/script.rpy:1801
translate spanish fishing_1a69c0f0:

    # s pplav "Может быть, попробуем искупаться завтра?"
    s pplav "¿Quizás podríamos intentar ir a nadar mañana?"

# game/script.rpy:1802
translate spanish fishing_65be5f91:

    # p "Завтра..? Но я еще от сегодня не отош[p2_verb_la_el()]… "
    p "¿Mañana..? Pero ni siquiera me he recuperado de hoy..."

# game/script.rpy:1803
translate spanish fishing_e63241df:

    # p "Это слишком резко..."
    p "Eso es demasiado repentino..."

# game/script.rpy:1804
translate spanish fishing_685e3d30:

    # s "Ты можешь сначала хотя бы ноги помочить, а потом, может быть, тебе станет проще, и ты пойдешь дальше."
    s "Puedes empezar solo mojando los pies. Luego quizás se haga más fácil, y puedas ir un poco más lejos."

# game/script.rpy:1805
translate spanish fishing_53861bbc:

    # p2 "Думаю, он прав. Я ведь не утону от того, что опущу ноги в воду. "
    p2 "Supongo que tiene razón. No me voy a ahogar solo por meter los pies en el agua."

# game/script.rpy:1806
translate spanish fishing_a7aafe1f_1:

    # p "Ладно..."
    p "Vale..."

# game/script.rpy:1807
translate spanish fishing_6966679c:

    # p2 "А что, если та рыба, которая чуть не убила меня сегодня, схватит мою ногу и потащит в воду? Она наверняка огромная… Проглотит меня разом и не наестся… "
    p2 "¿Pero y si ese pez que casi me mata hoy me agarra la pierna y me arrastra al agua? Tiene que ser enorme... Podría tragarme enter[letra] y seguir teniendo hambre..."

# game/script.rpy:1808
translate spanish fishing_c943f86e:

    # s "{size=20}Можно сегодня снова остаться у тебя?{/size}"
    s "{size=20}¿Puedo volver a quedarme a dormir esta noche?{/size}"

# game/script.rpy:1809
translate spanish fishing_fb271dec:

    # p "Ага."
    p "Sí."

# game/script.rpy:1810
translate spanish fishing_f499ec7b:

    # s "{size=20}И спать в одной кровати?{/size}"
    s "{size=20}¿Y dormir en la misma cama?{/size}"

# game/script.rpy:1811
translate spanish fishing_c7cc4dfa:

    # p "Да."
    p "Sí."

# game/script.rpy:1813
translate spanish fishing_2ca6b457:

    # p2 "Что?? О чем он спрашивал?? "
    p2 "¿¿Qué?? ¿¿Qué estaba preguntando??"

# game/script.rpy:1814
translate spanish fishing_0af5b98d:

    # p2 "Я был[p2_verb_a()] погружен[p2_verb_a()] в мысли о воде, так что даже не сразу понял[p2_verb_a()], о чем он меня спрашивает, но отступать было поздно. "
    p2 "Estaba tan absort[letra] pensando en el agua que al principio ni siquiera me di cuenta de lo que me estaba preguntando, pero ya era tarde para echarme atrás."

# game/script.rpy:1815
translate spanish fishing_e096b686:

    # s "Пойдем тогда делать фермерскую рутину?"
    s "Entonces, ¿vamos a hacer la rutina de la granja?"

# game/script.rpy:1816
translate spanish fishing_0771f832:

    # p "Верно, животные уже проголодались."
    p "Cierto, los animales deben tener hambre ya."

# game/script.rpy:1823
translate spanish fishing_134aaed3:

    # s "Ты теперь обязан[p2_verb_a()] позволить мне сделать все дела за тебя, из-за меня ты сейчас так[p2_verb_aya_oy()] напуганн[p2_verb_aya_iiy()]."
    s "Ahora tienes que dejarme hacer todas las tareas por ti. Es culpa mía que estés tan asustad[letra] ahora."

# game/script.rpy:1830
translate spanish fishing_11fb947f:

    # "Может он прав и мне сегодня стоит отдохнуть?"
    "¿Quizás tiene razón, y debería descansar hoy?"

# game/script.rpy:1842
translate spanish fishing_3d6df1d0:

    # "Можешь загнать животных."
    "Puedes meter a los animales."

# game/script.rpy:1844
translate spanish fishing_94ab071e:

    # "и загнать животных."
    "y meter a los animales."

# game/script.rpy:1850
translate spanish fishing_11053dcc:

    # "Можешь собрать яйца."
    "Puedes recoger los huevos."

# game/script.rpy:1852
translate spanish fishing_6d3cd8b1:

    # "И собрать яйца."
    "Y recoger los huevos."

# game/script.rpy:1859
translate spanish fishing_3b66fdf0:

    # "Можешь накормить скот."
    "Puedes dar de comer a los animales."

# game/script.rpy:1861
translate spanish fishing_f46802a1:

    # "И покормить скот."
    "Y dar de comer a los animales."

# game/script.rpy:1870
translate spanish fishing_2c9963f0:

    # s fehappy "Хорошо! Я все сделаю, а ты отдохни!"
    s fehappy "¡Vale! ¡Lo haré todo yo, y tú descansa!"

# game/script.rpy:1871
translate spanish fishing_b64fd888:

    # p "Спасибо."
    p "Gracias."

# game/script.rpy:1876
translate spanish fishing_99e07518:

    # p "На этом все, сделаешь это?"
    p "Eso es todo. ¿Puedes hacer eso?"

# game/script.rpy:1877
translate spanish fishing_87c23013:

    # s feser "Почему ты не хочешь, чтобы я сделал все дела?"
    s feser "¿Por qué no me dejas hacer todas las tareas?"

# game/script.rpy:1878
translate spanish fishing_e171e378:

    # p "Некоторые дела по ферме расслабляют меня, так что я не против их сделать."
    p "Algunas tareas de la granja me ayudan a relajarme, así que no me importa hacerlas."

# game/script.rpy:1879
translate spanish fishing_35ca305b:

    # s fecalm "Ну ладно, как скажешь..."
    s fecalm "Bueno, vale. Lo que tú digas..."

# game/script.rpy:1884
translate spanish fishing_5895f41b:

    # p "Хочу сделать все сам[p2_verb_a()]."
    p "Quiero hacerlo todo yo mism[letra]."

# game/script.rpy:1885
translate spanish fishing_b37320ff:

    # s feser "Почему? Разве после стресса ты не хочешь отдохнуть?"
    s feser "¿Por qué? ¿No quieres descansar después de todo ese estrés?"

# game/script.rpy:1886
translate spanish fishing_781b0ab1:

    # p "Дела помогут мне расслабиться."
    p "Las tareas me ayudarán a relajarme."

# game/script.rpy:1887
translate spanish fishing_b6107256:

    # s "Ладно, если так тебе будет лучше..."
    s "Vale, si eso te hace sentir mejor..."

# game/script.rpy:1895
translate spanish fishing_8b80186a:

    # p2 "Сайлас пошел заниматься делами, пока я отдыхал[p2_verb_a()]. Но сегодня у меня есть оправдание."
    p2 "Silas se fue a hacer las tareas mientras yo descansaba. Pero hoy, al menos, tenía una excusa."

# game/script.rpy:1899
translate spanish fishing_e591cd05:

    # p "Нужно загнать животных."
    p "Tengo que meter a los animales."

# game/script.rpy:1907
translate spanish fishing_0a19ebaa:

    # p "Обязательно всех накормить."
    p "Tengo que asegurarme de que todos coman."

# game/script.rpy:1912
translate spanish fishing_bd96875a:

    # p "Интересно, сколько яиц снесли курочки сегодня."
    p "Me pregunto cuántos huevos habrán puesto las gallinas hoy."

# game/script.rpy:1920
translate spanish fishing_42850055:

    # p2 "После дел по ферме, я почувствовал[p2_verb_a()], что проголодал[p2_verb_as()], живот просил рыбы… "
    p2 "Después de las tareas de la granja, me di cuenta de que tenía hambre. Mi estómago suplicaba pescado..."

# game/script.rpy:1921
translate spanish fishing_2f16ca00:

    # p "А мы собираемся съесть ту рыбу?"
    p "¿Vamos a comer ese pescado?"

# game/script.rpy:1922
translate spanish fishing_1c088920:

    # s fehappy "Конечно, но ее нужно разделать. Я пойду к себе и займусь этим там, у меня дома все инструменты и стол для разделки рыбы."
    s fehappy "Por supuesto, pero primero tengo que limpiarlo. Volveré a mi casa y lo haré allí. Tengo todas las herramientas y una mesa para limpiar pescado en casa."

# game/script.rpy:1923
translate spanish fishing_0bb21dac:

    # p "Можно пойти с тобой?"
    p "¿Puedo ir contigo?"

# game/script.rpy:1924
translate spanish fishing_b693cc3f:

    # s feser "Нет, жди меня тут, я быстро справлюсь."
    s feser "No, espérame aquí. Seré rápido."

# game/script.rpy:1925
translate spanish fishing_67b1e68c:

    # p "Но почему ты не хочешь водить меня к себе? Уже второй отказываешь."
    p "Pero, ¿por qué no quieres que vaya a tu casa? Es la segunda vez que me dices que no."

# game/script.rpy:1926
translate spanish fishing_754631fe:

    # s feang "Там нет ничего интересного, к тому же, чтобы попасть в деревню, нужно пройти через мост, а ты боишься."
    s feang "No hay nada interesante allí. Además, para llegar al pueblo, tendríamos que cruzar el puente, y te da miedo."

# game/script.rpy:1927
translate spanish fishing_04ac3141:

    # p "Мы же решили, что я буду бороться со страхом! "
    p "¡Decidimos que iba a luchar contra ese miedo!"

# game/script.rpy:1928
translate spanish fishing_8725bf6a:

    # s "Ты еще не приш[p2_verb_la_el()] в себя после сегодняшнего падения, тебе нужно время восстановиться."
    s "Aún no te has recuperado de caerte hoy. Necesitas tiempo para recomponerte."

# game/script.rpy:1929
translate spanish fishing_6b33977b:

    # p2 "Значит сегодня мне нельзя, а завтра уже можно? Либо он странный, либо что-то скрывает… Может стесняется своего дома или родителей? "
    p2 "¿Así que hoy no puedo, pero mañana sí? O se está comportando de forma rara, o está ocultando algo... ¿Quizás le da vergüenza su casa o sus padres?"

# game/script.rpy:1930
translate spanish fishing_2e29d51e:

    # p "Ладно, я подожду здесь…"
    p "Vale, esperaré aquí..."

# game/script.rpy:1935
translate spanish fishing_783834ae:

    # p2 "Он поцеловал меня в голову, наверное пытался сбросить напряжение между нами."
    p2 "Me besó en la coronilla, probablemente intentando aliviar la tensión entre nosotros."

# game/script.rpy:1937
translate spanish fishing_401a4a29:

    # s "Я скоро вернусь. "
    s "Volveré pronto."

# game/script.rpy:1947
translate spanish fishing_d4e2e3bf:

    # p2 "Он ушел, но я решил[p2_verb_a()] не терять времени даром и позвонил[p2_verb_a()] дедушке. "
    p2 "Se fue, pero decidí no perder el tiempo y llamé al abuelo."

# game/script.rpy:1951
translate spanish fishing_eb312253:

    # p "Привет, ну как ты там?"
    p "Hola, ¿cómo te va por ahí?"

# game/script.rpy:1952
translate spanish fishing_761c1985:

    # ded "Рад тебя слышать, [p]. Врачи говорят, что скоро меня выпишут, так что жди моего возвращения."
    ded "Me alegra oír tu voz, [p]. Los médicos dicen que me darán de alta pronto, así que prepárate para mi regreso."

# game/script.rpy:1953
translate spanish fishing_cba7fdf8:

    # p "Это так хорошо! Я очень жду твоего возвращения!"
    p "¡Eso es genial! ¡Tengo ganas de que vuelvas!"

# game/script.rpy:1954
translate spanish fishing_7adbbb39:

    # ded "А сам[p2_verb_a()] ты там как? Кайл сказал, что справляешься со всем."
    ded "¿Y tú cómo estás? Kyle me dijo que lo estás manejando todo."

# game/script.rpy:1955
translate spanish fishing_edeaa29c:

    # p "Да, дела на ферме идут хорошо, думаю я [p2_verb_farm()]."
    p "Sí, las cosas en la granja van bien. Creo que soy granjer[letra] de nacimiento."

# game/script.rpy:1956
translate spanish fishing_053fa2c8:

    # ded "Раз так, то оставайся со мной, зачем тебе возвращаться в скучный город? Там воздух грязный и овощи из пластика!"
    ded "En ese caso, quédate aquí conmigo. ¿Por qué volver a esa ciudad aburrida? ¡El aire está sucio allí y las verduras son de plástico!"

# game/script.rpy:1957
translate spanish fishing_58587406:

    # p2 "Первой реакцией был тихий смешок, но ведь правда, у жизни в деревне много плюсов. "
    p2 "Mi primera reacción fue una risa suave, pero honestamente, la vida en el campo realmente tenía muchos puntos buenos."

# game/script.rpy:1958
translate spanish fishing_af759fd5:

    # p "Я подумаю над твоим предложением."
    p "Pensaré en tu oferta."

# game/script.rpy:1959
translate spanish fishing_d27a32ea:

    # ded "Ты все еще с Сайласом?"
    ded "¿Sigues con Silas?"

# game/script.rpy:1960
translate spanish fishing_d306608d:

    # p "Да, но он пошел к себе, чтобы разделать рыбу, которую мы поймали сегодня."
    p "Sí, pero volvió a su casa a limpiar el pescado que atrapamos hoy."

# game/script.rpy:1961
translate spanish fishing_9cd08a09:

    # ded "Вы были на рыбалке? Но разве ты не боишься воды?"
    ded "¿Fuiste a pescar? ¿Pero no le tienes miedo al agua?"

# game/script.rpy:1962
translate spanish fishing_a2df512d:

    # p2 "Не хочу рассказывать дедушке о том, что произошло, ему лучше не волноваться сейчас."
    p2 "No quiero contarle al abuelo lo que pasó. Es mejor que no se preocupe ahora."

# game/script.rpy:1963
translate spanish fishing_47e044e4:

    # p "Все еще боюсь, но рыбачить было весело."
    p "Todavía le tengo, pero pescar fue divertido."

# game/script.rpy:1964
translate spanish fishing_54f8ef50:

    # ded "Хорошо, что ты веселишься там, ты не представляешь, как это радует твоего старика."
    ded "Me alegra que te estés divirtiendo allí. No tienes idea de lo feliz que hace eso a este viejo."

# game/script.rpy:1965
translate spanish fishing_6d5f4409:

    # p "Ты не такой уж старый. Сколько тебе? 90?"
    p "No eres tan viejo. ¿Cuánto tienes, noventa?"

# game/script.rpy:1966
translate spanish fishing_bf007973:

    # ded "67 вообще-то! Хах. "
    ded "Sesenta y siete, de hecho. ¡Ja!"

# game/script.rpy:1967
translate spanish fishing_af71c8a6:

    # ded "Слушай, Сайлас нормально ведет себя?"
    ded "Escucha, ¿Silas se porta bien?"

# game/script.rpy:1968
translate spanish fishing_4befca47:

    # p "Что ты имеешь ввиду?"
    p "¿Qué quieres decir?"

# game/script.rpy:1969
translate spanish fishing_c0820c1f:

    # ded "После твоего отъезда он стал совсем закрытый, даже пугающий…"
    ded "Después de que te fuiste, se volvió completamente reservado. Incluso daba miedo..."

# game/script.rpy:1970
translate spanish fishing_0c5ef60f:

    # p "Ну… Он немного странный, но открытый и веселый."
    p "Bueno... Es un poco extraño, pero es abierto y alegre."

# game/script.rpy:1971
translate spanish fishing_b2697308:

    # ded "Похоже он действительно привязан к тебе."
    ded "Parece que está muy apegado a ti."

# game/script.rpy:1972
translate spanish fishing_fe34ae7c:

    # ded "Прошу тебя, будь осторож[p2_verb_na_en()] с ним."
    ded "Por favor, ten cuidado con él."

# game/script.rpy:1973
translate spanish fishing_f1063581:

    # p "Почему?"
    p "¿Por qué?"

# game/script.rpy:1974
translate spanish fishing_a1348d5c:

    # ded "На всякий случай… Я не думаю, что он плохой парень, но осторожность не повредит, верно?"
    ded "Por si acaso... No creo que sea un mal tipo, pero tener cuidado no está de más, ¿verdad?"

# game/script.rpy:1975
translate spanish fishing_e429b5ef:

    # p "Ты прав, всегда нужно быть на стороже."
    p "Tienes razón. Siempre es bueno mantenerse en guardia."

# game/script.rpy:1976
translate spanish fishing_bc17498d:

    # ded "Ты умница."
    ded "Chic[letra] list[letra]."

# game/script.rpy:1977
translate spanish fishing_b6677efe:

    # ded "Меня медсестра подгоняет, чтобы я ложился спать, я пойду."
    ded "La enfermera me está apurando para que me vaya a la cama, así que me voy."

# game/script.rpy:1978
translate spanish fishing_9438bae5:

    # p "Спокойной ночи и выздоровления тебе!"
    p "¡Buenas noches, y que te mejores!"

# game/script.rpy:1979
translate spanish fishing_5de8ed44:

    # ded "Спасибо, тебе тоже хорошей ночи."
    ded "Gracias. Que tengas buenas noches tú también."

# game/script.rpy:1981
translate spanish fishing_eca36bd7:

    # p2 "Быть осторожнее с Сайласом… Мне сложно представить его замкнутым, он всегда практически светится и выглядит так, словно может подружиться с каждым. "
    p2 "Tener cuidado con Silas... Es difícil imaginarlo reservado. Prácticamente brilla todo el tiempo y parece que podría hacerse amigo de cualquiera."

# game/script.rpy:1984
translate spanish fishing_7e92de46:

    # s "[p.upper()]!"
    s "¡[p.upper()]!"

# game/script.rpy:1985
translate spanish fishing_f6135508:

    # p2 "Я испугал[p2_verb_as()] его громкого голоса."
    p2 "Su voz fuerte me sobresaltó."

# game/script.rpy:1991
translate spanish fishing_0763e9de:

    # s "Соскучил[p2_verb_as()]?"
    s "¿Me echaste de menos?"

# game/script.rpy:1995
translate spanish fishing_5e8e7994:

    # s fshy "Хе-хе, так и знал, что ты уже жить без меня не можешь!"
    s fshy "Jeje, ¡sabía que ya no podías vivir sin mí!"

# game/script.rpy:1999
translate spanish fishing_56138ea6:

    # s fcl "Ну незачем быть так[p2_verb_oy_im()] груб[p2_verb_oy_iim()]!"
    s fcl "¡No hay necesidad de ser tan groser[letra]!"

# game/script.rpy:2001
translate spanish fishing_029bd70a:

    # s fcalm "Я разделал рыбу и вытащил все косточки, чтобы ты не подавил[p2_verb_as()]."
    s fcalm "Limpié el pescado y le quité todas las espinas para que no te puedas atragantar."

# game/script.rpy:2002
translate spanish fishing_6f53221e:

    # p "Очень мило с твоей стороны. Как приготовим ее? "
    p "Qué amable de tu parte. ¿Cómo lo vamos a cocinar?"

# game/script.rpy:2003
translate spanish fishing_0676e373:

    # s "Я думал о том, чтобы пожарить ее на открытом огне."
    s "Estaba pensando en asarlo a la parrilla."

# game/script.rpy:2004
translate spanish fishing_0e1e5da6:

    # p2 "У меня буквально потекли слюни, когда я подумал[p2_verb_a()] о жаренной на открытом огне рыбе. "
    p2 "Se me hizo agua la boca, literalmente, al pensar en el pescado asado a la parrilla."

# game/script.rpy:2005
translate spanish fishing_421065c2:

    # p "Да. Сделай это. Сейчас же."
    p "Sí. Hazlo. Ahora mismo."

# game/script.rpy:2006
translate spanish fishing_2676f7ea:

    # s fsly "Приказываешь мне?"
    s fsly "¿Dándome órdenes?"

# game/script.rpy:2007
translate spanish fishing_15ba0a94:

    # s "Мне нравится."
    s "Me gusta."

# game/script.rpy:2008
translate spanish fishing_bde55997:

    # p "Молчать!"
    p "¡Silencio!"

# game/script.rpy:2009
translate spanish fishing_6ca8a474:

    # s "Как скажешь, [p2_verb_master()]."
    s "Como desees, [p2_verb_mistress()]."

# game/script.rpy:2017
translate spanish fishing_0989cab7:

    # p2 "Он разжег угольный гриль и стал жарить рыбу. От запаха я захлебывал[p2_verb_as()] слюной. Так здорово, что он умеет готовить, Наверное мне тоже стоит научиться, а не питаться доставками и полуфабрикатами. "
    p2 "Encendió la parrilla de carbón y empezó a cocinar el pescado. El olor me hacía prácticamente babear. Era increíble que supiera cocinar. Quizás yo también debería aprender, en lugar de vivir a base de comida a domicilio y congelada."

# game/script.rpy:2018
translate spanish fishing_910ba534:

    # s "Готово. "
    s "Listo."

# game/script.rpy:2026
translate spanish fishing_c1653165:

    # p "Это божественно. Я хочу расцеловать тебя прямо сейчас."
    p "Esto es maravilloso. Quiero besarte por todas partes ahora mismo."

# game/script.rpy:2027
translate spanish fishing_de7abc52:

    # s "Хе, ну я всегда не против."
    s "Je, siempre estoy dispuesto a eso."

# game/script.rpy:2032
translate spanish fishing_6e82da5a:

    # p2 "Я положил[p2_verb_a()] кусочек рыбы в рот, мягкая сочная текстура таяла на языке. Я был[p2_verb_a()] готов[p2_verb_a()] расплакаться от того, как вкусно это было. "
    p2 "Me llevé un trozo de pescado a la boca. Su textura suave y jugosa se derritió en mi lengua. Sabía tan bien que me dieron ganas de llorar."

# game/script.rpy:2036
translate spanish fishing_5ae80209:

    # p "Я не знаю, кому ты продал душу за свой талант готовить, но это просто восхитительно. "
    p "No sé a quién le vendiste el alma a cambio de tus habilidades culinarias, pero esto es increíble."

# game/script.rpy:2039
translate spanish fishing_f0ea664a:

    # s fishcalm2 "Все дело в секретном ингредиенте."
    s fishcalm2 "Todo es gracias al ingrediente secreto."

# game/script.rpy:2040
translate spanish fishing_537cb5c9:

    # p "Не говори, что это любовь."
    p "No me digas que es amor."

# game/script.rpy:2041
translate spanish fishing_8655bea1:

    # s "Это любовь."
    s "Es amor."

# game/script.rpy:2042
translate spanish fishing_46b6106b:

    # p "Похоже ты действительно очень сильно любишь меня."
    p "Parece que de verdad me quieres mucho."

# game/script.rpy:2043
translate spanish fishing_a85f3f7f:

    # s fishshy "Ну это же очевидно. Люблю тебя так сильно, что иногда это причиняет боль."
    s fishshy "Bueno, ¿no es obvio? Te quiero tanto que a veces duele."

# game/script.rpy:2044
translate spanish fishing_d209eb17:

    # p "Но почему? Что во мне такого, что ты не переставал любить меня все эти годы?"
    p "¿Pero por qué? ¿Qué tengo de especial para que nunca dejaras de quererme en todos estos años?"

# game/script.rpy:2045
translate spanish fishing_37102b37:

    # s "Просто ты, в[p2_verb_sya_es()] ты, ты очаровател[p2_verb_mna_en()], драгоцен[p2_verb_na_en()] и идеал[p2_verb_mna_en()]."
    s "Solo tú. Todo lo que eres. Eres increíble, precios[letra] y perfect[letra]."

# game/script.rpy:2046
translate spanish fishing_118aaa8b:

    # p2 "Мои щеки покрылись румянцем, я чуть не подавил[p2_verb_as()] ужином. Мне нужно сказать что-то в ответ. "
    p2 "Me sonrojé y casi me atraganto con la cena. Necesitaba decir algo a cambio."

# game/script.rpy:2047
translate spanish fishing_961f91c7:

    # s "Ничего не говори. Мне достаточно того, что ты принимаешь мои чувства."
    s "No tienes que decir nada. Para mí es suficiente con que aceptes mis sentimientos."

# game/script.rpy:2048
translate spanish fishing_3b8c76ab:

    # p2 "Как он так легко читает меня. Как будто очень хорошо знает. "
    p2 "¿Cómo me lee tan fácilmente? Es como si me conociera muy bien."

# game/script.rpy:2049
translate spanish fishing_beabe5d5:

    # p "Рыба… Правда вкусная…"
    p "El pescado... de verdad está delicioso..."

# game/script.rpy:2050
translate spanish fishing_948ff6f8:

    # s fishcalm2 "Рад, что тебе нравится."
    s fishcalm2 "Me alegra que te guste."

# game/script.rpy:2053
translate spanish fishing_77b37dcb:

    # p2 "Я наел[p2_verb_as()], он все убрал и помыл, а потом мы отправились спать."
    p2 "Comí hasta llenarme. Él limpió todo y lavó los platos, y luego nos fuimos a la cama."

# game/script.rpy:2065
translate spanish fishing_cf6741f6:

    # p2 "Он так близко... "
    p2 "Está tan cerca..."

# game/script.rpy:2066
translate spanish fishing_6d9c3af1:

    # s "Почему-то я вспомнил, как мы отправились в поход на несколько дней и забыли сказать об этом взрослым."
    s "Por alguna razón, acabo de recordar la vez que fuimos de acampada unos días y nos olvidamos de decírselo a cualquier adulto."

# game/script.rpy:2067
translate spanish fishing_901c0036:

    # p "Мы правда сделали такое?? Как мы могли забыть сказать кому-то??"
    p "¿¿De verdad hicimos eso?? ¿¿Cómo pudimos olvidarnos de decírselo a alguien??"

# game/script.rpy:2068
translate spanish fishing_ac95222c:

    # s "Потому что были слишком увлечены идеей похода."
    s "Porque estábamos demasiado emocionados con la idea de acampar."

# game/script.rpy:2069
translate spanish fishing_0759b779:

    # p "И нас не искали?"
    p "¿Y nadie nos buscó?"

# game/script.rpy:2070
translate spanish fishing_46fabbb9:

    # s "Искали конечно, всю деревню на уши подняли."
    s "Claro que sí. Todo el pueblo fue puesto patas arriba."

# game/script.rpy:2072
translate spanish fishing_6e7937cc:

    # p2 "Странно... Мне даже никто об этом ничего не сказал."
    p2 "Qué raro... Nadie me contó nunca nada sobre eso."

# game/script.rpy:2073
translate spanish fishing_a20cefa7:

    # "..."
    "..."

# game/script.rpy:2074
translate spanish fishing_9905e39d:

    # s bser "Тебе до сих пор страшно от твоего падения в воду?"
    s bser "¿Todavía tienes miedo después de haberte caído al agua?"

# game/script.rpy:2075
translate spanish fishing_4ead9646:

    # p "Уже легче..."
    p "Ya me estoy sintiendo mejor..."

# game/script.rpy:2076
translate spanish fishing_4c600e82:

    # s "Но твоя нижняя губа дрожит."
    s "Pero te tiembla el labio inferior."

# game/script.rpy:2077
translate spanish fishing_cd5a1bf2:

    # p2 "И вправду, дрожит. Но не знаю, это из-за падения или из-за того, что он рядом. "
    p2 "De verdad que sí. Pero no sabía si era por la caída o porque él estaba tan cerca."

# game/script.rpy:2079
translate spanish fishing_a4d55444:

    # p "Все в порядке, такое бывает."
    p "No pasa nada. Son cosas que pasan."

# game/script.rpy:2084
translate spanish fishing_648092e3:

    # p2 "Внезапно, он придвинулся ближе."
    p2 "De repente, se acercó."

# game/script.rpy:2085
translate spanish fishing_99ff17e9:

    # p2 "Он собирается меня поцеловать?? "
    p2 "¿¿Me va a besar??"

# game/script.rpy:2090
translate spanish fishing_2380382d:

    # p2 "Я оставал[p2_verb_as()] на месте, ожидая того, что произойдет."
    p2 "Me quedé donde estaba, esperando a ver qué pasaba."

# game/script.rpy:2096
translate spanish fishing_851fb996:

    # p2 "!!!"
    p2 "!!!"

# game/script.rpy:2107
translate spanish fishing_2d39591c:

    # p2 "Когда я ответил[p2_verb_a()] на поцелуй, Сайлас притянул меня ближе, я почувствовал[p2_verb_a()], как он перестал стесняться и его язык проник в мой рот."
    p2 "Cuando le devolví el beso, Silas me atrajo hacia él. Sentí que dejaba de contenerse cuando su lengua se deslizó dentro de mi boca."

# game/script.rpy:2111
translate spanish fishing_6d11f18a:

    # p2 "Он отстранился, но я все еще чувствовал[p2_verb_a()] его вкус на своих губах."
    p2 "Se apartó, pero aún podía sentir su sabor en mis labios."

# game/script.rpy:2112
translate spanish fishing_6a71a464:

    # s "Я так сильно тебя люблю..."
    s "Te quiero tanto..."

# game/script.rpy:2114
translate spanish fishing_df3adf35:

    # p2 "Он просунул руку под мою футболку и слегка сжал кожу."
    p2 "Deslizó su mano bajo mi camiseta y me acarició suavemente la piel."

# game/script.rpy:2115
translate spanish fishing_c5a722ec:

    # p2 "Боже... Похоже все идет к этому..."
    p2 "Dios... Parece que esto se está poniendo serio..."

# game/script.rpy:2119
translate spanish fishing_81fc83fa:

    # p2 "Сайлас продолжил сжимать мою кожу на боку и спине, затем притянул ближе и..."
    p2 "Silas seguía apretándome la piel del costado y la espalda, luego me acercó más a él y..."

# game/script.rpy:2120
translate spanish fishing_0542fe7f:

    # p2 "Сопение"
    p2 "Ronquidos."

# game/script.rpy:2121
translate spanish fishing_334b5c73:

    # p2 "Он уснул!?"
    p2 "¿¡Se quedó dormido!?"

# game/script.rpy:2122
translate spanish fishing_6972304a:

    # p2 "Какого черта!?"
    p2 "¿¡Qué demonios!?"

# game/script.rpy:2123
translate spanish fishing_0b69b953:

    # p2 "Теперь мне стыдно, что я на что-то надеял[p2_verb_as()]… Черт…"
    p2 "Ahora me da vergüenza haber esperado algo... ¡Maldición!..."

# game/script.rpy:2124
translate spanish fishing_e41cdd5b:

    # p2 "Ладно... Мне тоже пора спать..."
    p2 "Está bien... Yo también debería dormir..."

# game/script.rpy:2126
translate spanish fishing_493a4dfc:

    # p "Сайлас, подожди..."
    p "Silas, espera..."

# game/script.rpy:2127
translate spanish fishing_e652d6e7:

    # p "Я еще не готов[p2_verb_a()]..."
    p "Aún no estoy list[letra]..."

# game/script.rpy:2128
translate spanish fishing_b895f7d3:

    # s bshy2 "К чему?"
    s bshy2 "¿Para qué?"

# game/script.rpy:2129
translate spanish fishing_6786ed65:

    # p "Ну... Секс..."
    p "Bueno... Sexo..."

# game/script.rpy:2131
translate spanish fishing_b0b1d345:

    # s bshy3 "Я не это имел ввиду..."
    s bshy3 "No me refería a eso..."

# game/script.rpy:2133
translate spanish fishing_b32d925c:

    # extend "Я хотел просто... Почувствовать тебя рядом со мной..."
    extend "Solo quería... sentirte cerca de mí..."

# game/script.rpy:2134
translate spanish fishing_4496c54d:

    # p "а..."
    p "oh..."

# game/script.rpy:2135
translate spanish fishing_83c8ff9d:

    # p2 "Я СЕЙЧАС УМРУ ОТ СМУЩЕНИЯ"
    p2 "ME VOY A MORIR DE LA VERGÜENZA"

# game/script.rpy:2136
translate spanish fishing_c6b1a5ec:

    # p "Ладно, давай просто спать..."
    p "Vale, vamos a dormir..."

# game/script.rpy:2137
translate spanish fishing_4054ed49:

    # s "Ага."
    s "Sí."

# game/script.rpy:2140
translate spanish fishing_728f0f92:

    # p2 "Он снова обнял меня и уснул, а я еще долго не мог[p2_verb_la()] провалиться в сон..."
    p2 "Me volvió a abrazar y se quedó dormido, mientras que yo tardé mucho en conciliar el sueño..."

# game/script.rpy:2146
translate spanish fishing_f8c8ad1b:

    # p2 "Я почувствовал[p2_verb_a()] себя странно, словно не мог[p2_verb_la()] дышать от этого поцелуя, так что непроизвольно отстранил[p2_verb_as()]…"
    p2 "Me sentí rar[letra], como si no pudiera respirar por culpa de ese beso, así que me aparté sin pensarlo..."

# game/script.rpy:2147
translate spanish fishing_0346e4a6:

    # s "Все в порядке?"
    s "¿Está todo bien?"

# game/script.rpy:2148
translate spanish fishing_9800e834:

    # p2 "Не знаю, что ему сказать… Все слова пропали из моей головы."
    p2 "No sabía qué decirle... Todas las palabras desaparecieron de mi cabeza."

# game/script.rpy:2149
translate spanish fishing_000fd71c:

    # p "Давай уже спать..."
    p "Vamos a dormir..."

# game/script.rpy:2150
translate spanish fishing_a3b49cfa:

    # s "Ладно..."
    s "Vale..."

# game/script.rpy:2156
translate spanish fishing_ffc83ee5:

    # p2 "Я отвернул[p2_verb_as()] от него и попытал[p2_verb_as()] быстрее уснуть."
    p2 "Le di la espalda e intenté quedarme dormid[letra] lo más rápido que pude."

# game/script.rpy:2172
translate spanish fishing_de3a652f:

    # p2 "Я поцеловал[p2_verb_a()] его, Сайлас кажется на мгновение удивился, а затем углубил поцелуй. Его язык проскользнул между моих губ, захватывая мой рот. Я пытал[p2_verb_as()] успевать за его темпом, но проигрывал[p2_verb_a()] ему в настойчивости."
    p2 "Lo besé. Silas pareció sorprenderse por un momento, luego profundizó el beso. Su lengua se deslizó entre mis labios, tomando el control de mi boca. Intenté seguirle el ritmo, pero no podía igualar su intensidad."

# game/script.rpy:2173
translate spanish fishing_a86f7420:

    # p2 "Он обхватил мое лицо руками, его прикосновение было таким теплым и приятным, было сложно сопротивляться, я придвинул[p2_verb_as()] чуть ближе к нему."
    p2 "Me acarició el rostro con las manos. Su tacto era tan cálido y agradable que era difícil resistirse, y me acerqué un poco más a él."

# game/script.rpy:2174
translate spanish fishing_5c318ee7:

    # p2 "Внезапно что-то твердое прижалось к моему животу…"
    p2 "De repente, algo duro presionó contra mi estómago..."

# game/script.rpy:2178
translate spanish fishing_fb2631e4:

    # s "Прости... {w}Мне нужно немного успокоиться..."
    s "Lo siento... {w}Necesito calmarme un poco..."

# game/script.rpy:2179
translate spanish fishing_c8ea8a4a_1:

    # p "..."
    p "..."

# game/script.rpy:2180
translate spanish fishing_7253327c:

    # s bshy4 "Н-не жди меня, засыпай..."
    s bshy4 "N-no me esperes. Vete a dormir..."

# game/script.rpy:2181
translate spanish fishing_7d43aeda:

    # s "Сладких снов..."
    s "Dulces sueños..."

# game/script.rpy:2185
translate spanish fishing_59c3dadb:

    # p "Подожди, куда ты?"
    p "Espera, ¿a dónde vas?"

# game/script.rpy:2187
translate spanish fishing_7eb0709e:

    # s "В ванную...{w=0.5} Умыться...."
    s "Al baño...{w=0.5} A lavarme la... cara... claro..."

# game/script.rpy:2189
translate spanish fishing_2b68788e:

    # p "Ладно... "
    p "Vale..."

# game/script.rpy:2192
translate spanish fishing_36a2324d:

    # p2 "Я понятия не имел[p2_verb_a()], как реагировать, сердце бешено стучало, мне хотелось провалиться под землю от неловкости этой ситуации..."
    p2 "No tenía ni idea de cómo reaccionar. Me latía el corazón a mil y quería hundirme en el suelo de lo incómoda que era toda la situación..."

# game/script.rpy:2193
translate spanish fishing_e4dd76b6:

    # p2 "Сайлас не долго не возвращался. Я начал[p2_verb_a()] медленно погружаться в сон."
    p2 "Silas no volvió en un rato. Empecé a quedarme dormid[letra] lentamente."

# game/script.rpy:2202
translate spanish fishing_20826dbd:

    # p2 "Я слегка отодвинул[p2_verb_as()], кажется он понял мой намек."
    p2 "Me alejé un poco. Pareció entender la indirecta."

# game/script.rpy:2203
translate spanish fishing_54b69a2a:

    # s "Спокойной ночи."
    s "Buenas noches."

# game/script.rpy:2204
translate spanish fishing_2166ac58:

    # p "Тебе тоже сладких снов..."
    p "Dulces sueños para ti también..."

# game/script.rpy:2216
translate spanish fishing_abdaa8bc:

    # dream "[p]"
    dream "[p]"

# game/script.rpy:2217
translate spanish fishing_26e4517e:

    # dream "[p]!"
    dream "¡[p]!"

# game/script.rpy:2218
translate spanish fishing_e963de7d:

    # dream "Сайлас?"
    dream "¿Silas?"

# game/script.rpy:2221
translate spanish fishing_85c6874e:

    # dream "Где ты?"
    dream "¿Dónde estás?"

# game/script.rpy:2224
translate spanish fishing_8d4eceb6:

    # dream "А!?"
    dream "¿¡Ah!?"

# game/script.rpy:2230
translate spanish fishing_1d3db150:

    # dream "Пойдем со мной."
    dream "Ven conmigo."

# game/script.rpy:2231
translate spanish fishing_65175e32:

    # dream "Я под водой, но… Почему тут... Не страшно?"
    dream "Estoy bajo el agua, pero... ¿por qué no... da miedo aquí?"

# game/script.rpy:2232
translate spanish fishing_11be0a89:

    # dream "Потому что я рядом."
    dream "Porque estoy aquí."

# game/script.rpy:2233
translate spanish fishing_e1eb0386:

    # dream "Мне сложно дышать..."
    dream "Cuesta respirar..."

# game/script.rpy:2236
translate spanish fishing_6642e769:

    # dream "Это нормально. Все будет в порядке."
    dream "Está bien. Todo estará bien."

# game/script.rpy:2237
translate spanish fishing_75c58566:

    # dream "Сайлас! Мне правда сложно дышать!"
    dream "¡Silas! ¡De verdad cuesta respirar!"

# game/script.rpy:2239
translate spanish fishing_b8321b10:

    # dream "Я не могу дышать... Но мне так спокойно..."
    dream "No puedo respirar... Pero me siento tan tranquil[letra]..."

# game/script.rpy:2249
translate spanish fishing_f79efa53:

    # p2 "Ох... Что это было... Почему Сайлас был русалом? Ну и чушь... "
    p2 "Ugh... Qué fue eso... ¿Por qué Silas era un tritón? Qué tontería..."

# game/script.rpy:2250
translate spanish fishing_a892b792:

    # p2 "Он милый, когда спит... "
    p2 "Se ve lindo cuando duerme..."

# game/script.rpy:2262
translate spanish fishing_d809e4a5:

    # p2 "Я погладил[p2_verb_a()] его по голове и он проснулся. "
    p2 "Le acaricié la cabeza y se despertó."

# game/script.rpy:2279
translate spanish fishing_5eaa50e9:

    # s "Что ты делаешь?"
    s "¿Qué haces?"

# game/script.rpy:2281
translate spanish fishing_f97fc28e:

    # p "Ээ... Твои волосы растрепались, я хотел[p2_verb_a()] их пригладить!!"
    p "Eh... Tenías el pelo alborotado, ¡¡y quería alisarlo!!"

# game/script.rpy:2292
translate spanish fishing_c6974621:

    # s "Сделать тебе кофе?"
    s "¿Quieres que te haga café?"

# game/script.rpy:2293
translate spanish fishing_dbfd0601:

    # p "Да... Пожалуйста..."
    p "Sí... Por favor..."

# game/script.rpy:2328
translate spanish fishing_31d3999d:

    # s "Зачем ты так сделал[p2_verb_a()]?"
    s "¿Por qué hiciste eso?"

# game/script.rpy:2331
translate spanish fishing_bd2a4400:

    # p2 "Он поцеловал меня, а когда я попытал[p2_verb_as()] ответить, он дунул мне в рот, от чего у меня даже дыхание сперлось. "
    p2 "Me besó, y cuando intenté devolverle el beso, me sopló en la boca, dejándome sin aliento."

# game/script.rpy:2341
translate spanish fishing_40e6a11f:

    # p2 "Он потянулся и начал трепать мою щеку"
    p2 "Se inclinó hacia mí y empezó a apretarme la mejilla."

# game/script.rpy:2342
translate spanish fishing_99241161:

    # p "Сайлас, прекрати!!"
    p "¡¡Silas, para!!"

# game/script.rpy:2343
translate spanish fishing_87bca2fb:

    # s "Да ладно, я должен хоть как-то отомстить!"
    s "¡Vamos, tengo que vengarme de alguna manera!"

# game/script.rpy:2344
translate spanish fishing_2a3e6d2f:

    # p "Думаю этого достаточно..."
    p "Creo que ya es suficiente..."

# game/script.rpy:2345
translate spanish fishing_0b547677:

    # s sleepnose "Хорошо, прекращаю."
    s sleepnose "Vale, pararé."

# game/script.rpy:2348
translate spanish fishing_57243bb6:

    # s "Пойдем завтракать. "
    s "Vamos a desayunar."

# game/script.rpy:2355
translate spanish fishing_53159bba:

    # p2 "Я молча наблюдал[p2_verb_a()] за тем, как он мирно спит. "
    p2 "Lo observé en silencio dormir pacíficamente."

# game/script.rpy:2368
translate spanish fishing_cafa4b32:

    # s "Нравится смотреть, как я сплю?"
    s "¿Te gusta verme dormir?"

# game/script.rpy:2369
translate spanish fishing_e7f70748:

    # p "Ну.. Я просто..."
    p "Bueno... Solo estaba..."

# game/script.rpy:2373
translate spanish fishing_4de3b327:

    # p2 "Я издал[p2_verb_a()] сдавленный звук неожиданности, но расслабил[p2_verb_as()] в его объятиях. "
    p2 "Dejé escapar un pequeño grito ahogado de sorpresa, pero me relajé en sus brazos."

# game/script.rpy:2374
translate spanish fishing_5002959f:

    # s "Ты вкусно пахнешь…"
    s "Hueles bien..."

# game/script.rpy:2375
translate spanish fishing_86556749:

    # p "Спасибо..?"
    p "¿Gracias..?"

# game/script.rpy:2376
translate spanish fishing_902121a8:

    # s "Пойдем завтракать?"
    s "¿Quieres ir a desayunar?"

# game/script.rpy:2377
translate spanish fishing_1c2798be:

    # p "Ага, я проголодал[p2_verb_as()] от того, что спал[p2_verb_a()]."
    p "Sí. Me entró hambre de tanto dormir."

# game/script.rpy:2385
translate spanish fishing_1961dd8f:

    # p "Ты так хорошо готовишь. Я чувствую себя бесполезн[p2_verb_oy_iim()], дай мне какое-то поручение."
    p "Eres muy buen cocinero. Me siento inútil, así que dame algo que hacer."

# game/script.rpy:2386
translate spanish fishing_7ce26d39:

    # s "Тебе не нужно ничего делать, я ведь могу прекрасно справиться сам, ты бы мог[p2_verb_la()] просто отдыхать и наслаждаться жизнью."
    s "No tienes que hacer nada. Puedo encargarme perfectamente yo solo. Podrías simplemente relajarte y disfrutar de la vida."

# game/script.rpy:2387
translate spanish fishing_0839e6d3:

    # s "Но если так хочешь помочь, то взбей сливки."
    s "Pero si de verdad quieres ayudar, bate la crema."

# game/script.rpy:2388
translate spanish fishing_e1cabc53:

    # p "О, хорошо, как?"
    p "Oh, vale. ¿Cómo?"

# game/script.rpy:2389
translate spanish fishing_9703ad5f:

    # s "Добавь в миску сливки, затем сахар и взбей до пышной массы."
    s "Pon la crema en un bol, luego el azúcar, y bátela hasta que esté esponjosa."

# game/script.rpy:2390
translate spanish fishing_7410eea5:

    # p "Понял[p2_verb_a()]."
    p "Entendido."

# game/script.rpy:2399
translate spanish fishing_28732d07:

    # s "Хорошо получилось, ты молодец."
    s "Ha quedado bien. Buen trabajo."

# game/script.rpy:2406
translate spanish fishing_9dbd3526:

    # s "Что? Хочешь быть на месте этого венчика?"
    s "¿Qué? ¿Quieres ocupar el lugar de esas varillas?"

# game/script.rpy:2408
translate spanish fishing_c8bc926e:

    # p "САЙЛАС!!!"
    p "¡¡¡SILAS!!!"

# game/script.rpy:2409
translate spanish fishing_a38c684c:

    # s msly2 "Просто шучу."
    s msly2 "Solo bromeaba."

# game/script.rpy:2410
translate spanish fishing_f8fa6e0e:

    # p "Давай уже есть."
    p "Comamos ya."

# game/script.rpy:2422
translate spanish fishing_19012e5a:

    # p2 "Я уже начинаю привыкать к его вкусной еде."
    p2 "Ya me estoy empezando a acostumbrar a su deliciosa comida."

# game/script.rpy:2423
translate spanish fishing_50f95cc5:

    # p2 "В городе такого повара с руками и ногами бы забрали себе дорогие рестораны."
    p2 "En la ciudad, los restaurantes de lujo se pelearían por un cocinero como él en un abrir y cerrar de ojos."

# game/script.rpy:2425
translate spanish fishing_6014f1f3:

    # s "Сегодня пойдем на речку, будем бороться с твоим страхом."
    s "Hoy iremos al río. Trabajaremos en superar tu miedo."

# game/script.rpy:2426
translate spanish fishing_6001a7a8:

    # p "Я уже передумал[p2_verb_a()]..."
    p "Ya he cambiado de opinión..."

# game/script.rpy:2427
translate spanish fishing_abc51ed1:

    # s kcalm "Неа, ты не отвертишься, мы пойдем."
    s kcalm "No, no te vas a librar. Vamos."

# game/script.rpy:2428
translate spanish fishing_c954745f:

    # s "Сделай первый шаг."
    s "Da el primer paso."

# game/script.rpy:2429
translate spanish fishing_d4c3081f:

    # p "Мх..."
    p "Mgh..."

# game/script.rpy:2430
translate spanish fishing_7b2cc7b6:

    # p2 "После завтрака мы направились на ферму. "
    p2 "Después del desayuno, nos dirigimos a la granja."

# game/script.rpy:2442
translate spanish fishing_8df020d8:

    # s "Сегодня сложный день для тебя, давай хоть с делами помогу."
    s "Hoy va a ser duro para ti, así que al menos déjame ayudar con las tareas."

# game/script.rpy:2443
translate spanish fishing_126283aa:

    # p2 "Он прав... Стоит ли ему дать какие-то дела или все на него переложить?"
    p2 "Tiene razón... ¿Debería asignarle algunas tareas o dejarle todo a él?"

# game/script.rpy:2461
translate spanish fishing_bca0d638:

    # "Можешь выпустить животных."
    "Puedes soltar a los animales."

# game/script.rpy:2463
translate spanish fishing_b4ccaca4:

    # "и выпустить животных."
    "y soltar a los animales."

# game/script.rpy:2469
translate spanish fishing_11053dcc_1:

    # "Можешь собрать яйца."
    "Puedes recoger los huevos."

# game/script.rpy:2471
translate spanish fishing_6d3cd8b1_1:

    # "И собрать яйца."
    "Y recoger los huevos."

# game/script.rpy:2478
translate spanish fishing_3b66fdf0_1:

    # "Можешь накормить скот."
    "Puedes dar de comer a los animales."

# game/script.rpy:2480
translate spanish fishing_f46802a1_1:

    # "И покормить скот."
    "Y dar de comer a los animales."

# game/script.rpy:2489
translate spanish fishing_50c82757:

    # s "Рад, что ты доверяешь мне это! Иди отдохни, но не смей передумать идти к речке!"
    s "¡Me alegra que confíes en mí para esto! Ve a descansar, ¡pero no te atrevas a cambiar de opinión sobre ir al río!"

# game/script.rpy:2491
translate spanish fishing_99e07518_1:

    # p "На этом все, сделаешь это?"
    p "Eso es todo. ¿Puedes hacer eso?"

# game/script.rpy:2492
translate spanish fishing_a24e011d:

    # s "Конечно! "
    s "¡Por supuesto!"

# game/script.rpy:2493
translate spanish fishing_b64fd888_1:

    # p "Спасибо."
    p "Gracias."

# game/script.rpy:2494
translate spanish fishing_d2e7b0d2:

    # p "Я улыбнул[p2_verb_as()] ему."
    p "Le sonreí."

# game/script.rpy:2496
translate spanish fishing_7c32c7c0:

    # p "Хочу сделать все сам[p2_verb_a()]"
    p "Quiero hacerlo todo yo mism[letra]."

# game/script.rpy:2497
translate spanish fishing_59048148:

    # s "Ладно, раз ты так хочешь..."
    s "Vale, si eso es lo que quieres..."

# game/script.rpy:2505
translate spanish fishing_972bba4b:

    # p2 "Сайлас пошел заниматься делами, а я думал[p2_verb_a()] о том, стоит ли вообще пытаться побороть страх? {w}Что если я поймаю паническую атаку и умру от страсса?."
    p2 "Silas se fue a hacer las tareas, mientras yo me preguntaba si siquiera debería intentar superar mi miedo. {w}¿Y si tengo un ataque de pánico y me muero del estrés?"

# game/script.rpy:2513
translate spanish fishing_79886a7b:

    # p "Так, нужно всех накормить."
    p "Bien, tengo que dar de comer a todos."

# game/script.rpy:2517
translate spanish fishing_a270f701:

    # p "Сегодня солнечный день, надеюсь животным не будет слишком жарко."
    p "Hoy hace sol. Espero que los animales no pasen demasiado calor."

# game/script.rpy:2523
translate spanish fishing_95521891:

    # p "Интересно, сколько cегодня будет яичек."
    p "Me pregunto cuántos huevos habrá hoy."

# game/script.rpy:2527
translate spanish fishing_190866b8:

    # p2 "Мне хотелось, чтобы дела тянулись подольше, чтобы отсрочить борьбу со страхом..."
    p2 "Quería que las tareas tardaran más, solo para posponer el momento de enfrentarme a mi miedo..."

# game/script.rpy:2532
translate spanish fishing_4765946d:

    # s "Ну что, пойдем?"
    s "Entonces, ¿vamos?"

# game/script.rpy:2533
translate spanish fishing_5b06de7a:

    # p "Ага..."
    p "Sí..."

# game/script.rpy:2540
translate spanish fishing_7adbd8f5:

    # p2 "Я побрел[p2_verb_as()] за Сайласом, но понял[p2_verb_a()], что мы идем в другую сторону. "
    p2 "Caminé con dificultad detrás de Silas, pero luego me di cuenta de que íbamos en otra dirección."

# game/script.rpy:2541
translate spanish fishing_c6f4e1a5:

    # p "Сайлас, куда мы идем?"
    p "Silas, ¿a dónde vamos?"

# game/script.rpy:2542
translate spanish fishing_23157d70:

    # s "Сначала хочу показать тебе еще одно место."
    s "Quiero enseñarte un lugar más primero."

# game/script.rpy:2550
translate spanish fishing_0cd3d8c2:

    # p2 "Внутри стало тревожно, когда я увидел[p2_verb_a()] полуразрушенный сарай. "
    p2 "Sentí cómo un nudo de ansiedad se me formaba en el estómago al ver el granero medio derruido."

# game/script.rpy:2552
translate spanish fishing_bbaef2b8:

    # s "Ты помнишь это место?"
    s "¿Te acuerdas de este lugar?"

# game/script.rpy:2553
translate spanish fishing_5dd0f79f:

    # p "Нет, но чувство странное... Как будто это место меня пугает..."
    p "No, pero se siente extraño... Como si este lugar me diera miedo..."

# game/script.rpy:2554
translate spanish fishing_e699ca88:

    # s scalm "Неудивительно, Я пугал тебя, будто тут живут призраки, ты очень боял[p2_verb_as()], наверное, страх остался."
    s scalm "No me extraña. Solía asustarte diciendo que aquí vivían fantasmas. Estabas aterrorizad[letra], así que quizás el miedo se quedó."

# game/script.rpy:2555
translate spanish fishing_f5306169:

    # p "Наверное..."
    p "Quizás..."

# game/script.rpy:2556
translate spanish fishing_43b50e18:

    # s ssad "И больше ничего не вспоминаешь? "
    s ssad "¿Y no recuerdas nada más?"

# game/script.rpy:2557
translate spanish fishing_f025272e:

    # p "Нет... Пошли отсюда..."
    p "No... Vámonos de aquí..."

# game/script.rpy:2558
translate spanish fishing_12533e97:

    # s scalm "Ладно, ладно, уходим."
    s scalm "Vale, vale. Nos vamos."

# game/script.rpy:2566
translate spanish fishing_71235143:

    # s "Начнем с малого, потрогай воду."
    s "Empezaremos por lo pequeño. Toca el agua."

# game/script.rpy:2575
translate spanish touch_the_water_32e1f402:

    # p2 "Я смотрел[p2_verb_a()] на реку, она словно уставилась на меня в ответ. Желание взаимодействовать с ней пропадало, но я долж[p2_verb_na_en()] был[p2_verb_a()] это сделать… Хотя бы потрогать…"
    p2 "Me quedé mirando el río, y sentí como si él me mirara a mí. Cualquier deseo de interactuar con él desapareció, pero tenía que hacer esto... Al menos tocarlo..."

# game/script.rpy:2576
translate spanish touch_the_water_3a17de63:

    # p "Ладно... Я могу это сделать..."
    p "Vale... Puedo hacer esto..."

# game/script.rpy:2581
translate spanish touch_the_water_4d6333c4:

    # p "Прохладная..."
    p "Está fresca..."

# game/script.rpy:2582
translate spanish touch_the_water_d71dda9e:

    # p "Это не кажется таким страшным."
    p "No da tanto miedo."

# game/script.rpy:2587
translate spanish touch_the_water_81113db5:

    # p2 "Во мне проснулась уверенность и я опустил[p2_verb_a()] ноги в воду."
    p2 "Un poco de confianza despertó en mí, y metí los pies en el agua."

# game/script.rpy:2588
translate spanish touch_the_water_141c3fdd:

    # p "Это даже приятно..."
    p "La verdad es que está bien..."

# game/script.rpy:2589
translate spanish touch_the_water_47851b6f:

    # s "Готов[p2_verb_a()] пойти дальше?"
    s "¿List[letra] para avanzar un poco más?"

# game/script.rpy:2590
translate spanish touch_the_water_09f9f7db:

    # s "Не беспокойся, я буду рядом, с тобой ничего плохого не случится."
    s "No te preocupes. Estaré justo aquí. No te pasará nada malo."

# game/script.rpy:2600
translate spanish go_into_the_water_c0861436:

    # p "Хорошо, я зайду по пояс…"
    p "Está bien, me meteré hasta la cintura..."

# game/script.rpy:2601
translate spanish go_into_the_water_f07ecbec:

    # p2 "Я повернул[p2_verb_as()] к Сайласу и подавил[p2_verb_as()] воздухом от того, что увидел[p2_verb_a()]."
    p2 "Me volví hacia Silas y me quedé sin aliento al ver lo que vi."

# game/script.rpy:2607
translate spanish go_into_the_water_78f903bc:

    # p "Сайлас..?"
    p "¿Silas..?"

# game/script.rpy:2608
translate spanish go_into_the_water_5fba86b2:

    # s rhappy "Что? Стесняешься? Можешь не снимать футболку, она все равно быстро высохнет."
    s rhappy "¿Qué? ¿Te da vergüenza? No tienes que quitarte la camisa. De todos modos se secará rápido."

# game/script.rpy:2612
translate spanish go_into_the_water_f0b055dc:

    # p2 "Я раздел[p2_verb_as()] до нижнего белья и футболки, чувствовал[p2_verb_a()] себя немного неловко."
    p2 "Me desnudé hasta quedarme en ropa interior y camisa, sintiéndome un poco incómod[letra]."

# game/script.rpy:2613
translate spanish go_into_the_water_91b12bbc:

    # s rcalm "Пойдем."
    s rcalm "Vamos."

# game/script.rpy:2620
translate spanish go_into_the_water_80b4dfa4:

    # p2 "Я крепко держал[p2_verb_as()] за него, боясь отпустить, вдруг где-то под ногами окажется обрыв, но… {w}Это не было настолько страшно, как я себе представлял[p2_verb_a()].{w} Я забыл[p2_verb_a()] о том, что в воде может быть приятно."
    p2 "Me aferré a él con fuerza, con miedo a soltarlo por si había un desnivel repentino bajo mis pies, pero... {w}No daba tanto miedo como me imaginaba.{w} Había olvidado que estar en el agua podía sentirse bien."

# game/script.rpy:2621
translate spanish go_into_the_water_f6f71c4b:

    # s "Ну как тебе?"
    s "¿Y bien? ¿Qué tal?"

# game/script.rpy:2622
translate spanish go_into_the_water_c7d42f38:

    # p "Это хорошо…"
    p "Está bien..."

# game/script.rpy:2624
translate spanish go_into_the_water_7f287ccf:

    # p "Это правда не так страшно..."
    p "De verdad no da tanto miedo..."

# game/script.rpy:2625
translate spanish go_into_the_water_9516f2f4:

    # p2 "Я шагнул[p2_verb_a()] дальше в воду, она окутывала мое тело. тревога присутствовала, но пока я чувствовал[p2_verb_a()] дно под ногами и руку Сайласа, паника не появлялась."
    p2 "Avancé más en el agua, dejando que envolviera mi cuerpo. La ansiedad seguía ahí, pero mientras pudiera sentir el fondo bajo mis pies y la mano de Silas en la mía, el pánico no llegaba."

# game/script.rpy:2626
translate spanish go_into_the_water_6a9b8513:

    # s "Я рад, что ты поборол[p2_verb_a()] страх."
    s "Me alegra que te hayas enfrentado a tu miedo."

# game/script.rpy:2627
translate spanish go_into_the_water_7b123890:

    # p "Ну не то, чтобы поборол[p2_verb_a()], но стараюсь...."
    p "Bueno, no diría que lo enfrenté por completo, pero lo estoy intentando..."

# game/script.rpy:2632
translate spanish go_into_the_water_d48d060f:

    # p2 "Внезапно, я поскользнул[p2_verb_as()], но он поймал меня."
    p2 "De repente, resbalé, pero él me atrapó."

# game/script.rpy:2633
translate spanish go_into_the_water_8c2fbc66:

    # s "Я так горд за тебя."
    s "Estoy muy orgulloso de ti."

# game/script.rpy:2634
translate spanish go_into_the_water_e62fe7ed:

    # p "С-спасибо..."
    p "G-gracias..."

# game/script.rpy:2635
translate spanish go_into_the_water_fb6d01c9:

    # p2 "Он крепко держал меня за талию, поглижива кожу под мокрой футболкой большими пальцами, и теперь это было по-настоящему неловко и смущающе..."
    p2 "Me sujetó con fuerza por la cintura, sus pulgares acariciando la piel bajo mi camisa mojada, y ahora sí que era verdaderamente incómodo y vergonzoso..."

# game/script.rpy:2636
translate spanish go_into_the_water_d8871cb9:

    # p2 "Мне становилось холодно, так что мы решили выйти на берег."
    p2 "Empezaba a tener frío, así que decidimos volver a la orilla."

# game/script.rpy:2651
translate spanish coast_aa12bbf8:

    # p2 "Сайлас развел костер, чтобы я согрел[p2_verb_as()]. Мы долго сидели на берегу, болтали, я рассматривал[p2_verb_a()] муравьев на земле, они так старательно строили свою цивилизацию."
    p2 "Silas encendió una hoguera para que me calentara. Nos sentamos en la orilla un buen rato, hablando, mientras yo observaba a las hormigas en el suelo, trabajando tan duro para construir su pequeña civilización."

# game/script.rpy:2652
translate spanish coast_ec5214ef:

    # p2 "Мы болтали о жизни в деревне, Сайлас, кажется, старался переманить меня из города в деревню."
    p2 "Hablamos sobre la vida en el pueblo. Parecía que Silas intentaba convencerme de que me fuera de la ciudad."

# game/script.rpy:2661
translate spanish coast_374ebbf8:

    # p2 "Время мчалось незаметно, стало темнеть."
    p2 "El tiempo pasó desapercibido y empezó a oscurecer."

# game/script.rpy:2664
translate spanish coast_2f236d03:

    # s "Все как в тот день."
    s "Es igual que aquel día."

# game/script.rpy:2665
translate spanish coast_4ee1ccd3:

    # p "Какой день?"
    p "¿Qué día?"

# game/script.rpy:2666
translate spanish coast_1f37f24b:

    # s "Тот, когда мы впервые поцеловались."
    s "El día que nos besamos por primera vez."

# game/script.rpy:2677
translate spanish coast_2346efdc:

    # p2 "Он придвинулся ближе и поцеловал меня. Я поцеловал[p2_verb_a()] его в ответ, это начинало казаться таким естественным."
    p2 "Se acercó y me besó. Le devolví el beso. Empezaba a sentirse tan natural..."

# game/script.rpy:2687
translate spanish coast_a6de5a69:

    # p2 "Он придвинулся ближе и приобнял меня, я положил[p2_verb_a()] голову на его плечо."
    p2 "Se acercó más y me pasó un brazo por los hombros, y apoyé la cabeza en su hombro."

# game/script.rpy:2698
translate spanish coast_df9b585d:

    # s "Ты уже чувствуешь ко мне что-то, верно?"
    s "Ahora sientes algo por mí, ¿verdad?"

# game/script.rpy:2704
translate spanish coast_1acd4a81:

    # p2 "Его вопрос застал меня врасплох, но я не мог[p2_verb_a()] отрицать, что чувства начали зарождаться во мне."
    p2 "Su pregunta me pilló por sorpresa, pero no podía negar que habían empezado a crecer sentimientos dentro de mí."

# game/script.rpy:2710
translate spanish coast_aebb800d:

    # p2 "Ага, конечно, кого я обманываю. "
    p2 "Sí, por supuesto. ¿A quién quiero engañar?"

# game/script.rpy:2711
translate spanish coast_fc970e35:

    # p2 "Я чувствую к нему что-то, я целовал[p2_verb_a()] его."
    p2 "Sí que siento algo por él. Lo besé."

# game/script.rpy:2721
translate spanish feel_love_cbf6ee6b:

    # p "Да. Я начинаю что-то чувствовать к тебе."
    p "Sí. Estoy empezando a sentir algo por ti."

# game/script.rpy:2722
translate spanish feel_love_2b23802c:

    # s "Больше чем дружба..?"
    s "¿Más que amistad..?"

# game/script.rpy:2723
translate spanish feel_love_b5ee21cc:

    # p "Больше."
    p "Más."

# game/script.rpy:2727
translate spanish feel_love_578aaa48:

    # p "Сайлас?? Почему ты плачешь??"
    p "¿¿Silas?? ¿¿Por qué estás llorando??"

# game/script.rpy:2728
translate spanish feel_love_7769ab96:

    # s "Я... Я уже не верил, что ты сможешь полюбить меня после того, что произошло..."
    s "Yo... No creía que pudieras llegar a quererme después de lo que pasó..."

# game/script.rpy:2729
translate spanish feel_love_a7b5ac88:

    # p "О чем ты? Что произошло? "
    p "¿De qué estás hablando? ¿Qué pasó?"

# game/script.rpy:2740
translate spanish feel_love_72e5e8bc:

    # s "Ну... Я ведь... "
    s "Bueno... Yo..."

# game/script.rpy:2741
translate spanish feel_love_33118c26:

    # s "Не спас тебя тогда..."
    s "En aquel entonces no te salvé..."

# game/script.rpy:2742
translate spanish feel_love_1d39454d:

    # p "Боже, ты переживаешь об этом?"
    p "Dios, ¿es eso lo que te ha estado preocupando?"

# game/script.rpy:2743
translate spanish feel_love_2bfe4fe4:

    # p "Я бы никогда не стал[p2_verb_a()] винить тебя."
    p "Nunca te culparía."

# game/script.rpy:2755
translate spanish feel_love_64af0d1e:

    # p2 "Он начал не просто плакать, а рыдать."
    p2 "No fue que simplemente se puso a llorar. Se puso a sollozar."

# game/script.rpy:2756
translate spanish feel_love_70b18919:

    # p "Сайлас?.."
    p "¿Silas?.."

# game/script.rpy:2758
translate spanish feel_love_d71c3b2a:

    # s "Это... Это от счастья..."
    s "Es... Es porque estoy feliz..."

# game/script.rpy:2768
translate spanish feel_love_e5afe864:

    # p2 "Он плакал несколько минут, я пытал[p2_verb_as()] его отвлечь."
    p2 "Lloró durante varios minutos mientras yo intentaba distraerlo."

# game/script.rpy:2769
translate spanish feel_love_e1010476:

    # p "Сайлас, нам уже пора идти на ферму..."
    p "Silas, es hora de que volvamos a la granja..."

# game/script.rpy:2770
translate spanish feel_love_3b6d0ec6:

    # s "Д-да... Пошли..."
    s "S-sí... Vámonos..."

# game/script.rpy:2772
translate spanish feel_love_98c221cf:

    # p2 "По пути он так крепко держал меня за руку, я чувствовал[p2_verb_a()] как он дрожит."
    p2 "De camino de regreso, me sostuvo la mano con tanta fuerza que podía sentirlo temblar."

# game/script.rpy:2776
translate spanish feel_love_9108845c:

    # p2 "Вернувшись, мы быстро сделали дела по ферме и сразу легли спать, конечно вместе. Сайлас успокоился и нежно обнял меня, слегка сжимая ладонями."
    p2 "Cuando volvimos, terminamos rápido las tareas de la granja y nos fuimos directos a la cama. Juntos, por supuesto. Silas se había calmado y me abrazaba con suavidad, apretándome ligeramente con sus manos."

# game/script.rpy:2777
translate spanish feel_love_69d7d709:

    # p2 "Он придвинулся ближе и поцеловал меня в шею, у меня пошли мурашки по телу."
    p2 "Se acercó más y besó mi cuello, enviando escalofríos por mi piel."

# game/script.rpy:2779
translate spanish feel_love_478b7135:

    # p2 "Я ожидал[p2_verb_a()] его дальнейших действий, но... Он просто продолжал обнимать меня. "
    p2 "Esperaba que hiciera algo más, pero... simplemente siguió abrazándome."

# game/script.rpy:2780
translate spanish feel_love_72df4747:

    # p2 "Я долж[p2_verb_na_en()] был[p2_verb_a()] взять все в свои руки."
    p2 "Tuve que tomar la iniciativa."

# game/script.rpy:2792
translate spanish feel_love_68aa9b38:

    # p2 "Положив руку на его щеку, я притянул[p2_verb_a()] его ближе и поцеловал[p2_verb_a()]. Он долго не думал и ответил на поцелуй, углубляя его."
    p2 "Le puse una mano en la mejilla, lo acerqué hacia mí y lo besé. No tardó mucho en devolverme el beso y hacerlo más intenso."

# game/script.rpy:2793
translate spanish feel_love_a583e014:

    # p2 "Почувствовав себя смел[p2_verb_oy_iim()], я потянул[p2_verb_as()] к его трусам."
    p2 "Sintiéndome valiente, le quité la ropa interior"

# game/script.rpy:2798
translate spanish feel_love_834fabd6:

    # s "Ч-что ты делаешь..?"
    s "¿¿Q-qué estás haciendo..??"

# game/script.rpy:2799
translate spanish feel_love_77a950d0:

    # p "Сайлас... Мы не дети, ты знаешь, чего я хочу."
    p "Silas... Ya no somos niños. Sabes lo que quiero."

# game/script.rpy:2800
translate spanish feel_love_1c1eeabc:

    # p "Я хочу стать ближе."
    p "Quiero estar más cerca de ti."

# game/script.rpy:2801
translate spanish feel_love_a9891848:

    # s "Ты уверен[p2_verb_na()], что готов[p2_verb_a()]..?"
    s "¿Estás segur[letra] de que estás list[letra]..?"

# game/script.rpy:2802
translate spanish feel_love_ca1d7047:

    # p "Да, я полностью уверен[p2_verb_na()]."
    p "Sí. Estoy completamente segur[letra]."

# game/script.rpy:2803
translate spanish feel_love_9f710e28:

    # s bsex "Хорошо, тогда я..."
    s bsex "Vale, entonces voy a..."

# game/script.rpy:2810
translate spanish feel_love_1582bb4d:

    # p2 "После произошедшего, у меня немного дрожали руки, но мне было так хорошо..."
    p2 "Después de lo que pasó, me temblaban un poco las manos, pero me sentía tan bien..."

# game/script.rpy:2813
translate spanish feel_love_1d519e61:

    # p2 "Сердце билось ровно, сон медленно захватывал мой разум, я не стал[p2_verb_a()] сопротивляться."
    p2 "Mi corazón latía con regularidad. El sueño se apoderó poco a poco de mi mente, y no intenté resistirme."

# game/script.rpy:2818
translate spanish dont_feel_love_11981fdb:

    # p "Ну... Я не могу понять свои чувства... "
    p "Bueno... No logro entender mis sentimientos..."

# game/script.rpy:2822
translate spanish dont_feel_love_5f25f4c7:

    # s "Почему..?{w} Почему ты не можешь просто полюбить меня..?"
    s "¿Por qué..?{w} ¿Por qué no puedes simplemente amarme..?"

# game/script.rpy:2823
translate spanish dont_feel_love_604ce075:

    # p2 "Я почувствовал[p2_verb_a()] вину, которая сжигала меня изнутри, но я хотел[p2_verb_a()] быть чест[p2_verb_na_en()] с ним..."
    p2 "Sentí que la culpa me quemaba por dentro, pero quería ser honest[letra] con él..."

# game/script.rpy:2824
translate spanish dont_feel_love_98f8e426:

    # s "Зачем ты так близко подпускаешь меня, чтобы потом отвергнуть..?"
    s "¿Por qué me dejas acercarme tanto solo para rechazarme después..?"

# game/script.rpy:2825
translate spanish dont_feel_love_5f76ef4f:

    # p "Сайлас... Мы все еще друзья... Просто мне нужно больше времени, чтобы осознать свои чувства."
    p "Silas... Seguimos siendo amigos... Solo necesito más tiempo para entender mis sentimientos."

# game/script.rpy:2826
translate spanish dont_feel_love_cee082c3:

    # s "Я понимаю, но..."
    s "Lo entiendo, pero..."

# game/script.rpy:2827
translate spanish dont_feel_love_ad6d433a:

    # s "{size=20}Все должно быть не так...{/size}"
    s "{size=20}Esto no debería ser así...{/size}"

# game/script.rpy:2828
translate spanish dont_feel_love_5abe698d:

    # p2 "Он произнес это так тихо, словно это его внутренний голос вырвался наружу."
    p2 "Lo dijo tan bajo, como si su voz interior se le hubiera escapado."

# game/script.rpy:2829
translate spanish dont_feel_love_f5d06bfb:

    # s "Нам пора возвращаться."
    s "Deberíamos volver."

# game/script.rpy:2830
translate spanish dont_feel_love_3ae7030b:

    # p "Ага, ты прав. "
    p "Sí, tienes razón."

# game/script.rpy:2837
translate spanish dont_feel_love_a3a11a1e:

    # p2 "Мы затушили костер и направились к ферме. Сайлас был подозрительно тихим, мое чувство вины нарастало."
    p2 "Apagamos el fuego y volvimos a la granja. Silas estaba sospechosamente callado, y mi culpa no dejaba de crecer."

# game/script.rpy:2843
translate spanish dont_feel_love_6251e7b1:

    # p2 "Когда мы вернулись на ферму, Сайлас даже не посмотрел на меня."
    p2 "Cuando llegamos a la granja, Silas ni siquiera me miró."

# game/script.rpy:2844
translate spanish dont_feel_love_fce9434f:

    # s "Я переночую у себя."
    s "Esta noche dormiré en mi casa."

# game/script.rpy:2848
translate spanish dont_feel_love_f0bef273:

    # p2 "Я бы не выдержал[p2_verb_a()] еще хоть минуты этого напряженного молчания, думаю нам стоит провести ночь раздельно."
    p2 "No habría aguantado ni un minuto más de ese silencio tenso. Creo que deberíamos pasar la noche separados."

# game/script.rpy:2849
translate spanish dont_feel_love_03ff076b:

    # p "Да, я думаю тебе лучше пойти к себе."
    p "Sí, creo que deberías irte a casa."

# game/script.rpy:2850
translate spanish dont_feel_love_54b69a2a:

    # s "Спокойной ночи."
    s "Buenas noches."

# game/script.rpy:2851
translate spanish dont_feel_love_c3c84991:

    # p "Сладких снов..."
    p "Dulces sueños..."

# game/script.rpy:2858
translate spanish dont_feel_love_ceb9a88c:

    # p2 "Он ушел. я вздохнул[p2_verb_a()] с каким-то даже... Облегчением?"
    p2 "Se fue. Solté un suspiro de algo que fue casi... ¿alivio?"

# game/script.rpy:2859
translate spanish dont_feel_love_0ca5c53b:

    # p2 "Он даже не предложил помочь с фермой."
    p2 "Ni siquiera se ofreció a ayudar con la granja."

# game/script.rpy:2860
translate spanish dont_feel_love_d9d2af5b:

    # p2 "Ну и ладно, все равно я могу справиться сам[p2_verb_a()]."
    p2 "Bien, pues. De todos modos puedo encargarme yo mism[letra]."

# game/script.rpy:2865
translate spanish dont_feel_love_bf33b651:

    # p2 "Я выполнил[p2_verb_a()] все дела по ферме и пош[p2_verb_la_el()] в дом"
    p2 "Terminé todas las tareas de la granja y entré en la casa."

# game/script.rpy:2870
translate spanish dont_feel_love_7471f6cd:

    # p2 "День был долгий, я вымотал[p2_verb_as()], так что принял[p2_verb_a()] душ и сразу лег[p2_verb_la()] спать."
    p2 "Había sido un día largo y estaba agotad[letra], así que me duché y me fui directo a la cama."

# game/script.rpy:2871
translate spanish dont_feel_love_746ab8d4:

    # p2 "Много времени не понадобилось, я быстро уснул[p2_verb_a()]."
    p2 "No tardé mucho. Me quedé dormid[letra] rápido."

# game/script.rpy:2879
translate spanish dont_feel_love_a98f110e:

    # p "Сайлас, тот разговор ни на что не повлиял, нам не нужно отдаляться, я хочу, чтобы ты остался."
    p "Silas, esa conversación no cambió nada. No tenemos que alejarnos el uno del otro. Quiero que te quedes."

# game/script.rpy:2880
translate spanish dont_feel_love_e40d1bf0:

    # s fnsad2 "Ты правда этого хочешь? "
    s fnsad2 "¿De verdad quieres eso?"

# game/script.rpy:2881
translate spanish dont_feel_love_00c1f714:

    # p "Да, Сайлас, мы все еще друзья."
    p "Sí, Silas. Seguimos siendo amigos."

# game/script.rpy:2882
translate spanish dont_feel_love_67b16d50:

    # p2 "Он все еще выглядел обиженным, но пошел со мной в спальню."
    p2 "Seguía pareciendo herido, pero me siguió al dormitorio."

# game/script.rpy:2887
translate spanish dont_feel_love_650ce876:

    # p2 "Я думал[p2_verb_a()], что он отвернется от меня, но он крепко обнял, словно это была наша последняя ночь вместе."
    p2 "Pensé que me daría la espalda, pero me abrazó con fuerza, como si fuera nuestra última noche juntos."

# game/script.rpy:2888
translate spanish dont_feel_love_57ba2231:

    # p2 "Я обнял[p2_verb_a()] его в ответ и погрузил[p2_verb_as()] в сон, под весом его рук."
    p2 "Yo también lo abracé y me quedé dormid[letra] bajo el peso de sus brazos."

# game/script.rpy:2898
translate spanish final_dream_22bfcb23:

    # dream "Что это? {w} Это выглядит как кусочки моих воспоминаний. {w} Мне нужно собрать их воедино."
    dream "¿Qué es esto? {w} Parece que son fragmentos de mis recuerdos. {w} Necesito unirlos."

# game/script.rpy:2905
translate spanish final_dream_f9b13b81:

    # dream2 "Что за...{nw=2.0}"
    dream2 "Qué demonios...{nw=2.0}"

# game/script.rpy:3029
translate spanish final_dream_2_22bfcb23:

    # dream "Что это? {w} Это выглядит как кусочки моих воспоминаний. {w} Мне нужно собрать их воедино."
    dream "¿Qué es esto? {w} Parece que son fragmentos de mis recuerdos. {w} Necesito unirlos."

# game/script.rpy:3036
translate spanish final_dream_2_f9b13b81:

    # dream2 "Что за...{nw=2.0}"
    dream2 "Qué demonios...{nw=2.0}"

# game/script.rpy:3156
translate spanish final_dream_2_54a63996:

    # p2 "Меня выбросило из сна, я был[p2_verb_a()] покрыт[p2_verb_a()] холодным потом и прерывисто дышал[p2_verb_a()]."
    p2 "Me desperté de golpe, empapad[letra] en sudor frío y jadeando con dificultad."

# game/script.rpy:3157
translate spanish final_dream_2_3e1c2b17:

    # p "Это... Это не просто сон... Я помню... Это правда случилось..."
    p "Eso... Eso no fue solo un sueño... Lo recuerdo... De verdad pasó..."

# game/script.rpy:3162
translate spanish final_dream_2_9b168eb7:

    # p "ЧТО ЗА!?"
    p "¡¿QUÉ DEMONIOS!?"

# game/script.rpy:3163
translate spanish final_dream_2_d73e3a21:

    # p2 "Мое сердце сжалось от ужаса."
    p2 "Mi corazón se encogió de terror."

# game/script.rpy:3172
translate spanish final_dream_2_b07a6e80:

    # p2 "Бей. Первая моя мысль. Я ударил[p2_verb_a()] его по лицу, это сбило его с толка."
    p2 "Golpearlo. Ese fue mi primer pensamiento. Le di un golpe en la cara y eso lo hizo retroceder."

# game/script.rpy:3176
translate spanish final_dream_2_566b00d6:

    # p2 "Воспользовавшись его недоумением, я поднял[p2_verb_as()] и побежал[p2_verb_a()] вниз по лестнице, запираясь в единственной комнате с замком - в ванной. "
    p2 "Aprovechando su desconcierto, me levanté y bajé corriendo las escaleras, y me encerré en la única habitación que tenía cerrojo: el baño."

# game/script.rpy:3178
translate spanish final_dream_2_84e5622b:

    # p2 "Сайлас начал долбиться в дверь, пытаясь ее открыть. Он даже не пытался объясниться, он знал, что я все вспомнил[p2_verb_a()]."
    p2 "Silas empezó a golpear la puerta, tratando de abrirla. Ni siquiera intentó explicarse. Sabía que yo lo recordaba todo."

# game/script.rpy:3179
translate spanish final_dream_2_b6cc60cb:

    # s "[p.upper()]!!! ТЫ ВСЕ НЕПРАВИЛЬНО ПОНЯЛ[p2_verb_aa()]!!!"
    s "¡¡¡[p.upper()]!!! ¡¡¡LO HAS ENTENDIDO TODO MAL!!!"

# game/script.rpy:3180
translate spanish final_dream_2_79648342:

    # s "ОТКРОЙ ДВЕРЬ!"
    s "¡ABRE LA PUERTA!"

# game/script.rpy:3182
translate spanish final_dream_2_85103d95:

    # s "ОТКРОЙ ЧЕРТОВУ ДВЕРЬ! "
    s "¡ABRE LA MALDITA PUERTA!"

# game/script.rpy:3183
translate spanish final_dream_2_fe359437:

    # s "ЕСЛИ ТЫ НЕ ОТКРОЕШЬ ДВЕРЬ ПРЯМО СЕЙЧАС, Я ЕЕ СЛОМАЮ!"
    s "¡SI NO ABRES ESTA PUERTA AHORA MISMO, LA VOY A ROMPER!"

# game/script.rpy:3186
translate spanish final_dream_2_76508b51:

    # p2 "Дрожащими руками, я набрал[p2_verb_a()] номер Кайла, потому что он точно приедет быстрее, чем полиция."
    p2 "Con las manos temblorosas, marqué el número de Kyle, porque sin duda él llegaría aquí más rápido que la policía."

# game/script.rpy:3187
translate spanish final_dream_2_7dfc4256:

    # p "Кайл!! Пожалуйста, приезжай быстрее!! Мне нужна помощь, тут Сайлас!!"
    p "¡¡Kyle!! ¡Por favor, ven rápido!! ¡Necesito ayuda, Silas está aquí!!"

# game/script.rpy:3188
translate spanish final_dream_2_10b24c4d:

    # k "Сайлас..? "
    k "¿Silas..?"

# game/script.rpy:3190
translate spanish final_dream_2_3d3a97d0:

    # p2 "Он казался сонным, но следующая фраза прозвучала четко."
    p2 "Sonaba somnoliento, pero sus siguientes palabras salieron claras."

# game/script.rpy:3191
translate spanish final_dream_2_be27cf71:

    # k "Не бросай трубку, я сейчас приеду."
    k "No cuelgues. Voy para allá ahora mismo."

# game/script.rpy:3192
translate spanish final_dream_2_28f18daf:

    # p2 "Я оставал[p2_verb_as()] на линии с ним, он мог слышать безумные стуки Сайласа, дверь трещала, он явно пытался выбить ее."
    p2 "Me quedé al teléfono con él. Él podía oír los golpes frenéticos de Silas. La puerta se estaba agrietando. Era evidente que estaba tratando de derribarla."

# game/script.rpy:3194
translate spanish final_dream_2_e271461a:

    # s "[p.upper()]!!! ПРОСТИ!!! "
    s "¡¡¡[p.upper()]!!! ¡¡¡LO SIENTO!!!"

# game/script.rpy:3195
translate spanish final_dream_2_512a285e:

    # s "Я ВСЁ ОБЪЯСНЮ!"
    s "¡LO EXPLICARÉ TODO!"

# game/script.rpy:3196
translate spanish final_dream_2_3420c231:

    # s "Открой дверь, пожалуйста, Солнышко… "
    s "Abre la puerta, por favor, Solecito..."

# game/script.rpy:3197
translate spanish final_dream_2_9552706f:

    # s "Все будет хорошо, я клянусь…"
    s "Todo estará bien, te lo juro..."

# game/script.rpy:3199
translate spanish final_dream_2_5b5960b3:

    # s "Я тебя и пальцем не трону… "
    s "No te pondré un dedo encima..."

# game/script.rpy:3200
translate spanish final_dream_2_043988f7:

    # s "Мил[p2_verb_aya_iiy()]… Я так люблю тебя…"
    s "Cariño... Te amo tanto..."

# game/script.rpy:3203
translate spanish final_dream_2_fe5309dd:

    # s "НУ ХВАТИТ УЖЕ, ОТКРОЙ!!!"
    s "¡¡¡BASTA YA, ABRE!!!"

# game/script.rpy:3204
translate spanish final_dream_2_1e4d0196:

    # p2 "Я продолжал[p2_verb_a()] молчать, стараясь сосредоточиться на словах Кайла из телефона."
    p2 "Me mantuve en silencio, intentando concentrarme en la voz de Kyle a través del teléfono."

# game/script.rpy:3208
translate spanish final_dream_2_afa49dfb:

    # p2 "Через несколько минут стук прекратился..."
    p2 "Después de unos minutos, los golpes se detuvieron..."

# game/script.rpy:3209
translate spanish final_dream_2_9b7bcd34:

    # p2 "Я услышал[p2_verb_a()] голос Кайла. Сейчас это казалось самой приятной музыкой для ушей."
    p2 "Oí la voz de Kyle. En ese momento, sonó como la música más dulce del mundo."

# game/script.rpy:3211
translate spanish final_dream_2_29d5fc9c:

    # p2 "Снаружи звуки борьбы, я был[p2_verb_a()] так напуган[p2_verb_a()] за Кайла, надеюсь с ним все в порядке..."
    p2 "Se oyeron sonidos de forcejeo afuera. Tenía tanto miedo por Kyle. Esperaba que estuviera bien..."

# game/script.rpy:3213
translate spanish final_dream_2_61fc6902:

    # k "[p]??"
    k "¿¿[p]??"

# game/script.rpy:3214
translate spanish final_dream_2_08fdfe42:

    # p2 "Звуки борьбы прекратились, сменившись взволнованным голосом Кайла, произносящим мое имя."
    p2 "Los sonidos del forcejeo se detuvieron, reemplazados por la voz preocupada de Kyle diciendo mi nombre."

# game/script.rpy:3222
translate spanish final_dream_2_cabf0a57:

    # p2 "Я выш[p2_verb_la_el()] из ванной и бросил[p2_verb_as()] к нему. Он обнял меня."
    p2 "Salí del baño y corrí hacia él. Me envolvió en sus brazos."

# game/script.rpy:3227
translate spanish final_dream_2_e475a0d3:

    # k "Тише... "
    k "Shh..."

# game/script.rpy:3228
translate spanish final_dream_2_fa3fb927:

    # k "Все будет в порядке, я здесь, он тебе больше не навредит..."
    k "Todo va a estar bien. Estoy aquí. No te hará más daño..."

# game/script.rpy:3237
translate spanish final_dream_2_5437bcdb:

    # p "КАЙЛ!!!"
    p "¡¡¡KYLE!!!"

# game/script.rpy:3243
translate spanish final_dream_2_8cd0674f:

    # p "Кайл! Кайл, вставай!!"
    p "¡Kyle! ¡¡Kyle, levántate!!"

# game/script.rpy:3249
translate spanish final_dream_2_9031e615:

    # p2 "Он сейчас убьет меня."
    p2 "Me va a matar."

# game/script.rpy:3250
translate spanish final_dream_2_b14e5777:

    # p2 "Единственная мысль, пронесшаяся в моей голове."
    p2 "Ese fue el único pensamiento que me cruzó por la mente."

# game/script.rpy:3251
translate spanish final_dream_2_dd1b1dff:

    # p2 "Он попытался схватить меня."
    p2 "Intentó agarrarme."

# game/script.rpy:3256
translate spanish final_dream_2_aeff39e8:

    # k "От меня не избавиться при помощи сковородки, идиот."
    k "No puedes deshacerte de mí con una sartén, idiota."

# game/script.rpy:3259
translate spanish final_dream_2_9456bd68:

    # p2 "Он потянул Сайласа к себе, оказался на нем сверху и вырубил его одним ударом."
    p2 "Atrajo a Silas hacia él, se subió encima y lo noqueó de un puñetazo."

# game/script.rpy:3262
translate spanish final_dream_2_9d1422d5:

    # p2 "Я наблюдал за этой сценой в ужасе."
    p2 "Observé la escena con horror."

# game/script.rpy:3263
translate spanish final_dream_2_02643e69:

    # k "Я поспешил с обещаниями, но теперь он точно ничего не сделает."
    k "Me precipité al hacer esa declaración, pero ahora definitivamente no hará nada."

# game/script.rpy:3266
translate spanish final_dream_2_60292632:

    # p2 "Я молча взял[p2_verb_a()] Кайла за руку, крепко сжимая и не отводя взгляд от Сайласа."
    p2 "En silencio, tomé la mano de Kyle y la apreté con fuerza sin apartar la mirada de Silas."

# game/script.rpy:3267
translate spanish final_dream_2_d0f9c024:

    # s hwake "[p]... {w}[p]... {w}[p]..."
    s hwake "[p]... {w}[p]... {w}[p]..."

# game/script.rpy:3273
translate spanish final_dream_2_a30776ff:

    # s "Прости меня!! Умоляю!! "
    s "¡¡Lo siento!! ¡¡Por favor!!"

# game/script.rpy:3274
translate spanish final_dream_2_480d4034:

    # s "Я не хотел, я просто вспылил!!"
    s "¡No quería hacerlo, solo perdí los estribos!!"

# game/script.rpy:3275
translate spanish final_dream_2_cdf22f33:

    # s "Пожалуйста... Я так люблю тебя... Ты сам[p2_verb_aya_iiy()] драгоценн[p2_verb_aya_iiy()] для меня...."
    s "Por favor... Te amo tanto... Eres lo más preciado del mundo para mí..."

# game/script.rpy:3276
translate spanish final_dream_2_d9ef71b4:

    # p2 "Я лишь сильнее сжал[p2_verb_a()] руку Кайла, он сжал мою в ответ."
    p2 "Solo apreté más la mano de Kyle, y él apretó la mía de vuelta."

# game/script.rpy:3278
translate spanish final_dream_2_3a417079:

    # s hbes "Почему ты с ним!?{w}"
    s hbes "¿¡Por qué estás con él!?{w}"

# game/script.rpy:3280
translate spanish final_dream_2_4ae626b6:

    # extend "ТЫ ДОЛЖ[p2_verb_en_na()] БЫТЬ СО МНОЙ!! ЭТО ВСЕ ТАК НЕПРАВИЛЬНО!!!"
    extend "¡¡SE SUPONE QUE DEBES ESTAR CONMIGO!! ¡¡¡ESTO ESTÁ TODO MAL!!!"

# game/script.rpy:3286
translate spanish final_dream_2_77ef3d93:

    # k "Он слишком громкий."
    k "Hace demasiado ruido."

# game/script.rpy:3287
translate spanish final_dream_2_db1cc346:

    # p2 "Мне было неприятно смотреть на это, я чувствовал[p2_verb_a()] сильный страх и ненависть к Сайласу, но я не хотел[p2_verb_a()] смотреть на насилие."
    p2 "Era desagradable de ver. Sentía un miedo y un odio intensos hacia Silas, pero no quería ver violencia."

# game/script.rpy:3297
translate spanish final_dream_2_b3583950:

    # k "Так..."
    k "Vale..."

# game/script.rpy:3298
translate spanish final_dream_2_9ae7e365:

    # k "Теперь рассказывай, что вообще произошло."
    k "Ahora cuéntame qué demonios pasó."

# game/script.rpy:3299
translate spanish final_dream_2_29880ffe:

    # p "Сайлас пришел ко мне в день, когда я приехал[p2_verb_a()], сказал, что мы были друзьями..."
    p "Silas vino a verme el día que llegué. Dijo que solíamos ser amigos..."

# game/script.rpy:3300
translate spanish final_dream_2_049596aa:

    # p "Я был[p2_verb_a()] готов[p2_verb_a()] снова стать его другом, но сегодня ночью я вспомнил[p2_verb_a()], как..."
    p "Estaba dispuest[letra] a ser su amig[letra] de nuevo, pero esta noche recordé cómo..."

# game/script.rpy:3301
translate spanish final_dream_2_0e41ae0a:

    # p "Тем летом... Он запер меня в сарае, держал там несколько дней, а потом... Удар и я больше ничего не помню... "
    p "Aquel verano... Me encerró en el granero, me mantuvo allí varios días, y luego... un golpe, y no recuerdo nada después de eso..."

# game/script.rpy:3302
translate spanish final_dream_2_12fcff3b:

    # p "Я вспомнил[p2_verb_a()] это во сне, а когда проснул[p2_verb_as()], он уже был в моей комнате..."
    p "Lo recordé en un sueño, y cuando me desperté, él ya estaba en mi habitación..."

# game/script.rpy:3303
translate spanish final_dream_2_ed56cef1:

    # k "Вот значит как..."
    k "Así que así fue..."

# game/script.rpy:3304
translate spanish final_dream_2_a0743b55:

    # k "Теперь все сходится."
    k "Ahora todo tiene sentido."

# game/script.rpy:3305
translate spanish final_dream_2_9860213f:

    # k h3calm "Тем летом вся деревня искала тебя несколько дней, а потом Сайлас нашел тебя в реке и вытащил."
    k h3calm "Aquel verano, todo el pueblo te buscó durante días. Luego Silas te encontró en el río y te sacó."

# game/script.rpy:3306
translate spanish final_dream_2_96591205:

    # k "Я всегда думал, что это подозрительно, а поведение Сайласа подкидывало дров в огонь."
    k "Siempre me pareció sospechoso, y el comportamiento de Silas solo echó más leña al fuego."

# game/script.rpy:3307
translate spanish final_dream_2_39c05f33:

    # k h2calm "Он стал очень замкнутым, когда ты уехал. Люди в деревне считали его героем, хвалили, а он злился и иногда даже набрасывался на тех, кто хвалил его. Со временем он из героя стал изгоем."
    k h2calm "Se volvió muy reservado después de que te fueras. La gente del pueblo lo trataba como a un héroe y lo elogiaba, pero él se enojaba y, a veces, incluso arremetía contra cualquiera que lo elogiara. Con el tiempo, pasó de ser un héroe a convertirse en un marginado."

# game/script.rpy:3308
translate spanish final_dream_2_68bbcb44:

    # p "Он спас меня..?"
    p "¿Me salvó..?"

# game/script.rpy:3309
translate spanish final_dream_2_86cce5b4:

    # p "Я не понимаю зачем и как я вообще оказал[p2_verb_as()] в воде... "
    p "No entiendo por qué, ni cómo acabé en el agua..."

# game/script.rpy:3310
translate spanish final_dream_2_0329f736:

    # p "Может он подстроил это, чтобы казаться героем... Но он не мог знать, что я потеряю память..."
    p "Quizás lo planeó para parecer un héroe... Pero no imagino que yo perdería la memoria..."

# game/script.rpy:3311
translate spanish final_dream_2_58afcb99:

    # k h4calm "Не нагружай себя."
    k h4calm "No te eches la culpa por eso."

# game/script.rpy:3317
translate spanish final_dream_2_02aff4e0:

    # p2 "Я взял[p2_verb_a()] его за руку, так было спокойнее."
    p2 "Tomé su mano. Me hizo sentir más tranquil[letra]."

# game/script.rpy:3321
translate spanish final_dream_2_720fc0de:

    # p2 "Кайл улыбнулся и сжал мою руку."
    p2 "Kyle sonrió y me apretó la mano."

# game/script.rpy:3322
translate spanish final_dream_2_60994ff6:

    # k "Что ты будешь делать дальше?"
    k "¿Qué vas a hacer ahora?"

# game/script.rpy:3323
translate spanish final_dream_2_8a5e23fe:

    # p "Хочу снова забыть все..."
    p "Quiero olvidarlo todo de nuevo..."

# game/script.rpy:3324
translate spanish final_dream_2_ec435c18:

    # p "Но наверное останусь в деревне, дедушке все еще нужна моя помощь..."
    p "Pero probablemente me quedaré en el pueblo. El abuelo todavía necesita mi ayuda..."

# game/script.rpy:3325
translate spanish final_dream_2_3e6cfe81:

    # k "Напоминаю, что всегда готова помочь. "
    k "Solo te recuerdo que siempre estoy listo para ayudar."

# game/script.rpy:3326
translate spanish final_dream_2_8996f417:

    # k "Тебе сейчас страшно, так что я могу хотя бы просто быть рядом, пока твой старик не вернется."
    k "Estás asustad[letra] ahora mismo, así que al menos puedo quedarme cerca hasta que vuelva tu viejo."

# game/script.rpy:3327
translate spanish final_dream_2_b405609e:

    # p "Да... Пожалуйста...."
    p "Sí... Por favor..."

# game/script.rpy:3328
translate spanish final_dream_2_c8280132:

    # p "И если ты так хочешь помочь на ферме, то можешь заняться чисткой загонов с животными."
    p "Y si de verdad quieres ayudar en la granja, puedes limpiar los corrales de los animales."

# game/script.rpy:3329
translate spanish final_dream_2_5d437474:

    # k h4calmhand3 "Ну ты и [p2_verb_sly()]."
    k h4calmhand3 "No tienes remedio, ¿verdad?"

# game/script.rpy:3331
translate spanish final_dream_2_e9c00923:

    # p2 "Я уставил[p2_verb_as()] в пустоту, пытаясь успокоиться."
    p2 "Me quedé mirando al vacío, intentando calmarme."

# game/script.rpy:3332
translate spanish final_dream_2_4f0de8fd:

    # k h4calmwhand2 "Что ты будешь делать дальше?"
    k h4calmwhand2 "¿Qué vas a hacer ahora?"

# game/script.rpy:3333
translate spanish final_dream_2_8a5e23fe_1:

    # p "Хочу снова забыть все..."
    p "Quiero olvidarlo todo de nuevo..."

# game/script.rpy:3334
translate spanish final_dream_2_ec435c18_1:

    # p "Но наверное останусь в деревне, дедушке все еще нужна моя помощь..."
    p "Pero probablemente me quedaré en el pueblo. El abuelo todavía necesita mi ayuda..."

# game/script.rpy:3335
translate spanish final_dream_2_3e6cfe81_1:

    # k "Напоминаю, что всегда готова помочь. "
    k "Solo te recuerdo que siempre estoy listo para ayudar."

# game/script.rpy:3336
translate spanish final_dream_2_8996f417_1:

    # k "Тебе сейчас страшно, так что я могу хотя бы просто быть рядом, пока твой старик не вернется."
    k "Estás asustad[letra] ahora mismo, así que al menos puedo quedarme cerca hasta que vuelva tu viejo."

# game/script.rpy:3337
translate spanish final_dream_2_b405609e_1:

    # p "Да... Пожалуйста...."
    p "Sí... Por favor..."

# game/script.rpy:3338
translate spanish final_dream_2_c8280132_1:

    # p "И если ты так хочешь помочь на ферме, то можешь заняться чисткой загонов с животными."
    p "Y si de verdad quieres ayudar en la granja, puedes limpiar los corrales de los animales."

# game/script.rpy:3340
translate spanish final_dream_2_c757b790:

    # k h4calmwhand3 "Ну ты и [p2_verb_sly()]."
    k h4calmwhand3 "No tienes remedio, ¿verdad?"

# game/script.rpy:3348
translate spanish final_dream_2_2865b971:

    # p2 "Вскоре приехала полиция, Сайласа забрали. Я чувствовал[p2_verb_a()] угрозу, несмотря на наручники, сковывающие его руки и полицейских вокруг."
    p2 "Pronto, la policía llegó y se llevó a Silas. Todavía me sentía amenazad[letra], a pesar de las esposas en sus muñecas y los oficiales a su alrededor."

# game/script.rpy:3351
translate spanish final_dream_2_8c12b96e:

    # p2 "Через неделю дедушка вернулся из больницы, мы не стали ему рассказывать все, что произошло, чтобы он не нервничал, хотя слухи бы все равно дошли до него."
    p2 "Una semana después, el abuelo volvió del hospital. No le contamos todo lo que había pasado para que no se alterara, aunque los rumores probablemente le llegarían de todos modos."

# game/script.rpy:3352
translate spanish final_dream_2_89b5ad76:

    # p2 "Спустя еще одну неделю состоялся суд."
    p2 "Otra semana después, tuvo lugar el juicio."

# game/script.rpy:3359
translate spanish final_dream_2_a4c2b08d:

    # p2 "Я не сразу узнал[p2_verb_a()] его, было необычно видеть его хотя бы в чистой одежде."
    p2 "No lo reconocí de inmediato. Era inusual verlo con ropa limpia, al menos."

# game/script.rpy:3362
translate spanish final_dream_2_8b06bed6:

    # p "Т-ты хорошо выглядишь.."
    p "T-te ves bien..."

# game/script.rpy:3363
translate spanish final_dream_2_3e26a669:

    # k courtshy "Спасибо. Я пытался выглядеть уместно."
    k courtshy "Gracias. Intenté vestir de forma adecuada."

# game/script.rpy:3364
translate spanish final_dream_2_d88384db:

    # p "Ты и бороду уложил?"
    p "¿Te has arreglado la barba?"

# game/script.rpy:3365
translate spanish final_dream_2_fa920d4e:

    # k courtcalm "Нет, бороду не трогал, а что, тебе нравится?"
    k courtcalm "No, no me toqué la barba. ¿Por qué? ¿Te gusta?"

# game/script.rpy:3366
translate spanish final_dream_2_2322be11:

    # p "Ну да... Борода тебе идет..."
    p "Bueno, sí... La barba te sienta bien..."

# game/script.rpy:3367
translate spanish final_dream_2_354f9884:

    # k courtshy2 "Спасибо."
    k courtshy2 "Gracias."

# game/script.rpy:3368
translate spanish final_dream_2_b94204f4:

    # p "Что ты думаешь приговоре?"
    p "¿Qué piensas sobre la sentencia?"

# game/script.rpy:3371
translate spanish final_dream_2_b94204f4_1:

    # p "Что ты думаешь приговоре?"
    p "¿Qué piensas sobre la sentencia?"

# game/script.rpy:3372
translate spanish final_dream_2_7c00d2f1:

    # k courtsad "Я не разбираюсь в судебной системе, но надеюсь, что его отправят на принудительное лечение."
    k courtsad "No sé mucho sobre el sistema legal, pero espero que lo envíen a tratamiento obligatorio."

# game/script.rpy:3373
translate spanish final_dream_2_268582c5:

    # k "Он не плохой парень, просто запутался. Жизнь у него была нелегкая."
    k "No es un mal tipo. Solo se perdió. Su vida no fue fácil."

# game/script.rpy:3374
translate spanish final_dream_2_5db82973:

    # k courtsad2 "Не хочу его оправдать, он полностью виноват в том, что сделал, но..."
    k courtsad2 "No intento excusarlo. Es totalmente responsable de lo que hizo, pero..."

# game/script.rpy:3375
translate spanish final_dream_2_a1536507:

    # k "Я видел, как он рос и менялся. У него могло быть другое будущее."
    k "Lo vi crecer y cambiar. Podría haber tenido un futuro diferente."

# game/script.rpy:3376
translate spanish final_dream_2_bd8b5ca3:

    # p "Почему его жизнь была нелегкой?"
    p "¿Por qué no fue fácil su vida?"

# game/script.rpy:3377
translate spanish final_dream_2_dbad0243:

    # k "Он был рожден от женатого мужчины."
    k "Nació de un hombre casado."

# game/script.rpy:3378
translate spanish final_dream_2_2875a86a:

    # k "В деревне ничего не скрывается, так что все знали об этом."
    k "En un pueblo nada se mantiene oculto, así que todo el mundo lo sabía."

# game/script.rpy:3379
translate spanish final_dream_2_ba8852e0:

    # k "Люди любят осуждать, а их дети слышат больше, чем думают взрослые."
    k "A la gente le encanta juzgar, y sus hijos oyen más de lo que los adultos creen."

# game/script.rpy:3380
translate spanish final_dream_2_0dac17bf:

    # p "Его травили?"
    p "¿Lo acosaban?"

# game/script.rpy:3381
translate spanish final_dream_2_d2060b75:

    # k courtsad "Не всегда открыто. Иногда достаточно шепота за спиной."
    k courtsad "No siempre abiertamente. A veces los susurros a tus espaldas son suficientes."

# game/script.rpy:3382
translate spanish final_dream_2_f3b918c3:

    # k "Иногда достаточно того, что на тебя смотрят иначе."
    k "A veces es suficiente con que la gente te mire de forma diferente."

# game/script.rpy:3383
translate spanish final_dream_2_d0c22cf9:

    # k courtsad2 "Он рано понял, что его будто... Стыдятся."
    k courtsad2 "Se dio cuenta pronto de que la gente estaba... avergonzada de él."

# game/script.rpy:3384
translate spanish final_dream_2_f1b42e08:

    # k "Это не оправдание."
    k "Eso no excusa nada."

# game/script.rpy:3385
translate spanish final_dream_2_2138de8f:

    # k "Но когда человеку с детства внушают, что он лишний... Он начинает цепляться за тех, кто дает ему чувство нужности."
    k "Pero cuando alguien crece sintiéndose no deseado... empieza a aferrarse a cualquiera que le haga sentir necesario."

# game/script.rpy:3386
translate spanish final_dream_2_721bb8bf:

    # p "Ясно... Так я отверг[p2_verb_la()] его в момент, когда он больше всего во мне нуждался..."
    p "Ya veo... Así que lo rechacé cuando más me necesitaba..."

# game/script.rpy:3387
translate spanish final_dream_2_234b5b03:

    # k "Эй, не смей себя винить. Его травма не твоя проблема, ты не обязан[p2_verb_a()] спасать его. Ты просто оказал[p2_verb_as()] рядом не в подходящий момент."
    k "Oye, no te atrevas a echarte la culpa. Su trauma no es tu responsabilidad. No estabas obligad[letra] a salvarlo. Solo pasó que estabas allí en el momento equivocado."

# game/script.rpy:3388
translate spanish final_dream_2_d2859e10:

    # p "Ты прав, но мне все равно жаль его... Сложно всю жизнь быть тем, кого все призирают по факту рождения..."
    p "Tienes razón, pero aun así me da pena... Debe ser duro pasarte toda la vida siendo menospreciado por cómo naciste..."

# game/script.rpy:3389
translate spanish final_dream_2_5a856473:

    # k "Да. Поэтому ему нужна не тюрьма, а лечение. Я верю в его исправление. "
    k "Sí. Por eso necesita tratamiento, no prisión. Creo que puede mejorar."

# game/script.rpy:3392
translate spanish final_dream_2_a63cdbc1:

    # p2 "Суд был недолгим. Кайл оказался прав, его направили в психиатрическую больницу. Я надеюсь, что он избавится от своих демонов."
    p2 "El juicio no duró mucho. Kyle tenía razón: Silas fue enviado a un hospital psiquiátrico. Espero que pueda liberarse de sus demonios."

# game/script.rpy:3397
translate spanish final_dream_2_c96b868b:

    # p2 "Остаток лета прошел спокойно, даже несмотря на то, что дед вернулся, Кайл часто приходил провести со мной время."
    p2 "El resto del verano pasó en paz. Incluso después de que el abuelo volviera, Kyle venía a menudo a pasar tiempo conmigo."

# game/script.rpy:3398
translate spanish final_dream_2_ff8cc681:

    # p2 "Он помогал и с фермой, и с моими страхами. Я начал[p2_verb_a()] чувствовать привязанность к нему."
    p2 "Ayudaba con la granja y con mis miedos. Empecé a sentirme apegad[letra] a él."

# game/script.rpy:3401
translate spanish final_dream_2_28b420e6:

    # p2 "Последний вечер перед отъездом. Дед готовил большой ужин, а мы с Кайлом сидели на крыльце и пили пиво."
    p2 "Era la última tarde antes de que me fuera. El abuelo estaba preparando una gran cena, y Kyle y yo estábamos sentados en el porche bebiendo cerveza."

# game/script.rpy:3407
translate spanish final_dream_2_77ec38de:

    # k "Я надеюсь ты не забудешь это лето."
    k "Espero que no olvides este verano."

# game/script.rpy:3408
translate spanish final_dream_2_fe75086f:

    # p "Тебя я точно не забуду, не знаю, что бы я без тебя делал[p2_verb_a()], я тебе жизнью обязан[p2_verb_a()]."
    p "Definitivamente no te olvidaré. No sé qué habría hecho sin ti. Te debo la vida."

# game/script.rpy:3409
translate spanish final_dream_2_01036aeb:

    # k "Ну знаешь, ты тоже много сделал[p2_verb_a()] для меня. С твоим появлением тут, жизнь стала веселее. "
    k "Bueno, ya sabes, tú también hiciste mucho por mí. La vida se volvió más divertida después de que aparecieras por aquí."

# game/script.rpy:3410
translate spanish final_dream_2_8a5ec37a:

    # p2 "Я смотрел[p2_verb_a()] на него, как его волосы слегка развивались на ветру, как издавал довольные звуки после глотка пива, как смотрел на меня с теплотой в глазах."
    p2 "Lo observé: la forma en que su cabello se agitaba ligeramente con el viento, los sonidos de satisfacción que hacía tras un sorbo de cerveza, la calidez en sus ojos cuando me miraba."

# game/script.rpy:3413
translate spanish final_dream_2_f25ba932:

    # p2 "Я уставил[p2_verb_as()] на его губы, они слегка блестели от пива."
    p2 "Me quedé mirando sus labios. Brillaban tenuemente con la cerveza."

# game/script.rpy:3417
translate spanish final_dream_2_d94dc6b1:

    # p2 "Алкоголь дал мне смелости, и я наклонил[p2_verb_as()], чтобы поцеловать его."
    p2 "El alcohol me dio valor, y me incliné para besarlo."

# game/script.rpy:3418
translate spanish final_dream_2_a74d0c01:

    # k fner "[p]..."
    k fner "[p]..."

# game/script.rpy:3419
translate spanish final_dream_2_0a7f8cc4:

    # k "Это неправильно."
    k "Esto no está bien."

# game/script.rpy:3423
translate spanish final_dream_2_17a26edf:

    # p "Ч-что... Почему..?"
    p "¿Q-qué... Por qué..?"

# game/script.rpy:3424
translate spanish final_dream_2_ed22da0d:

    # k "Я понимаю, почему ты чувствуешь это, но я не могу ответить взаимностью."
    k "Entiendo por qué te sientes así, pero no puedo corresponder a esos sentimientos."

# game/script.rpy:3425
translate spanish final_dream_2_fc3f4696:

    # k fner2 "Смотри, я сильно старше тебя, ты видишь во мне того, кто тебя спас, поэтому чувствуешь что-то ко мне. "
    k fner2 "Mira, soy mucho mayor que tú, y me ves como la persona que te salvó. Por eso sientes algo por mí."

# game/script.rpy:3426
translate spanish final_dream_2_1a3061f7:

    # k "Я не могу ответить тебе тем же, потому что вижу в тебе т[p2_verb_y_ogo()] [p2_verb_gen()], котор[p2_verb_aya_iiy()] делал[p2_verb_a()] муравьиную ферму из бутылки, плакал[p2_verb_a()] на дереве, забирал[p2_verb_a()] рыбу у деда, чтобы отпустить ее обратно в реку. "
    k "No puedo sentir lo mismo, porque todavía te veo como [arti] niñ[letra] que hizo un hormiguero con una botella, que lloraba subid[letra] a un árbol y robaba peces de su abuelo solo para devolverlos al río."

# game/script.rpy:3427
translate spanish final_dream_2_413985e3:

    # k "Да, ты вырос[p2_verb_la()], но я все еще вижу в тебе ребенка."
    k "Sí, has crecido, pero sigo viéndote como [arti_2] niñ[letra]."

# game/script.rpy:3428
translate spanish final_dream_2_066366ed:

    # k "И самое главное."
    k "Y lo más importante."

# game/script.rpy:3429
translate spanish final_dream_2_2fa83190:

    # k fner3 "Твой дед убил бы меня, если бы я хотя бы притронулся тебе больше, чем следует."
    k fner3 "Tu abuelo me mataría si te tocara más de lo que debería."

# game/script.rpy:3430
translate spanish final_dream_2_ed8d2997:

    # p2 "Он попытался разрядить обстановку, но я все равно чувствовал[p2_verb_a()] себя отвергнут[p2_verb_oy_iim()], хотя его аргументы были весомыми..."
    p2 "Intentó aligerar el ambiente, pero aun así me sentí rechazad[letra], aunque sus razones eran sólidas..."

# game/script.rpy:3431
translate spanish final_dream_2_153eaa49:

    # k "Я все равно рад, что мы стали своего рода друзьями. "
    k "Aun así me alegra que nos hayamos hecho amigos. En cierto modo."

# game/script.rpy:3432
translate spanish final_dream_2_b6fc2da2:

    # k "Я буду рад увидеть тебя следующим летом."
    k "Me alegraría verte el próximo verano."

# game/script.rpy:3433
translate spanish final_dream_2_1524bd44:

    # p2 "Я слегка улыбнул[p2_verb_as()]."
    p2 "Sonreí débilmente."

# game/script.rpy:3434
translate spanish final_dream_2_71c91337:

    # p "Я обязательно приеду."
    p "Definitivamente volveré."

# game/script.rpy:3435
translate spanish final_dream_2_8ccd81f2:

    # p "Спасибо за все, что ты сделал для меня."
    p "Gracias por todo lo que has hecho por mí."

# game/script.rpy:3438
translate spanish final_dream_2_bece85b5:

    # p "Спасибо тебе за все, что ты для меня сделал."
    p "Gracias por todo lo que has hecho por mí."

# game/script.rpy:3439
translate spanish final_dream_2_95bf419c:

    # p "Я вернусь следующим летом, надеюсь не забудешь меня."
    p "Volveré el próximo verano. Espero que no me olvides."

# game/script.rpy:3440
translate spanish final_dream_2_5aecff95:

    # k fner3 "Конечно нет, я буду ждать."
    k fner3 "Claro que no. Estaré esperando."

# game/script.rpy:3450
translate spanish final_dream_2_683cfa8d:

    # p2 "Несмотря на все, что произошло в этой маленькой деревеньке, я буду скучать по ней и обязательно вернусь."
    p2 "A pesar de todo lo que pasó en este pequeño pueblo, lo extrañaré. Y definitivamente volveré."

# game/script.rpy:3475
translate spanish stay_at_bed_083a1252:

    # p2 "Подобные сны больше не появлялись, но я продолжал[p2_verb_a()] вспоминать и прокручивать в голове ту картину, которую увидел[p2_verb_a()] этой ночью."
    p2 "Sueños como ese no volvieron, pero seguí recordando y reproduciendo la imagen que había visto aquella noche."

# game/script.rpy:3476
translate spanish stay_at_bed_2886066c:

    # p2 "Сайлас продолжал вести себя как обычно. Милый, внимательный, прилипчивый."
    p2 "Silas seguía actuando como siempre. Dulce, atento, cariñoso."

# game/script.rpy:3477
translate spanish stay_at_bed_7ed99f3f:

    # p2 "Но я знал[p2_verb_a()], что с ним что-то не так."
    p2 "Pero yo sabía que algo andaba mal con él."

# game/script.rpy:3478
translate spanish stay_at_bed_d27c53a4:

    # p2 "Дедушка поправился и мне пора было возвращаться в город."
    p2 "El abuelo mejoró, y era hora de que yo volviera a la ciudad."

# game/script.rpy:3479
translate spanish stay_at_bed_f77d578f:

    # p2 "Кошмары больше не снились, но я гадал[p2_verb_a()], тот сон… {w}Это просто кошмар или воспоминания? "
    p2 "Las pesadillas se detuvieron, pero seguí preguntándome por ese sueño... {w}¿Fue solo una pesadilla o un recuerdo?"

# game/script.rpy:3485
translate spanish stay_at_bed_a21b2825:

    # p2 "Утром мои сумки уже были собраны, Сайлас как обычно стоял под дверью дома."
    p2 "Por la mañana, mis maletas ya estaban hechas, y Silas estaba de pie junto a la puerta principal como siempre."

# game/script.rpy:3486
translate spanish stay_at_bed_ec8ea13c:

    # s "Я подумал... Я хочу поехать с тобой... В город."
    s "Estaba pensando... Quiero ir contigo... a la ciudad."

# game/script.rpy:3489
translate spanish stay_at_bed_25974e09:

    # p2 "Мне не кажется, что это просто сон… Обычный сон не пробуждает такие сильные эмоции…"
    p2 "No creo que fuera solo un sueño... Un sueño normal no despierta emociones tan fuertes..."

# game/script.rpy:3492
translate spanish stay_at_bed_6fd7a725:

    # p2 "Не знаю, что управляло мной, но я согласил[p2_verb_as()]."
    p2 "No sé qué me impulsó a hacerlo, pero acepté."

# game/script.rpy:3498
translate spanish say_refuse_1bfc65f1:

    # p "Сайлас... Я знаю, что произошло тем летом..."
    p "Silas... Sé lo que pasó aquel verano..."

# game/script.rpy:3499
translate spanish say_refuse_4a24e720:

    # s "Всё?"
    s "¿Todo?"

# game/script.rpy:3500
translate spanish say_refuse_a4bf941b:

    # p "Почти..."
    p "Casi..."

# game/script.rpy:3501
translate spanish say_refuse_d9d11bd8:

    # s ldscr2 "И что ты собираешься делать?"
    s ldscr2 "¿Y qué vas a hacer?"

# game/script.rpy:3502
translate spanish say_refuse_1cf12769:

    # p "Я прошу тебя... Пожалуйста... Отправься на лечение..."
    p "Te lo pido... Por favor... Recibe tratamiento..."

# game/script.rpy:3504
translate spanish say_refuse_f5848580:

    # s ldsad "Ладно..."
    s ldsad "Vale..."

# game/script.rpy:3505
translate spanish say_refuse_f4a2a33b:

    # p2 "Я удивил[p2_verb_as()]. Он согласился слишком быстро. Всё не может быть так просто."
    p2 "Me sorprendió. Aceptó demasiado rápido. No podía ser tan sencillo."

# game/script.rpy:3506
translate spanish say_refuse_d54e9ff9:

    # p "Правда? Ты сделаешь это??"
    p "¿En serio? ¿¿Lo harás??"

# game/script.rpy:3507
translate spanish say_refuse_5e683e31:

    # s "Для тебя да..."
    s "Por ti, sí..."

# game/script.rpy:3509
translate spanish say_refuse_f4780700:

    # s ldcry2 "Я бы сделал всё для тебя."
    s ldcry2 "Haría cualquier cosa por ti."

# game/script.rpy:3523
translate spanish say_refuse_390138c4:

    # s "Еда тут не очень вкусная."
    s "La comida aquí no es muy buena."

# game/script.rpy:3524
translate spanish say_refuse_a3458780:

    # s phshy2 "Дали бы они мне плиту и сковородку… я бы всех накормил."
    s phshy2 "Si me dieran una estufa y una sartén... alimentaría a todos."

# game/script.rpy:3526
translate spanish say_refuse_4ba3148b:

    # s phshy "Тут есть беговая дорожка."
    s phshy "Hay una cinta de correr aquí."

# game/script.rpy:3527
translate spanish say_refuse_34661bd8:

    # s "Я иногда закрываю глаза и представляю, что это поле..."
    s "A veces cierro los ojos e imagino que es un campo..."

# game/script.rpy:3528
translate spanish say_refuse_4cdd849b:

    # s phsad "Как тогда."
    s phsad "Como entonces."

# game/script.rpy:3529
translate spanish say_refuse_91b8b8d0:

    # s phshy "Это глупо, да..?"
    s phshy "Eso es estúpido, ¿no..?"

# game/script.rpy:3530
translate spanish say_refuse_25166d7e:

    # s phsad "{size=30}Я...{w=0.5} стараюсь.{/size}"
    s phsad "{size=30}Estoy...{w=0.5} intentándolo.{/size}"

# game/script.rpy:3531
translate spanish say_refuse_6c10930d:

    # s "Иногда получается."
    s "A veces funciona."

# game/script.rpy:3532
translate spanish say_refuse_8b3fa9fc:

    # s phcry "Иногда - нет."
    s phcry "A veces no."

# game/script.rpy:3533
translate spanish say_refuse_5c1dd83c:

    # s "Я всё ещё думаю о тебе."
    s "Sigo pensando en ti."

# game/script.rpy:3537
translate spanish say_refuse_6b49f38c:

    # s "Слишком часто."
    s "Demasiado a menudo."

# game/script.rpy:3538
translate spanish say_refuse_8fd54210:

    # s "И я...{w=1.5} боюсь..."
    s "Y estoy...{w=1.5} asustado..."

# game/script.rpy:3539
translate spanish say_refuse_9c462747:

    # s "Что если снова окажусь рядом..."
    s "¿Y si termino cerca de ti otra vez...?"

# game/script.rpy:3540
translate spanish say_refuse_f494f7a0:

    # s "Я опять сделаю что-то не так."
    s "Voy a volver a hacer algo mal."

# game/script.rpy:3542
translate spanish say_refuse_53230e9b:

    # s phcry2 "Я не хочу тебе навредить."
    s phcry2 "No quiero hacerte daño."

# game/script.rpy:3543
translate spanish say_refuse_185839ef:

    # s "{size=25}Даже если это значит...{/size}"
    s "{size=25}Incluso si eso significa...{/size}"

# game/script.rpy:3545
translate spanish say_refuse_2498729e:

    # s "что я больше тебя не увижу."
    s "No volveré a verte."

# game/script.rpy:3546
translate spanish say_refuse_c731ab5a:

    # s phcry3 "Но...{w} я был счастлив. {w}Правда."
    s phcry3 "Pero...{w} era feliz. {w}De verdad lo era."

# game/script.rpy:3547
translate spanish say_refuse_8c33c371:

    # s "Это лето… {w}было моим самым лучшим."
    s "Este verano... {w}fue el mejor que he tenido."

# game/script.rpy:3563
translate spanish say_refuse_173b0be8:

    # s ldang "На лечение!?"
    s ldang "¿¡Tratamiento!?"

# game/script.rpy:3564
translate spanish say_refuse_5df725a5:

    # s "Я что похож на психа!?"
    s "¿¡Acaso parezco un psicópata!?"

# game/script.rpy:3565
translate spanish say_refuse_7786b3cf:

    # p "Твои вспышки агрессии — это не нормально, но врачи тебе помогут..."
    p "Tus arrebatos de agresión no son normales, pero los médicos pueden ayudarte..."

# game/script.rpy:3566
translate spanish say_refuse_6ccb97b8:

    # s "Я.{w=0.5} Не.{w=0.5} Больной."
    s "Yo.{w=0.5} No.{w=0.5} Estoy.{w=0.5} Enfermo."

# game/script.rpy:3567
translate spanish say_refuse_71e2173d:

    # s "Я просто влюбился, почему ты не понимаешь!?"
    s "¡Solo me enamoré! ¿¡Por qué no lo entiendes!?"

# game/script.rpy:3569
translate spanish say_refuse_25cabd00:

    # s ldcry "Ты не представляешь, как мне больно... Ты снова отвергаешь меня..."
    s ldcry "No tienes idea de cuánto duele esto... Me estás rechazando otra vez..."

# game/script.rpy:3570
translate spanish say_refuse_7d2b338d:

    # p "Снова..?"
    p "¿Otra vez..?"

# game/script.rpy:3574
translate spanish say_refuse_e2e81aaa:

    # p2 "Он обнял меня, я думал[p2_verb_a()], что он собирается что-то со мной сделать, но..."
    p2 "Me abrazó. Pensé que iba a hacerme algo, pero..."

# game/script.rpy:3575
translate spanish say_refuse_af49735f:

    # s "Прощай."
    s "Adiós."

# game/script.rpy:3576
translate spanish say_refuse_da002a5f:

    # p2 "Он поцеловал меня в щеку и ушел. Я был[p2_verb_a()] в ступоре, так что не сказал[p2_verb_a()] ему ни единого слова."
    p2 "Me besó en la mejilla y se fue. Estaba en shock, así que no le dije ni una sola palabra."

# game/script.rpy:3579
translate spanish say_refuse_0194e447:

    # p2 "Мы с дедушкой погрузили сумки в машину и заехали в деревню, чтобы дедушка передал что-то Кайлу."
    p2 "El abuelo y yo cargamos mis maletas en el coche y paramos en el pueblo para que él pudiera darle algo a Kyle."

# game/script.rpy:3583
translate spanish say_refuse_dd5488e6:

    # p2 "Я заметил[p2_verb_a()], что люди суетятся, а какая-то женщина плачет. Нет, она рыдала так, словно потеряла все, что у нее было."
    p2 "Noté a la gente apresurándose, y a una mujer llorando. No, no estaba llorando. Estaba sollozando como si hubiera perdido todo lo que tenía."

# game/script.rpy:3584
translate spanish say_refuse_e7ad9ad2:

    # "Мой мальчик...{w=1.0} Почему же он..."
    "Mi chico...{w=1.0} Por qué ha..."

# game/script.rpy:3585
translate spanish say_refuse_96f4b5d6:

    # p "Что произошло?"
    p "¿Qué pasó?"

# game/script.rpy:3586
translate spanish say_refuse_6f74b8a6:

    # ded "Это...{w} Мама Сайласа..."
    ded "Esa es...{w} la madre de Silas..."

# game/script.rpy:3588
translate spanish say_refuse_d8581dcc:

    # p2 "Тело замерло. Было очевидно, что что-то произошло, но я отрицал[p2_verb_a()] худший вариант."
    p2 "Mi cuerpo se congeló. Era obvio que algo había pasado, pero me negaba a aceptar la peor posibilidad."

# game/script.rpy:3614
translate spanish say_yes_198ac36d:

    # s "Боже, я так рад!! "
    s "Dios, ¡¡estoy tan feliz!!"

# game/script.rpy:3615
translate spanish say_yes_22c5297b:

    # s "Нам будет так хорошо вместе!!"
    s "¡¡Vamos a ser tan felices juntos!!"

# game/script.rpy:3616
translate spanish say_yes_afd0527a:

    # s "Мы могли бы даже завести собаку и прогуливаться с ней в парке!!"
    s "¡¡Incluso podríamos conseguir un perro y pasearlo por el parque!!"

# game/script.rpy:3618
translate spanish say_yes_5c9a90d5:

    # p2 "Его радость усиливала двойственность моих чувств, он светился, светился как солнце."
    p2 "Su felicidad solo hacía que mis sentimientos fueran más contradictorios. Estaba radiante, brillando como el sol."

# game/script.rpy:3626
translate spanish say_yes_6c50c3cb:

    # p2 "Когда я вернул[p2_verb_as()] в город, все вроде встало на свои места, кроме того, что, по возвращении домой, меня встречали объятия Сайласа и горячий ужин."
    p2 "Cuando volví a la ciudad, todo parecía volver a su lugar, excepto que ahora llegaba a casa a los brazos de Silas y a una cena caliente."

# game/script.rpy:3627
translate spanish say_yes_bc6478be:

    # p2 "С ним было хорошо, я никогда не чувствовал[p2_verb_a()] себя так[p2_verb_oy_im()] нужн[p2_verb_oy_iim()] и желанн[p2_verb_oy_iim()]."
    p2 "Estar con él se sentía bien. Nunca antes me había sentido tan necesitad[letra] y querid[letra]."

# game/script.rpy:3631
translate spanish say_yes_22e633d6:

    # n "Мы идем в бар в пятницу?"
    n "¿Vamos al bar el viernes?"

# game/script.rpy:3632
translate spanish say_yes_c0e532b0:

    # p "Конечно, ты думаешь, что я пропущу хоть одну корпоративную попойку?"
    p "Por supuesto. ¿Crees que me perdería una sola noche de bebidas de la empresa?"

# game/script.rpy:3633
translate spanish say_yes_bbb5be7c:

    # n happy "Уверен, что нет,"
    n happy "Estoy seguro de que no,"

# game/script.rpy:3636
translate spanish say_yes_0cbf25ee:

    # extend "Только... Не приводи в этот раз своего парня, ладно?"
    extend "pero... no traigas a tu novio esta vez, ¿vale?"

# game/script.rpy:3637
translate spanish say_yes_f1063581:

    # p "Почему?"
    p "¿Por qué?"

# game/script.rpy:3638
translate spanish say_yes_07f6f7ee:

    # n ser2 "Не хочу сказать ничего плохого, но..."
    n ser2 "No quiero decir nada malo, pero..."

# game/script.rpy:3641
translate spanish say_yes_dae3f425:

    # n "Бармен рассказал, что он избил того парня, который пялился на тебя в прошлый раз. "
    n "El camarero dijo que le dio una paliza a ese tipo que se quedó mirándote la última vez."

# game/script.rpy:3644
translate spanish say_yes_37c340e0:

    # n "Мы, конечно, не трусы, но получить только за взгляд не хотим, так что... Оставь его дома."
    n "No es que seamos cobardes ni nada, pero no queremos que nos den una paliza solo por mirar, así que... déjalo en casa."

# game/script.rpy:3645
translate spanish say_yes_e58785f6:

    # p "Ладно, я поговорю с ним."
    p "Vale. Hablaré con él."

# game/script.rpy:3646
translate spanish say_yes_19612764:

    # n "Спасибо, встретимся завтра!"
    n "Gracias. ¡Nos vemos mañana!"

# game/script.rpy:3650
translate spanish say_yes_7c47ce40:

    # p2 "Я попрощал[p2_verb_as()] с Ноем и заш[p2_verb_la_el()] в магазин. Сайлас просил взять вина к ужину."
    p2 "Me despedí de Noah y entré en la tienda. Silas me había pedido que comprara un poco de vino para la cena."

# game/script.rpy:3656
translate spanish say_yes_913a1cc5:

    # p2 "Подойдя к двери своего дома я услышал[p2_verb_a()] звуки из-за угла. Это было похоже на хрип и удары. Может кому-то там нужна помощь?"
    p2 "Al acercarme a la puerta de mi casa, escuché unos ruidos que venían de la esquina. Parecían como si alguien se estuviera ahogando y como si hubiera golpes. ¿Quizás alguien necesitaba ayuda?"

# game/script.rpy:3658
translate spanish say_yes_5bfa6976:

    # p2 "Заглянув за угол, я замер[p2_verb_la()]."
    p2 "Asomé la cabeza por la esquina y me congelé."

# game/script.rpy:3668
translate spanish say_yes_c946cb29:

    # dream2 "{sc=3.0}Прости...{/sc} "
    dream2 "{sc=3.0}Lo siento...{/sc}"

# game/script.rpy:3669
translate spanish say_yes_9e85d4ed:

    # dream3 "У меня закружилась голова, я не мог[p2_verb_la()] говорить, я не мог[p2_verb_la()] двигаться, я мог[p2_verb_la()] только стоять и смотреть на Ноя и Сайласа над ним."
    dream3 "Me dio vueltas la cabeza. No podía hablar, no podía moverme. Todo lo que podía hacer era quedarme allí de pie y mirar a Noah, con Silas alzándose sobre su cuerpo."

# game/script.rpy:3670
translate spanish say_yes_4368b0bd:

    # dream2 "{sc=3.0}Я видел, как вы...{/sc}"
    dream2 "{sc=3.0}Los vi a los dos...{/sc}"

# game/script.rpy:3671
translate spanish say_yes_0a21d06f:

    # dream2 "{sc=3.0}Я не сдержался...{/sc}"
    dream2 "{sc=3.0}No pude evitarlo...{/sc}"

# game/script.rpy:3672
translate spanish say_yes_a4f568b5:

    # dream2 "{sc=3.0}Прости...{/sc}"
    dream2 "{sc=3.0}Lo siento...{/sc}"

# game/script.rpy:3685
translate spanish say_yes_0277a7c6:

    # p2 "Он сам сдался. {w}Ему дали пожизненное. {w}Я ведь знал[p2_verb_a()], что ему нельзя доверять."
    p2 "Se entregó. {w}Lo condenaron a cadena perpetua. {w}Sabía que no se podía confiar en él."

# game/script.rpy:3686
translate spanish say_yes_7a126058:

    # p2 "Но сказка о нашей милой совместной жизни вскружила мне голову."
    p2 "Pero el cuento de hadas de nuestra dulce y pequeña vida juntos se me subió a la cabeza."

# game/script.rpy:3687
translate spanish say_yes_25a9a0c2:

    # p2 "Ной... {w}Он был таким жизнерадостным и дружелюбным... {w}Я долж[p2_verb_na_en()] был предотвратить это... {w}Я не долж[p2_verb_na_en()] был[p2_verb_a()] впускать его в мою жизнь..."
    p2 "Noah... {w}Era tan alegre y amigable... {w}Debería haber evitado esto... {w}Nunca debí dejarlo entrar en mi vida..."

# game/script.rpy:3704
translate spanish overnight_stay_e925cded:

    # p2 "Я резко сел[p2_verb_a()] в кровати, вырвавшись из лап сна, все тело дрожало, а комната кажется тряслась."
    p2 "Me incorporé de un salto en la cama, sacándome a la fuerza del sueño. Todo mi cuerpo temblaba, y sentía como si la habitación también se estuviera sacudiendo."

# game/script.rpy:3705
translate spanish overnight_stay_017071ab:

    # s "[p]? Что-то случилось?"
    s "¿[p]? ¿Pasó algo?"

# game/script.rpy:3707
translate spanish overnight_stay_c6a056ab:

    # p2 "Я услышал[p2_verb_a()] сонный голос Сайласа, похоже я разбудил[p2_verb_a()] его."
    p2 "Oí la voz somnolienta de Silas. Parece que lo había despertado."

# game/script.rpy:3710
translate spanish overnight_stay_d2a1875e:

    # p "Просто кошмар..."
    p "Solo una pesadilla..."

# game/script.rpy:3711
translate spanish overnight_stay_7b042adc:

    # p2 "Он притянул меня к себе, обхватывая руками и уткнулся лицом в мою шею."
    p2 "Me atrajo hacia él, me rodeó con sus brazos y enterró su rostro en mi cuello."

# game/script.rpy:3712
translate spanish overnight_stay_4ffa127d:

    # s "Что за кошмар?"
    s "¿Qué clase de pesadilla?"

# game/script.rpy:3713
translate spanish overnight_stay_18ad7e76:

    # p "Какая-то чепуха, ничего конкретного, но я чувствую напряжение..."
    p "Una tontería. Nada específico, pero sigo tens[letra]..."

# game/script.rpy:3714
translate spanish overnight_stay_7647624c:

    # s "Давай я немного расслаблю тебя."
    s "Déjame ayudarte a relajarte un poco."

# game/script.rpy:3715
translate spanish overnight_stay_30d1d339:

    # p2 "Он начал слегка массировать мои плечи, это правда немного помогло, но вскоре его руки остановились, он заснул."
    p2 "Empezó a masajearme suavemente los hombros. En realidad ayudó un poco, pero pronto sus manos se detuvieron. Se había quedado dormido."

# game/script.rpy:3716
translate spanish overnight_stay_56c25563:

    # p2 "Все еще чувствую тревогу.{w} Эта тревога направлена на Сайласа…"
    p2 "Sigo sintiendo ansiedad.{w} Y esa ansiedad va dirigida a Silas..."

# game/script.rpy:3719
translate spanish overnight_stay_d9f20a86:

    # p2 "Думаю, это все же просто сон, нужно попытаться отбросить все мысли и еще немного поспать."
    p2 "Creo que de verdad fue solo un sueño. Necesito intentar apartar estos pensamientos y dormir un poco más."

# game/script.rpy:3722
translate spanish overnight_stay_16804547:

    # p2 "Я пытал[p2_verb_as()] уснуть, но ничего не получилось."
    p2 "Intenté quedarme dormid[letra], pero no funcionó."

# game/script.rpy:3732
translate spanish overnight_stay_7478e3fc:

    # p "Мне снился тот сарай... В котором призраки... "
    p "Soñé con ese granero... El de los fantasmas..."

# game/script.rpy:3733
translate spanish overnight_stay_b022fe10:

    # s "Что именно?"
    s "¿Qué exactamente?"

# game/script.rpy:3734
translate spanish overnight_stay_bace8ff6:

    # p "Там был кролик...{w} сарай...{w} и руки..."
    p "Había un conejo...{w} el granero...{w} y manos..."

# game/script.rpy:3735
translate spanish overnight_stay_86b464c6:

    # s "Руки...?"
    s "¿Manos...?"

# game/script.rpy:3736
translate spanish overnight_stay_60e72f3c:

    # p "Твои руки..."
    p "Tus manos..."

# game/script.rpy:3738
translate spanish overnight_stay_9a0834ae:

    # s dwccalm "Это просто сон,{w=0.7} кошмар. {w} это был эмоциональный день, вот тебе и приснился такой сон."
    s dwccalm "Fue solo un sueño,{w=0.7} una pesadilla. {w}Fue un día muy emotivo, así que es normal que soñaras algo así."

# game/script.rpy:3739
translate spanish overnight_stay_0653d11d:

    # p2 "Он взял меня за руку, но от его прикосновения не было комфортно и его улыбка вызывала тревогу."
    p2 "Me tomó de la mano, pero su tacto no se sentía reconfortante, y su sonrisa me inquietaba."

# game/script.rpy:3740
translate spanish overnight_stay_d09b20aa:

    # p "Это не просто сон..."
    p "No fue solo un sueño..."

# game/script.rpy:3742
translate spanish overnight_stay_f0ea9624:

    # p2 "Он сжал мою руку так сильно, что я почти услышал[p2_verb_a()] треск собственных костей."
    p2 "Me apretó la mano con tanta fuerza que casi pude oír cómo crujían mis huesos."

# game/script.rpy:3745
translate spanish overnight_stay_9bf23ebf:

    # s "Это.{w} Просто.{w} Сон."
    s "Fue.{w} Solo.{w} Un.{w} Sueño."

# game/script.rpy:3746
translate spanish overnight_stay_d2928c3c:

    # p "Сайлас, отпусти, мне больно! "
    p "Silas, suéltame, ¡me estás haciendo daño!"

# game/script.rpy:3747
translate spanish overnight_stay_6e0c54d6:

    # s dwcsad "Прости, прости..."
    s dwcsad "L-lo siento, perdón..."

# game/script.rpy:3748
translate spanish overnight_stay_2ab91801:

    # s "Мне просто неприятно, что я провинился в твоем сне, и теперь ты злишься на меня..."
    s "Solo duele que hice algo mal en tu sueño, y ahora estás enfadad[letra] conmigo..."

# game/script.rpy:3749
translate spanish overnight_stay_17a7cba1:

    # p "Я...{w} Я не говорил[p2_verb_a()], что ты провинился..."
    p "Yo...{w} No dije que hubieras hecho nada malo..."

# game/script.rpy:3756
translate spanish overnight_stay_68270f8e:

    # p2 "Я медленно отодвинул[p2_verb_as()]."
    p2 "Me alejé lentamente."

# game/script.rpy:3757
translate spanish overnight_stay_4a990f8c:

    # s "[p]. {w}Вернись."
    s "[p]. {w}Vuelve."

# game/script.rpy:3759
translate spanish overnight_stay_6562e907:

    # p2 "Я бросил[p2_verb_as()] к лестнице."
    p2 "Salí corriendo hacia las escaleras."

# game/script.rpy:3760
translate spanish overnight_stay_a283b8be:

    # s "СТОЙ!!! [p.upper()]!!!"
    s "¡¡¡PARA!!! ¡¡¡[p.upper()]!!!"

# game/script.rpy:3762
translate spanish overnight_stay_16cf3a14:

    # p2 "Схватившись за перила, я рывком направил[p2_verb_as()] вниз, надеясь ускориться, но не рассчитал[p2_verb_a()] силы и скатил[p2_verb_as()] вниз по лестнице, едва удерживаясь в сознании."
    p2 "Me agarré de la barandilla y tiré de mí hacia abajo, con la esperanza de moverme más rápido, pero calculé mal mi fuerza y caí rodando por las escaleras, sin perder el conocimiento por muy poco."

# game/script.rpy:3769
translate spanish overnight_stay_85df740d:

    # p "С-Сайлас... Не делай этого, пожалуйста..."
    p "S-Silas... No hagas esto, por favor..."

# game/script.rpy:3770
translate spanish overnight_stay_6b734299:

    # s dwcmad3 "Я не хотел... Я просто.. Ты..."
    s dwcmad3 "No fue mi intención... Es solo que... Tú..."

# game/script.rpy:3772
translate spanish overnight_stay_84ce3573:

    # s dwcmad5 "Ты... Ты никому не расскажешь."
    s dwcmad5 "Tú... No se lo dirás a nadie."

# game/script.rpy:3788
translate spanish knife_action_8d8e11af:

    # p2 "Он ослабил хватку."
    p2 "Su agarre se aflojó."

# game/script.rpy:3806
translate spanish knife_timeout_ad469a00:

    # p2 "Он вонзил нож в мое плечо, я не почувствовал[p2_verb_a()] боли, но слышал[p2_verb_a()] хруст кожи под лезвием."
    p2 "Me clavó el cuchillo en el hombro. No sentí dolor, pero escuché el sonido repugnante de la piel cediendo bajo la hoja."

# game/script.rpy:3809
translate spanish knife_timeout_bbee0eae:

    # s "[p]!! Прости меня!! Я не хотел!!"
    s "¡¡[p]!! ¡¡Lo siento!! ¡¡No quería hacerlo!!"

# game/script.rpy:3814
translate spanish knife_timeout_5cc8f159:

    # p2 "Я оттолкнул[p2_verb_a()] его, когда он потерял бдительность и выбежал[p2_verb_a()] из дома."
    p2 "Lo empujé cuando bajó la guardia y salí corriendo de la casa."

# game/script.rpy:3820
translate spanish run_action_ada634d9:

    # p2 "Я сумел[p2_verb_a()] выбежать из дома."
    p2 "Logré salir corriendo de la casa."

# game/script.rpy:3821
translate spanish run_action_0991ce63:

    # p2 "Нужно... Добраться в деревню... Кайл... Он должен помочь мне..."
    p2 "Necesito... llegar al pueblo... Kyle... Él tiene que ayudarme..."

# game/script.rpy:3823
translate spanish run_action_d372bdcb:

    # p2 "Я сам[p2_verb_a()] не заметил[p2_verb_a()], как добрал[p2_verb_as()] до леса."
    p2 "Ni siquiera me di cuenta de cómo llegué al bosque."

# game/script.rpy:3831
translate spanish run_timeout_f4f2b9e5:

    # p "САЙЛАС, НЕТ!!!"
    p "¡¡¡SILAS, NO!!!"

# game/script.rpy:3837
translate spanish run_timeout_368b6589:

    # dream2 "Я почувствовал[p2_verb_a()] металлический привкус во рту, а затем жидкость, которая не позволяла мне дышать. "
    dream2 "Sentí un sabor a metal en la boca, luego un líquido que no me dejaba respirar."

# game/script.rpy:3843
translate spanish run_timeout_955bbd2d:

    # dream2 "Сайлас выглядел напуганным, он что-то говорил, но я слышал[p2_verb_a()] только шум в ушах."
    dream2 "Silas se veía aterrorizado. Estaba diciendo algo, pero lo único que podía oír era un zumbido en mis oídos."

# game/script.rpy:3846
translate spanish run_timeout_17c573f3:

    # dream2 "Почему все потемнело..."
    dream2 "Por qué se oscurece todo..."

# game/script.rpy:3847
translate spanish run_timeout_9039cbb0:

    # dream2 "Неужели я..."
    dream2 "De verdad estoy..."

# game/script.rpy:3860
translate spanish go_bathroom_100a2ab4:

    # p2 "Тревога не позволила мне заснуть."
    p2 "La ansiedad no me dejaba dormir."

# game/script.rpy:3865
translate spanish go_bathroom_ab3ce097:

    # p2 "Я медленно встал[p2_verb_a()] с кровати и пош[p2_verb_la_el()] в ванную, чтобы отдышаться и попытаться успокоиться."
    p2 "Me levanté lentamente de la cama y fui al baño para recuperar el aliento e intentar calmarme."

# game/script.rpy:3920
translate spanish go_bathroom_61bc3613:

    # p2 "..."
    p2 "..."

# game/script.rpy:3921
translate spanish go_bathroom_ae3c5ea2:

    # p2 "Это... {w}Верно... {w} Сайлас пытался меня убить..."
    p2 "Eso es... {w}cierto... {w}Silas intentó matarme..."

# game/script.rpy:3922
translate spanish go_bathroom_1b179d2c:

    # p2 "Ружье дедушки...{w} Оно все еще лежит там, где он хранил его раньше..?"
    p2 "El arma del abuelo...{w} ¿Sigue donde solía guardarla..?"

# game/script.rpy:3923
translate spanish go_bathroom_ed445899:

    # p2 "Почему-то я помню, где это.."
    p2 "Por alguna razón, recuerdo dónde está eso..."

# game/script.rpy:3925
translate spanish go_bathroom_d69adee2:

    # p2 "Я направил[p2_verb_as()] к месту, где по моим воспоминаниям дедушка хранил его."
    p2 "Me dirigí al lugar donde recordaba que el abuelo la guardaba."

# game/script.rpy:3931
translate spanish go_bathroom_03e19b72:

    # p2 "Оно все еще тут..."
    p2 "Sigue aquí..."

# game/script.rpy:3937
translate spanish go_bathroom_3e2ba84f:

    # p2 "Услышав шаги за спиной, я резко обернул[p2_verb_as()], сжимая ружье в руках."
    p2 "Cuando oí pasos detrás de mí, me giré en redondo, empuñando la escopeta con mis manos."

# game/script.rpy:3946
translate spanish go_bathroom_4b29dd21:

    # s "[p]? Что происходит?"
    s "¿[p]? ¿Qué está pasando?"

# game/script.rpy:3949
translate spanish go_bathroom_caba3e7d:

    # p "Я все вспомнил[p2_verb_a()]!! Я знаю, что ты пытался убить меня!!"
    p "¡¡Lo recordé todo!! ¡¡Sé que intentaste matarme!!"

# game/script.rpy:3950
translate spanish go_bathroom_025266ab:

    # s hwcner "Это...{w=1.} Правда...{w=1.} Но теперь все по-другому!"
    s hwcner "Eso es...{w=1.} cierto...{w=1.} ¡Pero todo es diferente ahora!"

# game/script.rpy:3951
translate spanish go_bathroom_18f61608:

    # s hwcsad2 "Я не такой, как был раньше! Я был напуганным, отвергнутым ребенком..."
    s hwcsad2 "¡Ya no soy el mismo que era en aquel entonces! Era un niño asustado y rechazado..."

# game/script.rpy:3952
translate spanish go_bathroom_63672c31:

    # s "Клянусь, теперь я не сделаю тебе больно..."
    s "Lo juro, no te haré daño ahora..."

# game/script.rpy:3954
translate spanish go_bathroom_6fab0904:

    # extend " Никогда...{w} Я всегда буду защищать тебя..."
    extend "Nunca...{w} Siempre te protegeré..."

# game/script.rpy:3956
translate spanish go_bathroom_35f61c7f:

    # s "Я же твой страж, ты помнишь?"
    s "Soy tu guardián, ¿recuerdas?"

# game/script.rpy:3957
translate spanish go_bathroom_9beb9fba:

    # p "Это все тоже не правда!!!"
    p "¡¡¡Eso tampoco era cierto!!!"

# game/script.rpy:3958
translate spanish go_bathroom_467f78cf:

    # s "Я всегда был и буду твоим стражем."
    s "Siempre he sido y siempre seré tu guardián."

# game/script.rpy:3960
translate spanish go_bathroom_81bad955:

    # s "Мы же были друзьями..."
    s "Éramos amigos..."

# game/script.rpy:3961
translate spanish go_bathroom_9beb9fba_1:

    # p "Это все тоже не правда!!!"
    p "¡¡¡Eso tampoco era cierto!!!"

# game/script.rpy:3962
translate spanish go_bathroom_a64a7c91:

    # s "Я всегда был и буду твоим другом."
    s "Siempre he sido y siempre seré tu amigo."

# game/script.rpy:3963
translate spanish go_bathroom_006e9484:

    # s hwcsad4 "Я люблю тебя. Я не тот, кто тогда сделал это с тобой. Я тот, кто уничтожил этого человека внутри себя..."
    s hwcsad4 "Yo te amo. No fui yo quien te hizo eso en aquel entonces. Fui yo quien destruyó a esa persona que había dentro de mí..."

# game/script.rpy:3964
translate spanish go_bathroom_239a0819:

    # s "Пожалуйста, поверь мне..."
    s "Por favor, créeme..."

# game/script.rpy:3965
translate spanish go_bathroom_430e28dd:

    # s "Ты ведь тоже любишь меня, да..?"
    s "Tú también me quieres, ¿no..?"

# game/script.rpy:3970
translate spanish go_bathroom_fe73edf6:

    # p2 "Он молчал, и от этого становилось только страшнее..."
    p2 "Se quedó en silencio, y eso solo lo hacía más aterrador..."

# game/script.rpy:3976
translate spanish go_bathroom_4acee37b:

    # p2 "Он шагнул ко мне и схватил ружье, но направил его на свою грудь."
    p2 "Dio un paso hacia mí y agarró la escopeta, pero la apuntó a su propio pecho."

# game/script.rpy:3977
translate spanish go_bathroom_f43601bc:

    # s "Стреляй."
    s "Dispara."

# game/script.rpy:3978
translate spanish go_bathroom_bb35acc5:

    # p "ЧТО!?"
    p "¿¡QUÉ!?"

# game/script.rpy:3979
translate spanish go_bathroom_9bf1e423:

    # p "САЙЛАС ПРЕКРАТИ!"
    p "¡SILAS, PARA!"

# game/script.rpy:3980
translate spanish go_bathroom_2ae18c6d:

    # s "Если наставляешь ружье, то будь готов[p2_verb_a()] стрелять."
    s "Si apuntas con un arma, deberías estar list[letra] para disparar."

# game/script.rpy:3981
translate spanish go_bathroom_444ce442:

    # p "Я НЕ ХОЧУ УБИВАТЬ ТЕБЯ!"
    p "¡NO QUIERO MATARTE!"

# game/script.rpy:3984
translate spanish go_bathroom_f30a0a95:

    # s hwccr2 "Если не хочешь, значит любишь."
    s hwccr2 "Si no quieres, eso significa que me amas."

# game/script.rpy:3985
translate spanish go_bathroom_5d4f90cf:

    # p "НЕТ, Я ПРОСТО НЕ ХОЧУ СТАНОВИТЬСЯ УБИЙЦЕЙ!!!"
    p "¡¡¡NO, SOLO NO QUIERO CONVERTIRME EN [arti_2_ma] ASESIN[letra_ma]!!!"

# game/script.rpy:3986
translate spanish go_bathroom_14f22a9b:

    # s hwccr3 "Стреляй пожалуйста..."
    s hwccr3 "Por favor, dispara..."

# game/script.rpy:3987
translate spanish go_bathroom_c8bc926e:

    # p "САЙЛАС!!!"
    p "¡¡¡SILAS!!!"

# game/script.rpy:3988
translate spanish go_bathroom_8ae7763f:

    # s hwccr4 "Я люблю тебя."
    s hwccr4 "Te amo."

# game/script.rpy:3989
translate spanish go_bathroom_dbf6628a:

    # p2 "Он потянулся к спусковому крючку и..."
    p2 "Alcanzó el gatillo y..."

# game/script.rpy:3996
translate spanish go_bathroom_2f43ea96:

    # p2 "Я не хотел[p2_verb_a()]... Это он нажал на крючок... Я просто боял[p2_verb_as()]..."
    p2 "No quería... Él apretó el gatillo... Solo estaba asustad[letra]..."

# game/script.rpy:4004
translate spanish go_bathroom_9a1f174f:

    # "Вы признаны виновным[p2_verb_oy_iim()] в убийстве. Присяжные не нашли оснований считать ваши действия самообороной. Суд, руководствуясь статьей 19.02 Уголовного кодекса штата, приговаривает вас к шестнадцати годам лишения свободы в исправительной колонии строгого режима."
    "Ha sido declarad[letra] culpable de asesinato. El jurado no encontró motivos para considerar sus acciones como legítima defensa. Guiado por la Sección 19.02 del Código Penal del Estado, el tribunal le condena a dieciséis años en una instalación correccional de máxima seguridad."

# game/script.rpy:4017
translate spanish go_bathroom_770fe4b7:

    # p2 "Я промолчал[p2_verb_a()], не находя ответа на его вопрос."
    p2 "Me quedé en silencio, incapaz de encontrar una respuesta a su pregunta."

# game/script.rpy:4018
translate spanish go_bathroom_ec734a3b:

    # s hwccr5 "Любишь..."
    s hwccr5 "Tú sí me amas..."

# game/script.rpy:4019
translate spanish go_bathroom_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:4023
translate spanish go_bathroom_e9af3645:

    # p2 "Он отвел дуло ружья от себя и обнял меня."
    p2 "Apartó el cañón del arma de sí mismo y me abrazó."

# game/script.rpy:4024
translate spanish go_bathroom_239e74ec:

    # s "Я тоже тебя люблю."
    s "Yo también te amo."

# game/script.rpy:4025
translate spanish go_bathroom_e8b7750b:

    # p2 "Я... {w}нет... "
    p2 "Yo... {w}no..."

# game/script.rpy:4026
translate spanish go_bathroom_067a4392:

    # s "Не ври мне."
    s "No me mientas."

# game/script.rpy:4027
translate spanish go_bathroom_f90be5fd:

    # p "Я боюсь тебя..."
    p "Te tengo miedo..."

# game/script.rpy:4028
translate spanish go_bathroom_ac6f7cfa:

    # s "Это пройдет... Я заслужу твое доверие."
    s "Eso pasará... Me ganaré tu confianza."

# game/script.rpy:4029
translate spanish go_bathroom_874b40e8:

    # p "Нет... Это невозможно..."
    p "No... Eso es imposible..."

# game/script.rpy:4030
translate spanish go_bathroom_c9a63d2a:

    # p "Ты никогда не станешь нормальным..."
    p "Nunca serás normal..."

# game/script.rpy:4031
translate spanish go_bathroom_73f60c59:

    # s "Нормальным? Нет, никогда. Но зато я буду твоим. верным, любящим тебя всем своим существом. "
    s "¿Normal? No, nunca. Pero seré tuyo. Leal, amándote con cada parte de mí."

# game/script.rpy:4032
translate spanish go_bathroom_e48dfd88:

    # p "Ты... "
    p "Tú..."

# game/script.rpy:4033
translate spanish go_bathroom_7a8639c1:

    # s "Тише... Успокойся, все будет хорошо... "
    s "Shh... Cálmate. Todo estará bien..."

# game/script.rpy:4034
translate spanish go_bathroom_ca536bf9:

    # p2 "Он попытался выхватить дробовик из моих рук, я запаниковал[p2_verb_a()] и сжал[p2_verb_a()] палец на спусковом крючке.{nw=1.2}"
    p2 "Intentó arrancarme la escopeta de las manos. Me entró el pánico y apreté el dedo en el gatillo.{nw=1.2}"

# game/script.rpy:4043
translate spanish go_bathroom_fcb873b5:

    # p "САЙЛАС!!"
    p "¡¡SILAS!!"

# game/script.rpy:4044
translate spanish go_bathroom_681986d7:

    # p "Я НЕ ХОТЕЛ[p2_verb_aa()]!!"
    p "¡¡NO QUERÍA HACERLO!!"

# game/script.rpy:4047
translate spanish go_bathroom_bd9b0439:

    # p "НЕТ, САЙЛАС, ПОДОЖДИ!! СМОТРИ НА МЕНЯ!! ПОСМОТРИ НА МЕНЯ СЕЙЧАС ЖЕ!!"
    p "¡¡NO, SILAS, ESPERA!! ¡¡MÍRAME!! ¡¡MÍRAME AHORA MISMO!!"

# game/script.rpy:4057
translate spanish go_bathroom_b89dd4bb:

    # p2 "Слезы катились по моим щекам, я не хотел[p2_verb_a()] стрелять в него, я не хотел[p2_verb_a()] причинать боль хоть кому-то..."
    p2 "Las lágrimas rodaban por mis mejillas. No quería dispararle. No quería hacerle daño a nadie..."

# game/script.rpy:4058
translate spanish go_bathroom_7897bc94:

    # s "Тише, все в порядке, я не виню тебя."
    s "Shh, está bien. No te culpo."

# game/script.rpy:4059
translate spanish go_bathroom_c668abf9:

    # p "Н-но... Я..."
    p "P-pero... Yo..."

# game/script.rpy:4060
translate spanish go_bathroom_cf62b54f:

    # s "Зато знаешь что?"
    s "¿Pero sabes qué?"

# game/script.rpy:4063
translate spanish go_bathroom_0184be68:

    # p2 "Я поднял[p2_verb_a()] на него взгляд, он выглядел таким спокойным, словно ничего не произошло."
    p2 "Levanté la mirada hacia él. Se veía tan tranquilo, como si nada hubiera pasado."

# game/script.rpy:4066
translate spanish go_bathroom_06f60145:

    # s "Мы теперь квиты, я полагаю?"
    s "Estamos en paz ahora, ¿supongo?"

# game/script.rpy:4068
translate spanish go_bathroom_4fceff8f:

    # p2 "Мы квиты...{w} Оба травмировали друг друга...{w} Может...{w} Может мы правда друг друга стоим..?"
    p2 "Estamos en paz...{w} Los dos nos hicimos daño...{w} Quizás...{w} ¿Quizás de verdad nos merecemos el uno al otro..?"

# game/script.rpy:4089
translate spanish forest_fa31c060:

    # p2 "Это дорога из моего сна... {w} Нужно вспоминть путь..."
    p2 "Este es el camino de mi sueño... {w} Necesito recordar el camino..."

# game/script.rpy:4090
translate spanish forest_107cc608:

    # s "[p.upper()]!!!"
    s "¡¡¡[p.upper()]!!!"

# game/script.rpy:4124
translate spanish forest_timeout_821e4293:

    # p2 "Нет.. "
    p2 "No..."

# game/script.rpy:4125
translate spanish forest_timeout_bcd120d7:

    # p2 "Это не та дорога..."
    p2 "Este no es el camino correcto..."

# game/script.rpy:4132
translate spanish forest_timeout_98b87a32:

    # p2 "Я слышу его шаги.{w} он где-то рядом.{w} он...{nw=1.5}"
    p2 "Puedo oír sus pasos.{w} Está en algún lugar cerca.{w} Está...{nw=1.5}"

# game/script.rpy:4176
translate spanish path_river_128cf26a:

    # p2 "Мне удалось вспомнить путь из моего сна, но... Река... Я забыл[p2_verb_a()] про нее..."
    p2 "Logré recordar el camino de mi sueño, pero... el río... Lo olvidé..."

# game/script.rpy:4177
translate spanish path_river_849e678a:

    # p2 "Я не успею добежать до моста. Нужно плыть."
    p2 "No llegaré al puente a tiempo. Tengo que nadar."

# game/script.rpy:4180
translate spanish path_river_6a8d56be:

    # p2 "Я смогу это сделать. Я долж[p2_verb_na_en()]."
    p2 "Puedo hacer esto. Tengo que hacerlo."

# game/script.rpy:4183
translate spanish path_river_19dcd71c:

    # p2 "Я нырнул[p2_verb_a()] в воду и поплыл[p2_verb_a()] на другой берег. вода была холодной, но это только добавляло трезвости."
    p2 "Me zambullí en el agua y nadé hacia la otra orilla. El agua estaba fría, pero eso solo ayudó a despejar mi mente."

# game/script.rpy:4184
translate spanish path_river_24191a3c:

    # p2 "Я не долж[p2_verb_na_en()] был показываться на поверхности, иначе он увидит меня."
    p2 "No podía salir a la superficie. Si lo hacía, me vería."

# game/script.rpy:4186
translate spanish path_river_b96f1a90:

    # p2 "Я не уч[p2_verb_la_el()] только одно..."
    p2 "Solo había una cosa que no había tenido en cuenta..."

# game/script.rpy:4188
translate spanish path_river_76f41ddd:

    # p2 "Кровь от его удара выдавала мое местоположение... "
    p2 "La sangre de su golpe estaba delatando mi posición..."

# game/script.rpy:4191
translate spanish path_river_fc988ab1:

    # p2 "Я почувствовал[p2_verb_a()] его руки, обхватившие меня.{w} Я пытал[p2_verb_as()] кричать, но вода заглушала крики."
    p2 "Sentí sus brazos rodearme.{w} Intenté gritar, pero el agua se tragó el sonido."

# game/script.rpy:4192
translate spanish path_river_53885fb2:

    # p2 "Воздуха в легких не осталось. "
    p2 "No quedaba aire en mis pulmones."

# game/script.rpy:4193
translate spanish path_river_36b28ece:

    # p2 "Я снова испытал[p2_verb_a()] чувство беспомощности перед водой, которая забирала меня. "
    p2 "Sentí esa impotencia de nuevo, enfrentándome al agua mientras me llevaba."

# game/script.rpy:4194
translate spanish path_river_a57c3a4c:

    # p2 "Нет, это не вода забрала меня. {w} Это он отдал меня воде."
    p2 "No, no fue el agua lo que me llevó. {w}Él me entregó a ella."

# game/script.rpy:4212
translate spanish path_river_60eacd63:

    # p2 "Когда я оказал[p2_verb_as()] в деревне, я побежал[p2_verb_a()] к ближайшим домам, стуча в двери."
    p2 "Cuando llegué al pueblo, corrí a las casas más cercanas, golpeando las puertas."

# game/script.rpy:4213
translate spanish path_river_eddd6a0c:

    # p2 "Все было как в тумане, я не помню, кто открыл мне и что я им говорил[p2_verb_a()], но они помогли."
    p2 "Todo fue un borrón. No recuerdo quién abrió la puerta ni qué les dije, pero me ayudaron."

# game/script.rpy:4217
translate spanish path_river_e95b92bd:

    # dream3 "Сайлас исчез.{w} Его больше никто не видел, я в том числе.{w} Мне было страшно оставаться в деревне, так что я вернул[p2_verb_as()] в город."
    dream3 "Silas desapareció.{w} Nadie lo volvió a ver. Yo tampoco.{w} Tenía demasiado miedo para quedarme en el pueblo, así que volví a la ciudad."

# game/script.rpy:4219
translate spanish path_river_99558241:

    # dream3 "Мне стыдно перед дедушкой, что я так и не остал[p2_verb_as()] помочь ему с фермой, но Кайл убедил меня, что все в порядке и он сам поможет ему."
    dream3 "Me sentí avergonzad[letra] frente al abuelo por no quedarme a ayudarlo con la granja, pero Kyle me convenció de que estaba bien y dijo que él mismo lo ayudaría."

# game/script.rpy:4220
translate spanish path_river_2f5e158f:

    # dream3 "Жизнь вернулась в нормальное русло, но ощущение, что кто-то смотрит никогда не покидало меня."
    dream3 "La vida volvió a la normalidad, pero la sensación de que alguien me observaba nunca se fue."

# game/script.rpy:4235
translate spanish path_river_6ab212e3:

    # p2 "Я не могу!! Это слишком страшно!!"
    p2 "¡¡No puedo!! ¡¡Da demasiado miedo!!"

# game/script.rpy:4236
translate spanish path_river_54bbef3a:

    # p2 "Я успею добежать до моста."
    p2 "Puedo llegar al puente."

# game/script.rpy:4238
translate spanish path_river_64f0e1e4:

    # p2 "Мост был ближе и ближе, но..."
    p2 "El puente se acercaba cada vez más, pero..."

# game/script.rpy:4242
translate spanish path_river_984defb2:

    # s "Я ЖЕ ИЗВИНИЛСЯ!!! В ЧЕМ ТВОЯ ПРОБЛЕМА!?"
    s "¡¡¡DIJE QUE LO SENTÍA!!! ¿¡CUÁL ES TU PROBLEMA!?"

# game/script.rpy:4243
translate spanish path_river_26e601dd:

    # s dwcmad11 "ТЫ НЕВЫНОСИМ[p2_verb_iiy_aya()]! УПРЯМ[p2_verb_iiy_aya()]! НЕ ПОНИМАЮЩ[p2_verb_iy_aya()]! "
    s dwcmad11 "¡ERES INSOPOPORTABLE! ¡TERC[letra_ma]! ¡IMPOSIBLE DE ENTENDER!"

# game/script.rpy:4244
translate spanish path_river_e87e8080:

    # s dwcmad12 "ТЫ!!!"
    s dwcmad12 "¡¡TÚ!!"

# game/script.rpy:4268
translate spanish dont_go_into_the_water_fee8a1ec:

    # p "Я думаю, на сегодня хватит."
    p "Creo que eso es suficiente por hoy."

# game/script.rpy:4269
translate spanish dont_go_into_the_water_4d70f0ee:

    # s "Да ладно тебе, ты уже коснул[p2_verb_as()], почему бы тебе не пойти дальше?"
    s "Vamos, ya lo tocaste. ¿Por qué no ir un poco más lejos?"

# game/script.rpy:4270
translate spanish dont_go_into_the_water_1574adc7:

    # p "Я не хочу, не пытайся меня переубедить."
    p "No quiero. No intentes convencerme."

# game/script.rpy:4271
translate spanish dont_go_into_the_water_8185121e:

    # s "Как скажешь. "
    s "Lo que tú digas."

# game/script.rpy:4272
translate spanish dont_go_into_the_water_4f8465d7:

    # s "Ну тогда может пойдем?"
    s "¿Entonces quizás deberíamos irnos?"

# game/script.rpy:4273
translate spanish dont_go_into_the_water_fb271dec:

    # p "Ага."
    p "Sí."

# game/script.rpy:4281
translate spanish dont_go_into_the_water_a544282e:

    # p2 "Мы пошли на ферму, я был[p2_verb_a()] рад[p2_verb_a()], что Сайлас не пытался меня переубедить, кажется, он начинает прислушиваться ко мне."
    p2 "Volvimos a la granja. Me alegré de que Silas no hubiera intentado convencerme. Sentía que estaba empezando a escucharme."

# game/script.rpy:4282
translate spanish dont_go_into_the_water_abc11f0b:

    # p "В детстве я любил[p2_verb_a()] плавать, пока не произошло то, что произошло."
    p "Me encantaba nadar cuando era niñ[letra], hasta que pasó lo que pasó."

# game/script.rpy:4283
translate spanish dont_go_into_the_water_ec02099a:

    # p "Я много думал[p2_verb_a()] о том, как это случилось, в больнице сказали, что перед утоплением был удар тупым предметом. "
    p "He pensado mucho en cómo pasó. En el hospital, dijeron que me habían golpeado con algo contundente antes de que casi me ahogara."

# game/script.rpy:4286
translate spanish dont_go_into_the_water_2caefe6e:

    # p "Я думаю, что прыгнул[p2_verb_a()] в воду и ударил[p2_verb_as()] головой о камни на дне."
    p "Creo que salté al agua y me golpeé la cabeza con las rocas del fondo."

# game/script.rpy:4287
translate spanish dont_go_into_the_water_13ba49b6:

    # s fisad "Наверное, так и было..."
    s fisad "Probablemente eso fue lo que pasó..."

# game/script.rpy:4288
translate spanish dont_go_into_the_water_abeb6be7:

    # p "А где ты был в тот день?"
    p "¿Dónde estabas ese día?"

# game/script.rpy:4289
translate spanish dont_go_into_the_water_e9f1995c:

    # s fisad2 "Ну.. Я сам плохо помню... Так испугался за тебя, что все воспоминания отбило..."
    s fisad2 "Bueno... Yo mismo no lo recuerdo muy bien... Estaba tan asustado por ti que todo se me borró de la cabeza..."

# game/script.rpy:4296
translate spanish dont_go_into_the_water_0d42e210:

    # p2 "Мы вернулись домой, я решил[p2_verb_a()] сразу сделать все вечерние заботы на ферме, Сайлас не позволил мне заниматься всем одно[p2_verb_y_mu()]."
    p2 "Llegamos a casa, y decidí encargarme de las tareas de la granja de la tarde de inmediato. Silas no me dejaba hacer todo sol[letra]."

# game/script.rpy:4297
translate spanish dont_go_into_the_water_68832fe5:

    # p "Мне кажется, что теперь все получается быстрее."
    p "Siento que todo va más rápido ahora."

# game/script.rpy:4298
translate spanish dont_go_into_the_water_8306bf8d:

    # p "Чувствую себя настоящ[p2_verb_ey_im()] фе-{nw=0.5}"
    p "Me siento como [arti_2] gran- {nw=0.5}"

# game/script.rpy:4302
translate spanish dont_go_into_the_water_61bc3613:

    # p2 "..."
    p2 "..."

# game/script.rpy:4303
translate spanish dont_go_into_the_water_a45f44dc:

    # p "Вот черт... Я как свинья..."
    p "Oh, maldición... Pareces un cerdo..."

# game/script.rpy:4304
translate spanish dont_go_into_the_water_47288ba2:

    # s "АХАХАХАХАХАХ"
    s "JAJAJAJAJAJAJA"

# game/script.rpy:4305
translate spanish dont_go_into_the_water_fe330648:

    # s "Да, ты настоящая свинья!"
    s "¡Sí, eres un cerdo de verdad!"

# game/script.rpy:4306
translate spanish dont_go_into_the_water_28f3bac6:

    # p "Ладно тебе... "
    p "Oh, vamos..."

# game/script.rpy:4312
translate spanish dont_go_into_the_water_0bc74957:

    # p2 "Я поднял[p2_verb_as()] с земли, грязь практически капала с меня."
    p2 "Me levanté del suelo, con barro goteando prácticamente de mí."

# game/script.rpy:4313
translate spanish dont_go_into_the_water_3dc3254f:

    # p "Я пойду приму душ."
    p "Me voy a dar una ducha."

# game/script.rpy:4315
translate spanish dont_go_into_the_water_0484c3d9:

    # s fnfli "Тебе нужна моральная поддержка в душе или что-то в этом роде?"
    s fnfli "¿Necesitas apoyo moral en la ducha o algo así?"

# game/script.rpy:4317
translate spanish dont_go_into_the_water_dbf97df2:

    # p "Нет уж, спасибо, я сам[p2_verb_a()] справлюсь."
    p "No, gracias. Puedo encargarme yo sol[letra]."

# game/script.rpy:4318
translate spanish dont_go_into_the_water_b139ac6d:

    # s fnshy "Ну раз ты так уверен[p2_verb_a()] в себе, то валяй."
    s fnshy "Bueno, si estás tan segur[letra], adelante."

# game/script.rpy:4321
translate spanish dont_go_into_the_water_0d688b75:

    # p2 "Я смутил[p2_verb_as()].{w} Вместе... В душ...{w} Почему-то эта идея привлекала..."
    p2 "Me sonrojé.{w} Juntos... en la ducha...{w} Por alguna razón, la idea me resultaba tentadora..."

# game/script.rpy:4322
translate spanish dont_go_into_the_water_da78603c:

    # p "Да... Я думаю, что не справлюсь там без тебя..."
    p "Sí... No creo que pueda arreglármelas ahí dentro sin ti..."

# game/script.rpy:4326
translate spanish dont_go_into_the_water_d3e7a911:

    # s "Ты шутишь..? "
    s "¿Estás bromeando..?"

# game/script.rpy:4327
translate spanish dont_go_into_the_water_6425d273:

    # p "Нет...{w} Ну...{w} Только если ты шутишь..."
    p "No...{w} Bueno...{w} A menos que estuvieras bromeando..."

# game/script.rpy:4330
translate spanish dont_go_into_the_water_26e5dbf7:

    # s fnshock2 "НЕТ!!! {w=0.5}НЕ ШУЧУ, ПОШЛИ!!!"
    s fnshock2 "¡¡¡NO!!! {w=0.5}NO ESTOY BROMEANDO, ¡¡¡VAMOS!!!"

# game/script.rpy:4331
translate spanish dont_go_into_the_water_d0069f2d:

    # p2 "Похоже он правда шутил, потому что смутился сильнее, чем я, но это уже его проблемы."
    p2 "Parece que realmente estaba bromeando, porque se puso aún más nervioso que yo. Pero ese ya era su problema."

# game/script.rpy:4339
translate spanish dont_go_into_the_water_3e48d53b:

    # p2 "Ванна была мала для нас двоих, мы едва там помещались.{w} Сайлас был красный как рак в кастрюле, но явно довольный. "
    p2 "La bañera era demasiado pequeña para los dos. Apenas cabíamos dentro.{w} Silas estaba rojo como un cangrejo cocido, pero claramente feliz."

# game/script.rpy:4340
translate spanish dont_go_into_the_water_64e15266:

    # p2 "Я тоже не пожалел[p2_verb_a()] о своем выборе..."
    p2 "Tampoco me arrepentía de mi elección..."

# game/script.rpy:4346
translate spanish dont_go_into_the_water_bd4e1a52:

    # p2 "После душа было приятно лечь в кровать и завернуться в мягкое одеяло."
    p2 "Después de la ducha, se sentía bien acostarse en la cama y envolverse en una manta suave."

# game/script.rpy:4347
translate spanish dont_go_into_the_water_0aa14b0b:

    # p2 "Сайлас приобнял меня и вскоре уснул. Я последовал[p2_verb_a()] его примеру."
    p2 "Silas me pasó un brazo y pronto se quedó dormido. Seguí su ejemplo."

# game/script.rpy:4352
translate spanish dont_touch_the_water_4d8b18d1:

    # p2 "Я долго смотрел[p2_verb_a()] на воду, пытаясь принять решение. Страх прошел по моему телу, словно электрический ток."
    p2 "Me quedé mirando el agua durante mucho tiempo, intentando tomar una decisión. El miedo recorría mi cuerpo como una corriente eléctrica."

# game/script.rpy:4353
translate spanish dont_touch_the_water_3d3f5aa9:

    # p "Нет..."
    p "No..."

# game/script.rpy:4358
translate spanish dont_touch_the_water_da66b347:

    # s "Что? Почему? Я уже даже разделся, чтобы поддержать тебя в воде!"
    s "¿Qué? ¿Por qué? ¡Hasta me desvestí para poder ayudarte en el agua!"

# game/script.rpy:4359
translate spanish dont_touch_the_water_ad0c6f9e:

    # p "Это слишком страшно..."
    p "Da demasiado miedo..."

# game/script.rpy:4360
translate spanish dont_touch_the_water_d30e1851:

    # s "Но если ты не попытаешься, то никогда не поборешь страх!"
    s "¡Pero si no lo intentas, nunca superarás tu miedo!"

# game/script.rpy:4361
translate spanish dont_touch_the_water_795f97e5:

    # p "Сейчас не самый лучший момент..."
    p "Ahora no es el mejor momento..."

# game/script.rpy:4362
translate spanish dont_touch_the_water_c619e3e0:

    # s rang "Самого лучшего момента не будет никогда! "
    s rang "¡Nunca habrá un momento perfecto!"

# game/script.rpy:4363
translate spanish dont_touch_the_water_362e2cd7:

    # p "Но... Я все равно не хочу сейчас... Дай мне время..."
    p "Pero... todavía no quiero ahora... Dame tiempo..."

# game/script.rpy:4364
translate spanish dont_touch_the_water_73ddb4da:

    # s rang2 "Ты всегда отказывал[p2_verb_as()] от того, что для тебя лучше."
    s rang2 "Siempre rechazaste lo que era mejor para ti."

# game/script.rpy:4365
translate spanish dont_touch_the_water_5bf73acd:

    # p2 "Что он имеет ввиду? \"Всегда\"... Это ведь значит, что я не всегда соглашал[p2_verb_as()] с ним и это его раздражало?"
    p2 "¿Qué quiere decir con \"Siempre\"? ¿Significa que no siempre estaba de acuerdo con él, y eso lo molestaba?"

# game/script.rpy:4370
translate spanish dont_touch_the_water_c45bcc0a:

    # p "Что ты подразумеваешь под этим? "
    p "¿Qué quieres decir con eso?"

# game/script.rpy:4371
translate spanish dont_touch_the_water_57744d07:

    # s rsad2 "Я.. Ну... Ты просто всегда был[p2_verb_a()] упрям[p2_verb_a()] в детстве..."
    s rsad2 "Yo... Bueno... Es que siempre eras muy terc[letra] de niñ[letra]..."

# game/script.rpy:4377
translate spanish dont_touch_the_water_0825f348:

    # p2 "Он вздохнул раздраженно и сел на берег."
    p2 "Suspiró con irritación y se sentó en la orilla."

# game/script.rpy:4384
translate spanish dont_touch_the_water_0825f348_1:

    # p2 "Он вздохнул раздраженно и сел на берег."
    p2 "Suspiró con irritación y se sentó en la orilla."

# game/script.rpy:4386
translate spanish dont_touch_the_water_1f4ebd0a:

    # p2 "Неловко... Похоже он злится на меня, так что я чувствую себя виноват[p2_verb_oy_iim()], хотя я ничего плохого не сделал[p2_verb_a()]..."
    p2 "Incómodo... Parece que está enfadado conmigo, así que me siento culpable, aunque no hice nada malo..."

# game/script.rpy:4387
translate spanish dont_touch_the_water_db0dc8e5:

    # s "Я всегда хотел только лучшего для тебя."
    s "Siempre solo quise lo mejor para ti."

# game/script.rpy:4388
translate spanish dont_touch_the_water_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:4390
translate spanish dont_touch_the_water_0726f1bc:

    # s rsad4 "Ты не веришь мне..."
    s rsad4 "No me crees..."

# game/script.rpy:4391
translate spanish dont_touch_the_water_e8d14ec2:

    # p "Я не могу быть в этом уверен[p2_verb_na()]. Ведь я ничего не помню о том лете, почему я долж[p2_verb_na_en()] верить тебе?"
    p "No puedo estar segur[letra] de eso. No recuerdo nada de aquel verano, así que ¿por qué debería creerte?"

# game/script.rpy:4392
translate spanish dont_touch_the_water_b2e8f17a:

    # s rsad5 "Ты не веришь мне."
    s rsad5 "No me crees."

# game/script.rpy:4393
translate spanish dont_touch_the_water_ace2b548:

    # p "Нет, я думаю, что ты можешь говорить только то, что удобно тебе"
    p "No, creo que quizás solo estás diciendo lo que te conviene."

# game/script.rpy:4394
translate spanish dont_touch_the_water_fdb08013:

    # s rsad4 "С чего ты взял[p2_verb_a()], что я буду тебе врать??"
    s rsad4 "¿¿Qué te hace pensar que te mentiría??"

# game/script.rpy:4395
translate spanish dont_touch_the_water_98cd38af:

    # p "Разговор с дедушкой. Он сказал, что тем летом я избегал[p2_verb_a()] тебя. Почему?"
    p "Mi conversación con el abuelo. Dijo que te evitaba aquel verano. ¿Por qué?"

# game/script.rpy:4397
translate spanish dont_touch_the_water_7e5072bb:

    # s rang3 "Да этот старик мог просто что-то придумать или перепутать!!"
    s rang3 "¡¡Ese anciano podría simplemente haberse inventado algo o haber confundido las cosas!!"

# game/script.rpy:4400
translate spanish dont_touch_the_water_e9836271:

    # p "Может быть и правда дедушка что-то напутал..."
    p "Quizás el abuelo sí se confundió..."

# game/script.rpy:4402
translate spanish dont_touch_the_water_243cae74:

    # s rsad4 "Не сомневайся во мне, я причина по которой ты вообще жив[p2_verb_a()]."
    s rsad4 "No dudes de mí. Soy la razón por la que sigues viv[letra]."

# game/script.rpy:4403
translate spanish dont_touch_the_water_a80c3b6d:

    # p "Что ты имеешь ввиду!?"
    p "¿¡Qué quieres decir!?"

# game/script.rpy:4404
translate spanish dont_touch_the_water_0ac23da4:

    # s rsad5 "Я спас тебя тогда. Когда ты чуть не утонул[p2_verb_a()]. "
    s rsad5 "Te salvé en aquel entonces. Cuando casi te ahogas."

# game/script.rpy:4405
translate spanish dont_touch_the_water_5da19759:

    # p "Что!? Правда!?"
    p "¡¿Qué!? ¿¡De verdad!?"

# game/script.rpy:4406
translate spanish dont_touch_the_water_37f06c1a:

    # p "Но почему ты не говорил мне!?"
    p "¿¡Entonces por qué no me lo dijiste!?"

# game/script.rpy:4407
translate spanish dont_touch_the_water_923df604:

    # s "Потому что я винил себя за то, что не спас тебя сразу! Из-за меня у тебя теперь эта гребанная фобия воды, память отшибло, и твои родители не давали тебе видеться с дедом!!"
    s "¡Porque me echaba la culpa por no salvarte de inmediato! Por mi culpa, ahora tienes esta maldita fobia al agua, se te borró la memoria, ¡¡y tus padres no te dejaron ver a tu abuelo!!"

# game/script.rpy:4408
translate spanish dont_touch_the_water_b00c726f:

    # p "Но если все так, то ты не виноват, что я упал[p2_verb_a()] в воду..."
    p "Pero si eso fue lo que pasó, entonces no es tu culpa que me cayera al agua..."

# game/script.rpy:4409
translate spanish dont_touch_the_water_8a1830a7:

    # s "Я..."
    s "Yo..."

# game/script.rpy:4410
translate spanish dont_touch_the_water_2031e8f2:

    # s "Д-да.... Но..."
    s "S-sí... Pero..."

# game/script.rpy:4411
translate spanish dont_touch_the_water_954269a4:

    # s "Все должно было быть иначе..."
    s "Se suponía que sería diferente..."

# game/script.rpy:4412
translate spanish dont_touch_the_water_f08ba1a8:

    # p2 "Он говорит правду? Почему дедушка об этом не упоминал? Может он просто не особо хотел вспоминать, а Сайлас говорит мне правду?"
    p2 "¿Está diciendo la verdad? ¿Por qué el abuelo no lo mencionó? Quizás simplemente no quería recordarlo de verdad, ¿y Silas me está diciendo la verdad?"

# game/script.rpy:4413
translate spanish dont_touch_the_water_3030fad2:

    # p2 "Нужно сменить тему, разберусь с этим позже."
    p2 "Necesito cambiar de tema. Ya averiguaré esto más tarde."

# game/script.rpy:4414
translate spanish dont_touch_the_water_8594a208:

    # p "Ну... А как мы познакомились?"
    p "Bueno... ¿Cómo nos conocimos?"

# game/script.rpy:4416
translate spanish dont_touch_the_water_fdc3f658:

    # p2 "Он, кажется, расслабился от этого вопроса."
    p2 "Pareció relajarse con esa pregunta."

# game/script.rpy:4417
translate spanish dont_touch_the_water_0f6a9e56:

    # s "Тем летом я узнал, что в деревню приехал[p2_verb_a()] мо[p2_verb_ya_y()] [p2_verb_rov()], мне стало любопытно, я пришел познакомиться и мы сразу подружились."
    s "Aquel verano, me enteré de que alguien de mi edad había venido al pueblo. Me dio curiosidad, vine a conocerte y nos hicimos amigos de inmediato."

# game/script.rpy:4418
translate spanish dont_touch_the_water_26d07b6c:

    # p2 "Это звучит более реалистично, чем все, что он говорит, так что не думаю, что он лжет. "
    p2 "Eso sonaba más realista que todo lo demás que dijo, así que no creo que estuviera mintiendo."

# game/script.rpy:4419
translate spanish dont_touch_the_water_9aca06e6:

    # s "Хоть сейчас ты веришь мне?"
    s "¿Me crees ahora, al menos?"

# game/script.rpy:4420
translate spanish dont_touch_the_water_be044597:

    # p "Да... Верю... "
    p "Sí... Te creo..."

# game/script.rpy:4421
translate spanish dont_touch_the_water_3ef848a8:

    # p "Прости за то, что я вспылил..."
    p "Perdón por estallar..."

# game/script.rpy:4422
translate spanish dont_touch_the_water_ab3bfb6b:

    # s rsad3 "Все в порядке, я должен понимать, как сложно тебе собрать все в кучу, и полагаю сложно верить тому, кто, как тебе кажется, знаком с тобой пару дней…"
    s rsad3 "Está bien. Debería entender lo difícil que es para ti unir todas las piezas. Y supongo que es difícil confiar en alguien que, para ti, es como si solo lo conocieras desde hace un par de días..."

# game/script.rpy:4423
translate spanish dont_touch_the_water_95773775:

    # s rcalm2 "Ладно, давай не будем грустить, раз не хочешь идти в воду, то и не надо, но я не позволю тебе отказаться от того, чтобы провести время у костра."
    s rcalm2 "Muy bien, no estemos tristes. Si no quieres meterte en el agua, no tienes que hacerlo. Pero no te dejaré negarte a pasar tiempo junto al fuego."

# game/script.rpy:4424
translate spanish dont_touch_the_water_6991a22c:

    # p2 "Я улыбнул[p2_verb_as()]."
    p2 "Sonreí."

# game/script.rpy:4425
translate spanish dont_touch_the_water_24ab55b9:

    # p "Конечно."
    p "Por supuesto."

# game/script.rpy:4431
translate spanish dont_touch_the_water_6f772931:

    # p2 "Сайлас разжег костер, мы сидели у него до вечера, болтая абсолютно о всем, я узнал[p2_verb_a()] его лучше, он снова стал спокойным и добродушным."
    p2 "Silas encendió una hoguera, y nos sentamos junto a ella hasta el anochecer, hablando de absolutamente todo. Lo conocí mejor, y volvió a estar tranquil[letra] y de buen humor."

# game/script.rpy:4433
translate spanish dont_touch_the_water_49695f6b:

    # p2 "Он наклонился и поцеловал меня в щеку."
    p2 "Se inclinó y me besó en la mejilla."

# game/script.rpy:4434
translate spanish dont_touch_the_water_bb813289:

    # s "Ты так[p2_verb_aya_oy()] мягк[p2_verb_aya_iy()], я бы целовал тебя постоянно, везде, каждую частичку тебя."
    s "Eres tan suave. Podría besarte constantemente, por todas partes, cada pequeña parte de ti."

# game/script.rpy:4435
translate spanish dont_touch_the_water_6413e8c7:

    # p "Прекрати… Это смущает..."
    p "Para... Eso es vergonzoso..."

# game/script.rpy:4437
translate spanish dont_touch_the_water_165451cc:

    # p2 "Он потерся головой о мое плечо, выглядя таким милым, как кот."
    p2 "Frotó su cabeza contra mi hombro, pareciendo tan adorable como un gato."

# game/script.rpy:4438
translate spanish dont_touch_the_water_434bff09:

    # p "Ты снова сегодня останешься у меня?"
    p "¿Te vas a quedar a dormir otra vez esta noche?"

# game/script.rpy:4439
translate spanish dont_touch_the_water_308e4c46:

    # s swcalm "Может быть. А может, знаешь, переночуем тут?"
    s swcalm "Quizás. O quizás, ya sabes, ¿podríamos pasar la noche aquí?"

# game/script.rpy:4440
translate spanish dont_touch_the_water_61356717:

    # p "На улице? Даже без спальников? "
    p "¿Afuera? ¿Sin siquiera sacos de dormir?"

# game/script.rpy:4441
translate spanish dont_touch_the_water_db407855:

    # s "Ну да, вообще-то это романтично."
    s "Bueno, sí. En realidad, es romántico."

# game/script.rpy:4442
translate spanish dont_touch_the_water_fcf14add:

    # p "Но мы не покормили животных."
    p "Pero aún no hemos alimentado a los animales."

# game/script.rpy:4443
translate spanish dont_touch_the_water_05f1d589:

    # s "Да, ты прав[p2_verb_a()], отправимся обратно, покормим их и вернемся сюда."
    s "Sí, tienes razón. Volveremos, les daremos de comer y volveremos aquí."

# game/script.rpy:4446
translate spanish dont_touch_the_water_a939c705:

    # p2 "Мы отправились на ферму, покормили животных, взяли спальники и еду, а потом отправились к заливу, потому что там было тише, чем у реки."
    p2 "Volvimos a la granja, alimentamos a los animales, tomamos los sacos de dormir y la comida, y luego nos dirigimos a la bahía porque allí era más tranquilo que junto al río."

# game/script.rpy:4453
translate spanish dont_touch_the_water_92b1752a:

    # p2 "Глаза быстро привыкли к темноте, как только я лег[p2_verb_la()] в спальник, то увидел[p2_verb_a()], как маленькие огоньки поднимались над травой."
    p2 "Mis ojos se adaptaron rápidamente a la oscuridad. En cuanto me acosté en mi saco de dormir, vi pequeñas luces elevándose sobre la hierba."

# game/script.rpy:4454
translate spanish dont_touch_the_water_a7fbdbaf:

    # p "Как красиво... В городе такого не увидишь..."
    p "Es tan hermoso... No se ve esto en la ciudad..."

# game/script.rpy:4455
translate spanish dont_touch_the_water_304f343d:

    # s "Согласен, это одна из причин жить в деревне. "
    s "Estoy de acuerdo. Es una de las razones para vivir en el pueblo."

# game/script.rpy:4456
translate spanish dont_touch_the_water_b32e39d9:

    # s "Я бы хотел, чтобы этот момент длился вечно. Хочу всегда быть рядом с тобой, не хочу, чтобы ты снова оставил[p2_verb_a()] меня."
    s "Ojalá este momento pudiera durar para siempre. Quiero estar siempre a tu lado. No quiero que me dejes otra vez."

# game/script.rpy:4457
translate spanish dont_touch_the_water_cb9bcaba:

    # p "Но мне нужно будет вернуться в город в конце лета."
    p "Pero tendré que volver a la ciudad al final del verano."

# game/script.rpy:4458
translate spanish dont_touch_the_water_e53aea47:

    # p "Я буду приезжать каждый отпуск, не беспокойся."
    p "Te visitaré en cada descanso, no te preocupes."

# game/script.rpy:4459
translate spanish dont_touch_the_water_1abb679a:

    # s "Этого чертовски мало... Может останешься здесь..?"
    s "Eso no es ni de lejos suficiente... ¿Quizás podrías quedarte aquí..?"

# game/script.rpy:4460
translate spanish dont_touch_the_water_daab362c:

    # p "Я всю жизнь прожил[p2_verb_a()] в городе, я не думаю, что у меня получится прижиться тут."
    p "He vivido en la ciudad toda mi vida. No creo que pudiera vivir aquí."

# game/script.rpy:4461
translate spanish dont_touch_the_water_4acbcb62:

    # s "Тогда... Может я поеду с тобой..?"
    s "Entonces... ¿quizás podría irme contigo..?"

# game/script.rpy:4462
translate spanish dont_touch_the_water_1022be9f:

    # p "Со мной? Но ты же тоже привык к тому месту, где вырос."
    p "¿Conmigo? Pero estás acostumbrado al lugar donde creciste."

# game/script.rpy:4463
translate spanish dont_touch_the_water_2156a871:

    # s "Мое место не здесь. И даже не в городе. Мое место с тобой."
    s "Mi lugar no está aquí. Y tampoco está en la ciudad. Mi lugar está contigo."

# game/script.rpy:4464
translate spanish dont_touch_the_water_75e990ee:

    # p2 "Я не слушал[p2_verb_a()] ничего более романтичного, мои щеки покраснели, и я чувствовал[p2_verb_a()], как они становятся теплее."
    p2 "Nunca había oído nada más romántico. Mis mejillas se sonrojaron y podía sentir cómo se calentaban."

# game/script.rpy:4465
translate spanish dont_touch_the_water_1bc70430:

    # p "Ты правда хочешь..."
    p "De verdad quieres..."

# game/script.rpy:4466
translate spanish dont_touch_the_water_d4f59848:

    # s "Да. Хочу быть с тобой, не важно где. Даже если ты улетишь на Марс, я полечу с тобой."
    s "Sí. Quiero estar contigo, sin importar dónde. Incluso si vuelas a Marte, volaré contigo."

# game/script.rpy:4467
translate spanish dont_touch_the_water_acc2bec8:

    # p2 "У меня не было выбора, пусть мозг сопротивлялся, но сердце согласилось, я хотел[p2_verb_a()], чтобы это было правдой."
    p2 "No tuve más remedio. Mi cerebro se resistía, pero mi corazón aceptó. Quería que fuera verdad."

# game/script.rpy:4507
translate spanish dont_touch_the_water_512dd55b:

    # dream3 "{sc=2}Т-ты... Как ты мог[p2_verb_la()]!? Я так любил тебя!!{/sc}"
    dream3 "{sc=2}¿¡T-tú... ¿Cómo pudiste!? ¡¡Te quería tanto!!{/sc}"

# game/script.rpy:4508
translate spanish dont_touch_the_water_6ee80b6b:

    # dream3 "Я пытал[p2_verb_as()] ответить, что не изменял[p2_verb_a()] ему, но воздух не мог пройти через мое горло, сдавленное его руками."
    dream3 "Traté de responderle que no lo había engañado, pero no me salía el aire por la garganta, que tenía apretada por sus manos."

# game/script.rpy:4509
translate spanish dont_touch_the_water_a0e7bb90:

    # dream3 "Я снова не могу дышать... Как тогда... Тем летом…"
    dream3 "No puedo respirar otra vez... Igual que entonces... Aquel verano..."

# game/script.rpy:4527
translate spanish dont_touch_the_water_098f0432:

    # p "Почему я долж[p2_verb_na_en()] считать, что именно дедушка ошибся? Может мне спросить кого-то другого в деревне, чтобы узнать про тебя!?"
    p "¿Por qué se supone que debo asumir que el abuelo es el que se equivocó? ¿¡Quizás debería preguntarle a alguien más del pueblo sobre ti!?"

# game/script.rpy:4529
translate spanish dont_touch_the_water_b490fec2:

    # s "Нет. Ты не посмеешь."
    s "No. No te atreverías."

# game/script.rpy:4530
translate spanish dont_touch_the_water_730611d8:

    # p "Почему!?"
    p "¿¡Por qué!?"

# game/script.rpy:4531
translate spanish dont_touch_the_water_180d6ca8:

    # s "Потому что... Нет, ты просто не можешь. Это ведь нарушит доверие между нами.."
    s "Porque... No, simplemente no puedes. Eso rompería la confianza entre nosotros..."

# game/script.rpy:4532
translate spanish dont_touch_the_water_2b97d848:

    # p "Между нами нет доверия! "
    p "¡No hay confianza entre nosotros!"

# game/script.rpy:4533
translate spanish dont_touch_the_water_0ed09dfb:

    # s rang4 "Снова..."
    s rang4 "Otra vez..."

# game/script.rpy:4534
translate spanish dont_touch_the_water_e8127d47:

    # p "Что снова?"
    p "¿Otra vez qué?"

# game/script.rpy:4535
translate spanish dont_touch_the_water_d00f8693:

    # s "Все повторяется снова!! "
    s "¡¡Está pasando todo otra vez!!"

# game/script.rpy:4536
translate spanish dont_touch_the_water_a6c21676:

    # s "Ты снова не можешь просто прислушаться ко мне, не можешь принять мою сторону!!"
    s "¡Otra vez, no puedes simplemente escucharme! ¡¡No puedes ponerte de mi lado!!"

# game/script.rpy:4540
translate spanish dont_touch_the_water_53f8cb8d:

    # s rner "..."
    s rner "..."

# game/script.rpy:4546
translate spanish dont_touch_the_water_6f2d1d77:

    # s rner3 "Ты предал[p2_verb_a()] нашу дружбу."
    s rner3 "Traicionaste nuestra amistad."

# game/script.rpy:4547
translate spanish dont_touch_the_water_3e82d9b8:

    # p "Что!? Как!?"
    p "¿¡Qué!? ¿¡Cómo!?"

# game/script.rpy:4548
translate spanish dont_touch_the_water_abf99430:

    # s "Ты бросил[p2_verb_a()] меня."
    s "Me abandonaste."

# game/script.rpy:4549
translate spanish dont_touch_the_water_51ba146a:

    # p "Н-но... Почему?"
    p "P-pero... ¿por qué?"

# game/script.rpy:4550
translate spanish dont_touch_the_water_84d287cb:

    # s "Ты сказал[p2_verb_a()], что я слишком прилипчивый, слишком раздражающий, что я тебе больше не нужен."
    s "Dijiste que era demasiado intenso, demasiado molesto, que ya no me necesitabas."

# game/script.rpy:4551
translate spanish dont_touch_the_water_063cbfa0:

    # s rsad6 "Я просто очень люблю тебя..."
    s rsad6 "Es que te amo tanto..."

# game/script.rpy:4553
translate spanish dont_touch_the_water_5e6ade9b:

    # s "Всегда любил..."
    s "Siempre lo he hecho..."

# game/script.rpy:4554
translate spanish dont_touch_the_water_806d7f1a:

    # s rsad5 "Я пытался все наладить... Но ты только сильнее отдалял[p2_verb_as()] от меня... И..."
    s rsad5 "Intenté arreglarlo todo... Pero solo te alejabas más de mí... Y..."

# game/script.rpy:4555
translate spanish dont_touch_the_water_42be8983:

    # p "Что..? Что было дальше..?"
    p "¿Qué..? ¿Qué pasó después..?"

# game/script.rpy:4556
translate spanish dont_touch_the_water_6090d634:

    # s "Тот сарай... Который я сегодня тебе показал..."
    s "Ese granero... El que te mostré hoy..."

# game/script.rpy:4557
translate spanish dont_touch_the_water_ece14712:

    # s rmad "Я запер тебя там... "
    s rmad "Te encerré allí..."

# game/script.rpy:4558
translate spanish dont_touch_the_water_8192ce1f:

    # p "Зачем..?"
    p "¿Por qué..?"

# game/script.rpy:4559
translate spanish dont_touch_the_water_651dbc72:

    # s rmad2 "Чтобы у тебя было время понять, что ты любишь меня..."
    s rmad2 "Para que tuvieras tiempo de entender que me amabas..."

# game/script.rpy:4560
translate spanish dont_touch_the_water_f14703c6:

    # s rmad "Но ты отказывал[p2_verb_as()] признавать свои чувства ко мне..."
    s rmad "Pero te negaste a admitir tus sentimientos por mí..."

# game/script.rpy:4565
translate spanish dont_touch_the_water_868ace44:

    # s "А Я ЧУВСТВОВАЛ, Я ВИДЕЛ ЛЮБОВЬ В ТВОИХ ГЛАЗАХ, КОТОРУЮ ТЫ ПЫТАЕШЬСЯ ПОДАВИТЬ!!"
    s "¡¡PERO LO SENTÍ!! ¡¡VI EL AMOR EN TUS OJOS, EL AMOR QUE INTENTABAS ENTERRAR!!"

# game/script.rpy:4569
translate spanish dont_touch_the_water_940b56d7:

    # p2 "Я бросил[p2_verb_as()] бежать, мысли переполняли мою голову, но их перебивал инстинкт бежать, иначе со мной случится что-то плохое."
    p2 "Empecé a correr. Los pensamientos inundaban mi cabeza, pero eran ahogados por el instinto de huir, o algo terrible me pasaría."

# game/script.rpy:4573
translate spanish dont_touch_the_water_940b56d7_1:

    # p2 "Я бросил[p2_verb_as()] бежать, мысли переполняли мою голову, но их перебивал инстинкт бежать, иначе со мной случится что-то плохое."
    p2 "Empecé a correr. Los pensamientos inundaban mi cabeza, pero eran ahogados por el instinto de huir, o algo terrible me pasaría."

# game/script.rpy:4577
translate spanish dont_touch_the_water_940b56d7_2:

    # p2 "Я бросил[p2_verb_as()] бежать, мысли переполняли мою голову, но их перебивал инстинкт бежать, иначе со мной случится что-то плохое."
    p2 "Empecé a correr. Los pensamientos inundaban mi cabeza, pero eran ahogados por el instinto de huir, o algo terrible me pasaría."

# game/script.rpy:4581
translate spanish dont_touch_the_water_830aa237:

    # p2 "Я успел[p2_verb_a()] добежать до дома, закрыв дверь прямо перед его носом. Не успев вздохнуть, я вспомнил[p2_verb_a()], что есть задняя дверь... Я помчал[p2_verb_as()] к ней, но..."
    p2 "Logré llegar a la casa y cerrarle la puerta en las narices. Antes de que pudiera recuperar el aliento, recordé la puerta trasera... Corrí hacia ella, pero..."

# game/script.rpy:4585
translate spanish dont_touch_the_water_52166b06:

    # p2 "Я рефлекторно шагнул[p2_verb_a()] назад, но он бросился на меня."
    p2 "Retrocedí instintivamente, pero él se abalanzó sobre mí."

# game/script.rpy:4588
translate spanish dont_touch_the_water_90b24af3:

    # p2 "Смотря на его лицо, перекошенное от гнева и чего-то похожего на одержимость, я не мог[p2_verb_la()] заставить себя сказать хоть что-то."
    p2 "Al mirar su rostro, retorcido por la ira y algo parecido a la obsesión, no pude obligarme a decir nada."

# game/script.rpy:4589
translate spanish dont_touch_the_water_0b7f651d:

    # p2 "Он тяжело дышал и крепко сжимал мои запястья, удерживая меня под собой."
    p2 "Respiraba con dificultad, sujetando mis muñecas con fuerza e inmovilizándome bajo él."

# game/script.rpy:4590
translate spanish dont_touch_the_water_5b024183:

    # p2 "Мне нужно было что-то делать, необходимо решать быстро."
    p2 "Tenía que hacer algo. Tenía que decidir rápido."

# game/script.rpy:4598
translate spanish dont_touch_the_water_7aefb515:

    # p2 "Я согнул[p2_verb_a()] ногу в колене и упер[p2_verb_las_sya()] в его грудь, попытавшись оттолкнуть. "
    p2 "Doblé la rodilla y presioné mi pie contra su pecho, intentando empujarlo."

# game/script.rpy:4601
translate spanish dont_touch_the_water_3a29c2b8:

    # s "Хорошая попытка, Солнышко."
    s "Buen intento, Solecito."

# game/script.rpy:4605
translate spanish dont_touch_the_water_8aec623f:

    # p "ААААА САЙЛАС!!!"
    p "¡¡¡AAAAAH, SILAS!!!"

# game/script.rpy:4606
translate spanish dont_touch_the_water_746b0ac9:

    # s hamad5 "Тише, не кричи так..."
    s hamad5 "Shh, no grites así..."

# game/script.rpy:4607
translate spanish dont_touch_the_water_4200f3b0:

    # p2 "Я прикусил[p2_verb_a()] губу, стараясь не издавать звуков, чтобы не разозлить его еще сильнее. "
    p2 "Me mordí el labio, intentando no hacer ningún sonido para no enfadarlo aún más."

# game/script.rpy:4608
translate spanish dont_touch_the_water_632f7caf:

    # s "Ты знаешь притчу о непослушном ягненке? "
    s "¿Conoces la parábola del cordero desobediente?"

# game/script.rpy:4609
translate spanish dont_touch_the_water_c8ea8a4a_1:

    # p "..."
    p "..."

# game/script.rpy:4610
translate spanish dont_touch_the_water_76b540b3:

    # s "Ягненок не слушался пастуха, убегал от него..."
    s "El cordero no escuchaba al pastor. Seguía huyendo de él..."

# game/script.rpy:4611
translate spanish dont_touch_the_water_bfb4eb4e:

    # s "Пастух сломал ягненку ножки и выхаживал его, заботясь о нем целыми днями. "
    s "Así que el pastor le rompió las patas al cordero y lo cuidó hasta que se recuperó, atendiéndolo día tras día."

# game/script.rpy:4612
translate spanish dont_touch_the_water_299fe81c:

    # s "Ягненок понял, что не смог бы выжить без пастуха и стал послушным. "
    s "El cordero se dio cuenta de que no podía sobrevivir sin el pastor, y se volvió obediente."

# game/script.rpy:4618
translate spanish dont_touch_the_water_301bf3b2:

    # s hamad6 "Ты станешь моим ягненком."
    s hamad6 "Te convertirás en mi cordero."

# game/script.rpy:4636
translate spanish dont_touch_the_water_ad317508:

    # p2 "Я согнул[p2_verb_a()] ногу в колене, упер[p2_verb_las_sya()] в его грудь и резко оттолкнул[p2_verb_a()] его."
    p2 "Doblé la rodilla, presioné mi pie contra su pecho y lo empujé con fuerza."

# game/script.rpy:4644
translate spanish dont_touch_the_water_1040f2e4:

    # p2 "Я замер[p2_verb_la()], а потом попытал[p2_verb_as()] резко вырвать руки из его хватки. "
    p2 "Me congelé, luego intenté zafar mis manos de su agarre."

# game/script.rpy:4645
translate spanish dont_touch_the_water_ba68b366:

    # p2 "У меня... Не вышло..."
    p2 "No... funcionó..."

# game/script.rpy:4646
translate spanish dont_touch_the_water_b72a2042:

    # s hakon "Прекрати..."
    s hakon "Para..."

# game/script.rpy:4647
translate spanish dont_touch_the_water_8acbb627:

    # s "Прекрати пытаться убежать от меня..."
    s "Deja de intentar huir de mí..."

# game/script.rpy:4648
translate spanish dont_touch_the_water_24775e16:

    # s "Ты не можешь, ты ничего без меня не можешь. "
    s "No puedes. No puedes hacer nada sin mí."

# game/script.rpy:4650
translate spanish dont_touch_the_water_34d27c26:

    # s hakon2 "Прекрати сопротивляться и я сделаю тебя самым счастливым человеком на свете..."
    s hakon2 "Deja de resistirte, y te haré la persona más feliz del mundo..."

# game/script.rpy:4651
translate spanish dont_touch_the_water_4dbce49a:

    # p "Сайлас... Я не могу... "
    p "Silas... No puedo..."

# game/script.rpy:4652
translate spanish dont_touch_the_water_c2d4e7ce:

    # s "Это не так сложно. Веди себя хорошо, и я никогда не сделаю тебе больно..."
    s "No es tan difícil. Pórtate bien, y nunca te haré daño..."

# game/script.rpy:4653
translate spanish dont_touch_the_water_4653ab2a:

    # s "Разве это сложно? "
    s "¿Es tan difícil?"

# game/script.rpy:4654
translate spanish dont_touch_the_water_a31db96b:

    # s "Я обеспечу тебя всем, что тебе нужно. Любовь, забота, верность, деньги, радость."
    s "Te daré todo lo que necesites. Amor, cuidado, lealtad, dinero, felicidad."

# game/script.rpy:4655
translate spanish dont_touch_the_water_681e7121:

    # s "Я дам тебе все, так почему ты отказываешься от этого?"
    s "Te lo daré todo, así que ¿por qué lo rechazas?"

# game/script.rpy:4656
translate spanish dont_touch_the_water_03e273c9:

    # p "Ты не дашь мне самого главного...{w} Свободы..."
    p "No me darás lo más importante...{w} Libertad..."

# game/script.rpy:4660
translate spanish dont_touch_the_water_e8ddee98:

    # s hakon2 "Почему нет? Ты сможешь выбирать, что будешь есть, что смотреть, куда мы будем ходить."
    s hakon2 "¿Por qué no? Podrás elegir qué comes, qué ves, a dónde vamos."

# game/script.rpy:4661
translate spanish dont_touch_the_water_0679c820:

    # p "Но..."
    p "Pero..."

# game/script.rpy:4663
translate spanish dont_touch_the_water_de18863b:

    # s hakon4 "Что \"но\"?"
    s hakon4 "¿Pero qué?"

# game/script.rpy:4664
translate spanish dont_touch_the_water_f82c5778:

    # s "Тебе этого недостаточно? "
    s "¿No es suficiente para ti?"

# game/script.rpy:4665
translate spanish dont_touch_the_water_e9c6a230:

    # s "Ты хочешь свободу трахаться с кем хочешь, да!?"
    s "¿¡Quieres tener la libertad de tener sexo con quien quieras, es eso!?"

# game/script.rpy:4667
translate spanish dont_touch_the_water_6fa34336:

    # s hakon5 "ЭТО ЕДИНСТВЕННОЕ, ЧТО Я ТЕБЕ НЕ ПОЗВОЛЮ!!!"
    s hakon5 "¡¡¡ESO ES LO ÚNICO QUE NO TE DEJARÉ HACER!!!"

# game/script.rpy:4668
translate spanish dont_touch_the_water_5655ae15:

    # p "Нет, Сайлас, я бы не посмел[p2_verb_a()]!"
    p "¡No, Silas, no me atrevería!"

# game/script.rpy:4669
translate spanish dont_touch_the_water_832e7cc7:

    # s hakon4 "Не посмел[p2_verb_a()]? Значит хотел[p2_verb_a()] бы, но не стал[p2_verb_a()]? "
    s hakon4 "¿No te atreverías? ¿Entonces te gustaría, pero no lo harías?"

# game/script.rpy:4670
translate spanish dont_touch_the_water_a657605b:

    # p "Нет, я не это имею ввиду!!"
    p "¡¡No, no es eso lo que quiero decir!!"

# game/script.rpy:4671
translate spanish dont_touch_the_water_ff9ee7dc:

    # s "Хорошо... Ладно..."
    s "Vale... Bien..."

# game/script.rpy:4672
translate spanish dont_touch_the_water_cabfd443:

    # s "Просто ответь мне..."
    s "Solo respóndeme..."

# game/script.rpy:4673
translate spanish dont_touch_the_water_4bcd3453:

    # s "Ты соглас[p2_verb_na_en()] быть счастлив[p2_verb_oy_iim()] со мной?"
    s "¿Aceptas ser feliz conmigo?"

# game/script.rpy:4674
translate spanish dont_touch_the_water_dde6b098:

    # p "Я... "
    p "Yo..."

# game/script.rpy:4678
translate spanish dont_touch_the_water_031dbb97:

    # p "Соглас[p2_verb_na_en()]..."
    p "Acepto..."

# game/script.rpy:4690
translate spanish dont_touch_the_water_2238287d:

    # p2 "Я замер[p2_verb_la()], а затем резко дернул[p2_verb_a()] руками, выскользнув из его хватки."
    p2 "Me congelé, luego sacudí los brazos con fuerza y me deslicé fuera de su agarre."

# game/script.rpy:4694
translate spanish dont_touch_the_water_93d16e95:

    # p "С-Сайлас... Послушай меня..."
    p "S-Silas... Escúchame..."

# game/script.rpy:4695
translate spanish dont_touch_the_water_45fb55d7:

    # p2 "На мгновение его хватка ослабла, но затем снова усилилась."
    p2 "Por un momento, su agarre se aflojó, pero luego se tensó de nuevo."

# game/script.rpy:4696
translate spanish dont_touch_the_water_9e2b0a09:

    # p "Я просто испугал[p2_verb_as()]... Я понимаю твои чувства, ты поступил неправильно, но я понимаю..."
    p "Solo me asusté... Entiendo tus sentimientos. Lo que hiciste estuvo mal, pero lo entiendo..."

# game/script.rpy:4697
translate spanish dont_touch_the_water_0ba70233:

    # s hakon4 "Ты пытаешься мне зубы заговорить?"
    s hakon4 "¿Estás intentando salir de esta hablando?"

# game/script.rpy:4698
translate spanish dont_touch_the_water_1f76fad0:

    # p2 "Я знал[p2_verb_a()], что нельзя отводить взгляд, когда врешь, но все равно неосознанно сделал[p2_verb_a()] это."
    p2 "Sabía que no se debe apartar la mirada cuando se miente, pero aun así lo hice sin pensarlo."

# game/script.rpy:4700
translate spanish dont_touch_the_water_74191985:

    # s hakon5 "ТЫ [p2_verb_liar()]!!!"
    s hakon5 "¡¡¡ERES [arti_2_ma] MENTIROS[letra_ma]!!!"

# game/script.rpy:4701
translate spanish dont_touch_the_water_706357af:

    # s "ТЫ МЕНЯ НЕ ПОНИМАЕШЬ!!! "
    s "¡¡¡NO ME ENTIENDES!!!"

# game/script.rpy:4702
translate spanish dont_touch_the_water_aa27d83d:

    # s "ТЫ НИКОГДА НЕ ПОЙМЕШЬ!!!"
    s "¡¡¡NUNCA LO HARÁS!!!"

# game/script.rpy:4703
translate spanish dont_touch_the_water_648c0f1c:

    # s hakon4 "Ты никогда... никогда... никогда не полюбишь меня, верно..?"
    s hakon4 "Nunca... nunca... nunca me amarás, ¿verdad...?"

# game/script.rpy:4704
translate spanish dont_touch_the_water_3d51713f:

    # p "Сайлас..."
    p "Silas..."

# game/script.rpy:4705
translate spanish dont_touch_the_water_5cbb56e7:

    # s "Вопрос риторический. "
    s "Esa era una pregunta retórica."

# game/script.rpy:4707
translate spanish dont_touch_the_water_de448b11:

    # p2 "Он потянулся к моему горлу."
    p2 "Alcanzó mi garganta."

# game/script.rpy:4708
translate spanish dont_touch_the_water_f3f0853a:

    # p "Я ЛЮБЛЮ ТЕБЯ!!!"
    p "¡¡¡TE AMO!!!"

# game/script.rpy:4710
translate spanish dont_touch_the_water_3f6dafee:

    # s "нет.{w=0.7} не любишь. "
    s "no.{w=0.7} no lo haces."

# game/script.rpy:4727
translate spanish dont_touch_the_water_93d16e95_1:

    # p "С-Сайлас... Послушай меня..."
    p "S-Silas... Escúchame..."

# game/script.rpy:4728
translate spanish dont_touch_the_water_45fb55d7_1:

    # p2 "На мгновение его хватка ослабла, но затем снова усилилась."
    p2 "Por un momento, su agarre se aflojó, pero luego se tensó de nuevo."

# game/script.rpy:4729
translate spanish dont_touch_the_water_9e2b0a09_1:

    # p "Я просто испугал[p2_verb_as()]... Я понимаю твои чувства, ты поступил неправильно, но я понимаю..."
    p "Solo me asusté... Entiendo tus sentimientos. Lo que hiciste estuvo mal, pero lo entiendo..."

# game/script.rpy:4730
translate spanish dont_touch_the_water_0ba70233_1:

    # s hakon4 "Ты пытаешься мне зубы заговорить?"
    s hakon4 "¿Estás intentando salir de esta hablando?"

# game/script.rpy:4731
translate spanish dont_touch_the_water_aeabc5fc:

    # p "Н-нет... Я правда понимаю... Ты так отчаялся, у тебя не было другого выхода..."
    p "N-no... De verdad lo entiendo... Estabas tan desesperado, no tenías otra opción..."

# game/script.rpy:4732
translate spanish dont_touch_the_water_27d73371:

    # s hasad "Мне было очень больно, когда ты отвергал[p2_verb_a()] меня раз за разом..."
    s hasad "Dolió tanto cuando me rechazaste una y otra vez..."

# game/script.rpy:4734
translate spanish dont_touch_the_water_d61b1eac:

    # p "Я был[p2_verb_a()] ребенком, мне не была интересна любовь... Но теперь все иначе... Я понимаю, какого тебе было, как любовь может ранить..."
    p "Era [arti_2] niñ[letra]. No me interesaba el amor... Pero ahora las cosas son diferentes... Entiendo cómo era para ti, cómo puede doler el amor..."

# game/script.rpy:4735
translate spanish dont_touch_the_water_75f34369:

    # p2 "Я несу полную чушь, но мне кажется, что это единственный способ выжить сейчас..."
    p2 "Estoy diciendo tonterías, pero siento que es la única forma de sobrevivir en este momento..."

# game/script.rpy:4736
translate spanish dont_touch_the_water_f4c468a4:

    # p2 "Я пытал[p2_verb_as()] прочитать мысли по его лицу, но я вообще не мог[p2_verb_la()] понять, что у него в голове."
    p2 "Intenté leer sus pensamientos en su rostro, pero no podía entender en absoluto lo que pasaba por su cabeza."

# game/script.rpy:4739
translate spanish dont_touch_the_water_95311821:

    # p2 "Внезапно он поцеловал меня, и я ответил[p2_verb_a()] на поцелуй. Это ощущалось неприятно, все чувства обострились, так что я чувствовал[p2_verb_a()] каждое движение его языка у меня во рту."
    p2 "De repente, me besó, y le devolví el beso. Se sentía desagradable. Todos mis sentidos estaban agudizados, así que podía sentir cada movimiento de su lengua en mi boca."

# game/script.rpy:4742
translate spanish dont_touch_the_water_282d65b8:

    # s hasad "Я не могу полностью довериться тебе, но готов купиться. "
    s hasad "No puedo confiar plenamente en ti, pero estoy dispuesto a creérmelo."

# game/script.rpy:4748
translate spanish dont_touch_the_water_0ac10984:

    # p2 "Он грубо поднял меня и привязал к колонне, после чего поднялся в мою комнату."
    p2 "Me levantó bruscamente y me ató a un pilar, luego subió las escaleras a mi habitación."

# game/script.rpy:4751
translate spanish dont_touch_the_water_02799791:

    # p2 "Он вернулся с моими вещами."
    p2 "Volvió con mis cosas."

# game/script.rpy:4752
translate spanish dont_touch_the_water_9a9702d4:

    # p "Что ты делаешь..?"
    p "¿Qué estás haciendo..?"

# game/script.rpy:4753
translate spanish dont_touch_the_water_f8242cf9:

    # s "Мы уезжаем."
    s "Nos vamos."

# game/script.rpy:4754
translate spanish dont_touch_the_water_2f3074a3:

    # p "Уезжаем!? Куда!?"
    p "¿¡Nos vamos!? ¿¡A dónde!?"

# game/script.rpy:4755
translate spanish dont_touch_the_water_9fa1902d:

    # s "Не знаю, но подальше отсюда."
    s "No lo sé, pero lejos de aquí."

# game/script.rpy:4765
translate spanish dont_touch_the_water_3d584b04:

    # p2 "Он усадил меня в машину, и мы поехали в неизвестном направлении."
    p2 "Me metió en el coche, y nos alejamos en una dirección desconocida."

# game/script.rpy:4770
translate spanish dont_touch_the_water_d6aaf3c8:

    # p2 "Мы какое-то время слонялись по разным местам, пока Сайлас не снял дом на окраине какого-то городка, у леса. "
    p2 "Vagamos de un lugar a otro por un tiempo, hasta que Silas alquiló una casa en las afueras de algún pueblo, cerca del bosque."

# game/script.rpy:4774
translate spanish dont_touch_the_water_bbf78bb7:

    # p2 "Я продолжал[p2_verb_a()] подыгрывать ему, но он все равно держал меня взаперти, пока однажды, спустя полтора года, он не оставил дверь открытой."
    p2 "Seguí siguiéndole el juego, pero aun así me mantenía encerrad[letra], hasta que un día, un año y medio después, dejó la puerta abierta."

# game/script.rpy:4775
translate spanish dont_touch_the_water_3a9eefdf:

    # p2 "Он сказал, что, если я хочу - могу уйти."
    p2 "Dijo que si quería, podía irme."

# game/script.rpy:4776
translate spanish dont_touch_the_water_a174bce1:

    # p2 "Он больше не будет меня держать."
    p2 "Ya no me iba a retener ahí."

# game/script.rpy:4777
translate spanish dont_touch_the_water_036ef4e5:

    # p2 "Дверь была открыта."
    p2 "La puerta estaba abierta."

# game/script.rpy:4778
translate spanish dont_touch_the_water_4517cabc:

    # p2 "Я стоял[p2_verb_a()] и смотрел[p2_verb_a()] на неё долго.{w} Очень долго."
    p2 "Me quedé allí y la miré fijamente durante mucho tiempo.{w} Mucho, mucho tiempo."

# game/script.rpy:4779
translate spanish dont_touch_the_water_63fa1851:

    # p2 "Раньше я мечтал[p2_verb_a()] об этом. Представлял[p2_verb_a()], как выбегу, не оглядываясь."
    p2 "Solía soñar con esto. Me imaginaba corriendo sin mirar atrás."

# game/script.rpy:4780
translate spanish dont_touch_the_water_1d322c7d:

    # p2 "Но теперь…"
    p2 "Pero ahora..."

# game/script.rpy:4781
translate spanish dont_touch_the_water_092d299d:

    # p2 "Куда я пойду?"
    p2 "¿A dónde iría?"

# game/script.rpy:4782
translate spanish dont_touch_the_water_23a903f7:

    # p2 "Я почти забыл[p2_verb_a()], как[p2_verb_oy_im()] был[p2_verb_a()] до него."
    p2 "Casi había olvidado cómo era yo antes de él."

# game/script.rpy:4783
translate spanish dont_touch_the_water_2ba2c8e1:

    # p2 "Он заботился обо мне. Всегда следил, чтобы я ел[p2_verb_a()]. Чтобы не мёрз[p2_verb_la()]. Чтобы мне не было одиноко."
    p2 "Él cuidaba de mí. Siempre se aseguraba de que comiera. De que no pasara frío. De que no estuviera sol[letra]."

# game/script.rpy:4784
translate spanish dont_touch_the_water_6d7bdb5f:

    # p2 "Да, иногда он срывался."
    p2 "Sí, a veces perdía el control."

# game/script.rpy:4785
translate spanish dont_touch_the_water_e3312cd7:

    # p2 "Но я ведь знал[p2_verb_a()], как ему тяжело. Я сам[p2_verb_a()] делал[p2_verb_a()] всё сложнее. Я пугал[p2_verb_a()] его разговорами о прошлом."
    p2 "Pero sabía lo difícil que era para él. Yo era [arti] que hacía todo más difícil. Lo asustaba sacando a relucir el pasado."

# game/script.rpy:4786
translate spanish dont_touch_the_water_6b20f858:

    # p2 "Если бы я просто был[p2_verb_a()] спокойнее… он бы не злился."
    p2 "Si tan solo hubiera estado más tranquil[letra]... no se habría enfadado."

# game/script.rpy:4787
translate spanish dont_touch_the_water_7ae7978d:

    # p2 "Он не плохой. Он просто боится."
    p2 "No es malo. Solo está asustad[letra]."

# game/script.rpy:4788
translate spanish dont_touch_the_water_576b0f3b:

    # p2 "А снаружи никто меня не ждёт."
    p2 "Y afuera, nadie me está esperando."

# game/script.rpy:4792
translate spanish dont_touch_the_water_db986e11:

    # p2 "Я закрыл[p2_verb_a()] дверь сам[p2_verb_a()]."
    p2 "Cerré la puerta yo mism[letra]."

# game/script.rpy:4807
translate spanish dont_touch_the_water_d8c5bf0c:

    # p2 "Я сорвал[p2_verb_as()] с места, но далеко убежать не получилось. Он схватил меня."
    p2 "Salí disparad[letra], pero no llegué lejos. Me atrapó."

# game/script.rpy:4809
translate spanish dont_touch_the_water_a0fd6b75:

    # p2 "Он крепко держал меня, таща куда-то"
    p2 "Me sujetó con fuerza, arrastrándome a algún lugar."

# game/script.rpy:4810
translate spanish dont_touch_the_water_35ae8989:

    # p "Сайлас!? Что ты делаешь!?"
    p "¿¡Silas!? ¿¡Qué estás haciendo!?"

# game/script.rpy:4811
translate spanish dont_touch_the_water_c34a9086:

    # p2 "Он игнорировал меня, продолжая вести за собой. Я пытал[p2_verb_as()] вырваться, упирался ногами в землю, но он продолжал волочить меня за собой."
    p2 "Me ignoró y siguió tirando de mí. Intenté zafarme, clavando los pies en el suelo, pero siguió arrastrándome tras él."

# game/script.rpy:4816
translate spanish dont_touch_the_water_4f308ecf:

    # p2 "Спустя несколько минут мы оказались у того сарая. Теперь я отчетливо его помнил[p2_verb_a()]..."
    p2 "Unos minutos después, estábamos en ese granero. Ahora lo recordaba claramente..."

# game/script.rpy:4817
translate spanish dont_touch_the_water_edffd964:

    # p2 "Он втолкнул меня внутрь."
    p2 "Me empujó hacia adentro."

# game/script.rpy:4824
translate spanish dont_touch_the_water_716f7e8f:

    # s "Ты помнишь это?"
    s "¿Te acuerdas de esto?"

# game/script.rpy:4834
translate spanish dont_touch_the_water_0b25d8e8:

    # s "Вижу, что помнишь..."
    s "Puedo ver que sí..."

# game/script.rpy:4835
translate spanish dont_touch_the_water_83e820eb:

    # s "Я не хотел делать этого тогда... Ты вынудил[p2_verb_a()] меня..."
    s "En ese entonces no quería hacerlo... Me obligaste a..."

# game/script.rpy:4836
translate spanish dont_touch_the_water_c5bd675f:

    # s shcalm3 "Если бы ты не был[p2_verb_a()] так[p2_verb_oy_im()] чертовски упрям[p2_verb_oy_iim()]... У нас все было бы хорошо..."
    s shcalm3 "Si no hubieras sido tan malditamente terc[letra]... Todo habría estado bien entre nosotros..."

# game/script.rpy:4837
translate spanish dont_touch_the_water_13dcf940:

    # s "Ты готов[p2_verb_a()] попробовать снова?"
    s "¿Estás list[letra] para intentarlo de nuevo?"

# game/script.rpy:4838
translate spanish dont_touch_the_water_83e3c734:

    # s shcalm4 "В третий раз..."
    s shcalm4 "Por tercera vez..."

# game/script.rpy:4842
translate spanish dont_touch_the_water_03f8e89c:

    # p2 "Его глаза были полны тихой ярости, от страха я потерял[p2_verb_a()] дар речи."
    p2 "Sus ojos estaban llenos de una ira silenciosa. El miedo me robó la voz."

# game/script.rpy:4845
translate spanish dont_touch_the_water_edd754c5:

    # p2 "Я смог[p2_verb_la()] вымолвить лишь одно слово, надеясь, что он поверит мне, успокоится и я смогу убежать"
    p2 "Solo pude forzar una palabra, esperando que me creyera, se calmara, y pudiera escapar."

# game/script.rpy:4852
translate spanish dont_touch_the_water_80e8b10e:

    # s "Не обманывай нас обоих. "
    s "No nos mientas a ninguno de los dos."

# game/script.rpy:4853
translate spanish dont_touch_the_water_114b40d8:

    # s "Ты никогда бы не полюбил[p2_verb_a()] меня. "
    s "Nunca me habrías amado."

# game/script.rpy:4854
translate spanish dont_touch_the_water_30fcbf06:

    # s "Ты ведь считаешь меня монстром, верно?"
    s "Crees que soy un monstruo, ¿verdad?"

# game/script.rpy:4859
translate spanish dont_touch_the_water_24edefec:

    # p "САЙЛАС, ПОДОЖДИ!!! "
    p "¡¡¡SILAS, ESPERA!!!"

# game/script.rpy:4860
translate spanish dont_touch_the_water_4bfdae7e:

    # p2 "Я вжал[p2_verb_as()] спиной в стену, бежать было некуда."
    p2 "Pegué mi espalda a la pared. No había a dónde huir."

# game/script.rpy:4861
translate spanish dont_touch_the_water_06960751:

    # s "Прости, что не смог вывести тебя на правильный путь."
    s "Siento no haber podido guiarte por el camino correcto."

# game/script.rpy:4862
translate spanish dont_touch_the_water_f6152759:

    # p "САЙ-{nw=0.5}"
    p "SIL-{nw=0.5}"

# game/script.rpy:4880
translate spanish dont_touch_the_water_edbedd1b:

    # p2 "Не знаю почему я ответил[p2_verb_a()] честно. Я не мог[p2_verb_la()] думать здраво, страх сковал не только тело, но и разум."
    p2 "No sé por qué respondí con honestidad. No podía pensar con claridad. El miedo había congelado no solo mi cuerpo, sino también mi mente."

# game/script.rpy:4884
translate spanish dont_touch_the_water_f9a8b4ec:

    # s "Спасибо, что хотя бы чест[p2_verb_na_en()] со мной."
    s "Gracias por al menos ser honest[letra] conmigo."

# game/script.rpy:4911
translate spanish highstats_195dd713:

    # p2 "Прежде, чем он успел это осознать, я побежал[p2_verb_a()] в ванную и замкнул[p2_verb_a()] дверь прямо перед его лицом."
    p2 "Antes de que pudiera darse cuenta de lo que estaba pasando, corrí al baño y cerré la puerta justo delante de su cara."

# game/script.rpy:4913
translate spanish highstats_0106743c:

    # p2 "Я сразу вызвал[p2_verb_a()] полицию, пока он продолжал безжалостно стучать в дверь и кричать на меня."
    p2 "Llamé a la policía de inmediato mientras él seguía golpeando implacablemente la puerta y gritándome."

# game/script.rpy:4914
translate spanish highstats_42bdd148:

    # p2 "Его крики и оскорбления сменялись извинениями и так по кругу."
    p2 "Sus gritos e insultos seguían convirtiéndose en disculpas, y luego volvían una y otra vez."

# game/script.rpy:4915
translate spanish highstats_addc93f2:

    # p2 "Он умолял открыть дверь, обещал, что не причинит мне вред, что даже не прикоснется ко мне, но я не был[p2_verb_a()] настолько глуп[p2_verb_a()], чтобы поверить ему."
    p2 "Me suplicó que abriera la puerta, prometiendo que no me haría daño, que ni siquiera me tocaría, pero no era tan estúpid[letra] como para creerle."

# game/script.rpy:4918
translate spanish highstats_fa62c848:

    # p2 "Сайласу дали всего лишь год заключения. Меня не устроил этот расклад, но суд отказался увеличивать срок, посчитав это простым бытовым нападением, ссорой пары. Думаю, мне повезло, что ему хоть какой-то срок дали. "
    p2 "Silas fue condenado a solo un año de prisión. No estaba satisfech[letra] con ese resultado, pero el tribunal se negó a aumentar la sentencia, tratándolo como una simple agresión doméstica, una pelea de pareja. Supongo que tuve suerte de que cumpliera algún tiempo."

# game/script.rpy:4919
translate spanish highstats_990a23f3:

    # p2 "Я пытал[p2_verb_as()] продолжить свою обычную жизнь, но, когда год подошел к концу, моя тревога снова усилилась. "
    p2 "Intenté volver a mi vida normal, pero cuando el año llegó a su fin, mi ansiedad empeoró de nuevo."

# game/script.rpy:4920
translate spanish highstats_97dc83f1:

    # p2 "Я получил[p2_verb_a()] письмо."
    p2 "Recibí una carta."

# game/script.rpy:4921
translate spanish highstats_95abe26b:

    # p2 "Без адреса отправителя, без какой-либо информации."
    p2 "Sin remitente, sin información en absoluto."

# game/script.rpy:4922
translate spanish highstats_30231949:

    # p2 "Внутри было только фото."
    p2 "Solo había una foto dentro."

# game/script.rpy:4944
translate spanish chicken_ending_3983e01b:

    # p "ЧЕРТОВА КУРИЦА!!!"
    p "¡¡¡MALDITA GALLINA!!!"

# game/script.rpy:4947
translate spanish chicken_ending_66d6fe7c:

    # p2 "Я споткнул[p2_verb_as()] о курицу и сломал[p2_verb_a()] ногу..."
    p2 "Tropecé con una gallina y me rompí la pierna..."

# game/script.rpy:4950
translate spanish chicken_ending_6564cb61:

    # p2 "Пришлось отправиться в больницу, а потом в вернуться в город. Дедушке итак сложно, а тут я как обуза для него..."
    p2 "Tuve que ir al hospital, y luego volver a la ciudad. El abuelo ya tenía suficientes problemas sin que yo fuera una carga también..."

# game/script.rpy:4951
translate spanish chicken_ending_50a9423f:

    # p2 "Он сказал, что ничего страшного, Кайл ему со всем поможет, он просто хотел увидеть меня. Я пообещал[p2_verb_a()] ему приехать следующим летом."
    p2 "Dijo que estaba bien, que Kyle lo ayudaría con todo, y que solo quería verme. Prometí que volvería el próximo verano."

translate spanish strings:

    # game/script.rpy:50
    old "Ной"
    new "Noah"

    # game/script.rpy:53
    old "Дедушка"
    new "Abuelo"

    # game/script.rpy:54
    old "Сайлас"
    new "Silas"

    # game/script.rpy:55
    old "Кайл"
    new "Kyle"

    # game/script.rpy:66
    old "{color=#ffb561}Эта игра предназначена только для лиц старше 18 лет.\nОна содержит сцены насилия, психологические манипуляции и другие материалы взрослого содержания.\nВсе персонажи, события и ситуации являются полностью вымышленными.\nЛюбое сходство с реальными людьми или событиями случайно.{/color}"
    new "{color=#ffb561}Este juego está destinado a adultos mayores de 18 años.\nContiene escenas de violencia, manipulación psicológica y otro contenido maduro.\nTodos los personajes, eventos y situaciones son completamente ficticios.\nCualquier parecido con personas o eventos reales es pura coincidencia.{/color}"

    # game/script.rpy:99
    old "Девушка"
    new "Femenino"

    # game/script.rpy:103
    old "Парень"
    new "Masculino"

    # game/script.rpy:107
    old "Ваше имя..."
    new "Tu nombre..."

    # game/script.rpy:127
    old "Я правда соскучил[p2_verb_as()] по дедушке"
    new "De verdad extrañé al abuelo"

    # game/script.rpy:129
    old "Думаю, еще немного смогу вытерпеть тебя"
    new "Creo que puedo aguantarte un poco más"

    # game/script.rpy:250
    old "У нас были еще друзья?"
    new "¿Teníamos otros amigos?"

    # game/script.rpy:317
    old "Рассказать сон"
    new "Contarle el sueño"

    # game/script.rpy:323
    old "Сказать, что выспал[p2_verb_as()]"
    new "Decir que dormí bien"

    # game/script.rpy:339
    old "Открыть дверь в загон"
    new "Abrir la puerta del corral"

    # game/script.rpy:464
    old "Согласиться"
    new "Aceptar"

    # game/script.rpy:474
    old "Отказаться"
    new "Negarse"

    # game/script.rpy:527
    old "Это было даже мило."
    new "Eso ha sido incluso tierno."

    # game/script.rpy:539
    old "Уверенно согласиться"
    new "Aceptar con confianza"

    # game/script.rpy:554
    old "Не делай так снова."
    new "No lo hagas de nuevo."

    # game/script.rpy:569
    old "Спросить, как я оказал[p2_verb_as()] в реке в тот день."
    new "Preguntar cómo acabé en el río ese día."

    # game/script.rpy:624
    old "Отступить"
    new "Retroceder"

    # game/script.rpy:630
    old "Настоять"
    new "Insistir"

    # game/script.rpy:647
    old "Сменить тему"
    new "Cambiar de tema"

    # game/script.rpy:654
    old "Спросить о чем-то другом."
    new "Preguntar sobre otra cosa."

    # game/script.rpy:657
    old "Какие еще у тебя есть хорошие воспоминания?"
    new "¿Qué otros buenos recuerdos tienes?"

    # game/script.rpy:669
    old "Как думаешь, дедушка поправится?"
    new "¿Crees que el abuelo se recuperará?"

    # game/script.rpy:678
    old "Что ты делал все эти годы?"
    new "¿Qué has hecho todos estos años?"

    # game/script.rpy:724
    old "Посмотреть ближе."
    new "Mirar más de cerca."

    # game/script.rpy:741
    old "Ну это было в детстве, так что все в прошлом"
    new "Bueno, éramos niños, eso ya es cosa del pasado"

    # game/script.rpy:746
    old "Ты живешь в сказках"
    new "Vives en un cuento de hadas"

    # game/script.rpy:754
    old "Ты прав, но тут другая ситуация,\n я ничего не помню"
    new "Tienes razón, pero esto es diferente.\nNo recuerdo nada"

    # game/script.rpy:777
    old "Это мило"
    new "Eso es lindo"

    # game/script.rpy:798
    old "Да, был"
    new "Sí, he tenido"

    # game/script.rpy:807
    old "Соврать(Не было)"
    new "Mentir (No pasó nada)"

    # game/script.rpy:816
    old "Сказать правду(Было)"
    new "Decir la verdad (Sí pasó)"

    # game/script.rpy:828
    old "Нет, не было"
    new "No, no he tenido"

    # game/script.rpy:832
    old "Похоже то лето было хорошим"
    new "Parece que ese verano fue bueno"

    # game/script.rpy:837
    old "Я не помню, что чувствовал[p2_verb_a()] тем летом, но сейчас... \nя начинаю чувствовать что-то к тебе..."
    new "No recuerdo lo que sentí ese verano, pero ahora...\nEstoy empezando a sentir algo por ti..."

    # game/script.rpy:846
    old "Ты для меня едва знакомый, так что прости..."
    new "Apenas te conozco, así que lo siento..."

    # game/script.rpy:863
    old "Звучит слишком романтично для двенадцатилеток"
    new "Suena demasiado romántico para niños de doce años"

    # game/script.rpy:879
    old "Разрядить обстановку"
    new "Aligerar el ambiente"

    # game/script.rpy:896
    old "Жаль, что я этого не помню"
    new "Lástima que no lo recuerde"

    # game/script.rpy:967
    old "Загнать животных"
    new "Meter a los animales"

    # game/script.rpy:975
    old "Собрать яйца"
    new "Recoger los huevos"

    # game/script.rpy:984
    old "Накормить скот"
    new "Dar de comer a los animales"

    # game/script.rpy:992
    old "Больше ничего"
    new "Nada más"

    # game/script.rpy:995
    old "Ничего"
    new "Nada"

    # game/script.rpy:1334
    old "Что-то про меня?"
    new "¿Fue sobre mí?"

    # game/script.rpy:1340
    old "И что именно тебе снилось?"
    new "¿Y qué soñaste exactamente?"

    # game/script.rpy:1342
    old "Это был романтический сон?"
    new "¿Fue un sueño romántico?"

    # game/script.rpy:1355
    old "Что я?"
    new "¿Yo qué?"

    # game/script.rpy:1358
    old "Ты не отпускаешь мысли о поцелуях…"
    new "No puedes dejar de pensar en besos..."

    # game/script.rpy:1368
    old "На облаке было мягко?"
    new "¿La nube era suave?"

    # game/script.rpy:1372
    old "Мои губы?"
    new "¿Mis labios?"

    # game/script.rpy:1385
    old "Там было что-то вкусное?"
    new "¿Había algo delicioso ahí?"

    # game/script.rpy:1488
    old "Выпустить животных"
    new "Soltar a los animales"

    # game/script.rpy:1578
    old "Ладно.."
    new "Vale..."

    # game/script.rpy:1618
    old "Наверное, потому что ты хороший человек."
    new "Probablemente porque eres buena persona."

    # game/script.rpy:1620
    old "Ты просто подкармливаешь их, да?"
    new "Solo es porque los alimentas, ¿no?"

    # game/script.rpy:1776
    old "Принять извинения"
    new "Aceptar sus disculpas"

    # game/script.rpy:1789
    old "Промолчать"
    new "Guardar silencio"

    # game/script.rpy:1993
    old "Ага, не знал[p2_verb_a()], продержусь ли \nеще хоть минуту без тебя."
    new "Sí, no estaba segur[letra] de poder aguantar\nun minuto más sin ti."

    # game/script.rpy:1996
    old "Хоть немного отдохнул[p2_verb_a()] от тебя"
    new "Al menos tuve un pequeño descanso de ti"

    # game/script.rpy:2089
    old "Ничего не делать"
    new "No hacer nada"

    # game/script.rpy:2098
    old "Ответить на поцелуй"
    new "Devolverle el beso"

    # game/script.rpy:2117
    old "Позволить продолжать"
    new "Dejar que continúe"

    # game/script.rpy:2125
    old "Остановить его"
    new "Detenerlo"

    # game/script.rpy:2159
    old "Поцеловать его"
    new "Besarlo"

    # game/script.rpy:2194
    old "Отстраниться"
    new "Apartarse"

    # game/script.rpy:2252
    old "Погладить его по голове"
    new "Acariciarle la cabeza"

    # game/script.rpy:2295
    old "Закрыть ему нос рукой"
    new "Taparle la nariz con la mano"

    # game/script.rpy:2351
    old "Ничего не делать."
    new "No hacer nada."

    # game/script.rpy:2568
    old "Потрогать"
    new "Tocarla"

    # game/script.rpy:2592
    old "Идти в воду"
    new "Meterse en el agua"

    # game/script.rpy:2595
    old "Не идти в воду"
    new "No meterse en el agua"

    # game/script.rpy:2702
    old "Чувствую"
    new "Sí, creo que sí"

    # game/script.rpy:2708
    old "Не чувствую"
    new "No, la verdad no"

    # game/script.rpy:2847
    old "Да, тебе лучше пойти к себе."
    new "Sí, creo que deberías irte."

    # game/script.rpy:2877
    old "Убедить его остаться"
    new "Convencerlo de quedarse"

    # game/script.rpy:3165
    old "Бить"
    new "Golpearlo"

    # game/script.rpy:3313
    old "Взять его за руку"
    new "Tomar su mano"

    # game/script.rpy:3330
    old "Не брать"
    new "No tomarla"

    # game/script.rpy:3361
    old "Сделать комплимент его образу"
    new "Elogiar su atuendo"

    # game/script.rpy:3370
    old "Спросить, что он думает о приговоре"
    new "Preguntarle qué piensa de la sentencia"

    # game/script.rpy:3437
    old "Поблагодарить за все"
    new "Agradecerle por todo"

    # game/script.rpy:3457
    old "{color=#00c407}Ты обещал[p2_verb_a()] вернуться{/color}"
    new "{color=#00c407}Prometiste volver{/color}"

    # game/script.rpy:3467
    old "{size=80}{color=#ffffff}Лето подходило к концу...{/color}{/size}"
    new "{size=80}{color=#ffffff}El verano llegaba a su fin...{/color}{/size}"

    # game/script.rpy:3488
    old "Отказаться, сказать, что знаешь всю правду."
    new "Rechazar y decir que sabes toda la verdad."

    # game/script.rpy:3491
    old "Согласиться."
    new "Aceptar."

    # game/script.rpy:3514
    old "{size=80}{color=#ffffff}Полгода пронеслись незаметно...{/color}{/size}"
    new "{size=80}{color=#ffffff}Medio año pasó en un parpadeo...{/color}{/size}"

    # game/script.rpy:3556
    old "{color=#00c407}Он отпустил тебя.{/color}"
    new "{color=#00c407}Te dejó ir.{/color}"

    # game/script.rpy:3600
    old "{sc=2.0}Он перестал надеяться{/sc}"
    new "{sc=2.0}Dejó de esperar{/sc}"

    # game/script.rpy:3693
    old "{sc=2.0}Ты сделал[p2_verb_a()] выбор{/sc}"
    new "{sc=2.0}Tomaste tu decisión{/sc}"

    # game/script.rpy:3709
    old "Сказать, что приснился кошмар"
    new "Decir que tuviste una pesadilla"

    # game/script.rpy:3718
    old "Продолжать лежать"
    new "Seguir acostad[letra] ahí"

    # game/script.rpy:3721
    old "Попытаться уйти"
    new "Intentar irme"

    # game/script.rpy:3725
    old "Спросить про сарай"
    new "Preguntar sobre el granero"

    # game/script.rpy:3852
    old "{sc=2.0}Он оказался быстрее{/sc}"
    new "{sc=2.0}Él fue más rápido{/sc}"

    # game/script.rpy:3967
    old "Нет!!"
    new "¡¡No!!"

    # game/script.rpy:4011
    old "{sc=2.0}Он смог забрать твою свободу{/sc}"
    new "{sc=2.0}Logró quitarte tu libertad{/sc}"

    # game/script.rpy:4016
    old "..."
    new "..."

    # game/script.rpy:4077
    old "{color=#f80}Ты стал[p2_verb_a()] заложником чувства вины{/color}"
    new "{color=#f80}Te convertiste en rehén de tu culpa{/color}"

    # game/script.rpy:4162
    old "{sc=2.0}Дорога помнила тебя, а ты ее - нет{/sc}"
    new "{sc=2.0}El camino te recordaba, pero tú no lo recordabas{/sc}"

    # game/script.rpy:4202
    old "{sc=2.0}Вода не отпускает{/sc}"
    new "{sc=2.0}El agua no te suelta{/sc}"

    # game/script.rpy:4226
    old "{color=#f80}Ты все еще чувствуешь его{/color}"
    new "{color=#f80}Todavía puedes sentirlo{/color}"

    # game/script.rpy:4230
    old "{size=80}{color=#ffffff}Продожение следует...{/color}{/size}"
    new "{size=80}{color=#ffffff}Continuará...{/color}{/size}"

    # game/script.rpy:4259
    old "{sc=2.0}Ты долж[p2_verb_na_en()] был[p2_verb_a()] быть храбрее{/sc}"
    new "{sc=2.0}Deberías haber sido más valiente{/sc}"

    # game/script.rpy:4367
    old "Спросить об этом"
    new "Preguntar sobre eso"

    # game/script.rpy:4399
    old "Может и так..."
    new "Puede que sea así..."

    # game/script.rpy:4491
    old "Я не жалел[p2_verb_a()] о том, что он поехал со мной.\n Я влюблял[p2_verb_as()] в него все сильнее с каждым днем.\n Он был так заботлив и внимателен к мелочам..."
    new "No me arrepentí de dejarlo venir conmigo.\n Me enamoraba de él más y más con cada día que pasaba.\n Era tan cariñoso, tan atento a cada pequeño detalle..."

    # game/script.rpy:4496
    old "Слишком внимательным... "
    new "Demasiado atento..."

    # game/script.rpy:4500
    old "Он замечал даже то, чего не было..."
    new "Incluso notaba cosas que no estaban ahí..."

    # game/script.rpy:4521
    old "{sc=2.0}Твое место было не рядом с ним{/sc}"
    new "{sc=2.0}Tu lugar nunca estuvo a su lado{/sc}"

    # game/script.rpy:4526
    old "А вдруг это ты все перепутал?"
    new "¿Y si eres tú [arti] que lo entendió todo mal?"

    # game/script.rpy:4538
    old "Что произошло тем летом?"
    new "¿Qué pasó aquel verano?"

    # game/script.rpy:4542
    old "ЧТО ПРОИЗОШЛО!?"
    new "¿¡QUÉ PASÓ!?"

    # game/script.rpy:4567
    old "{move}бежать{/move}"
    new "{move}correr{/move}"

    # game/script.rpy:4571
    old "БЕЖАТЬ"
    new "CORRER"

    # game/script.rpy:4575
    old "{sc=2.}БЕЖАТЬ{/sc}"
    new "{sc=2.}CORRER{/sc}"

    # game/script.rpy:4593
    old "Пнуть ногой"
    new "Patearlo"

    # game/script.rpy:4626
    old "{sc=2.0}Ты был[p2_verb_a()] недостаточно сил[p2_verb_llna_len()].{/sc}"
    new "{sc=2.0}No eras lo suficientemente fuerte.{/sc}"

    # game/script.rpy:4639
    old "Попытаться высвободить руки"
    new "Intentar liberar tus manos"

    # game/script.rpy:4684
    old "{color=#f80}Клетка действительно оказалась золотой.{/color}"
    new "{color=#f80}La jaula realmente era dorada.{/color}"

    # game/script.rpy:4692
    old "Подыграть"
    new "Seguirle el juego"

    # game/script.rpy:4721
    old "{sc=2.}Ты не был[p2_verb_a()] достаточно убедител[p2_verb_na_en()].{/sc}"
    new "{sc=2.}No fuiste lo suficientemente convincente.{/sc}"

    # game/script.rpy:4798
    old "{color=#f80}Ты был[p2_verb_a()] т[p2_verb_oy_em()], кто закрыл[p2_verb_a()] дверь.{/color}"
    new "{color=#f80}Fuiste tú quien cerró la puerta.{/color}"

    # game/script.rpy:4844
    old "Да..."
    new "Sí..."

    # game/script.rpy:4873
    old "{sc=2.0}Он больше не верит.{/sc}"
    new "{sc=2.0}Él ya no cree.{/sc}"

    # game/script.rpy:4879
    old "Нет..."
    new "No..."

    # game/script.rpy:4902
    old "{sc=2.0}Правда не всегда спасает.{/sc}"
    new "{sc=2.0}La verdad no siempre te salva.{/sc}"

    # game/script.rpy:4933
    old "{color=#f80}Ты всегда будешь помнить.{/color}"
    new "{color=#f80}Siempre lo recordarás.{/color}"

    # game/script.rpy:4959
    old "{color=#00c407}Может все к лучшему?{/color}"
    new "{color=#00c407}¿Quizás fue para bien?{/color}"
    
    old "master"
    new "patrón"
    
    old "mistress"
    new "patrona"

