﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/eggs_minigame.rpy:829
    old "Завершить"
    new "Finalizar"

