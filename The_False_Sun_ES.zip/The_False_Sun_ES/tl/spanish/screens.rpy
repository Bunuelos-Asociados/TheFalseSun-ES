﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/screens.rpy:360
    old "Начать"
    new "> Iniciar"

    # game/screens.rpy:364
    old "> История"
    new "> Historial"

    # game/screens.rpy:366
    old "> Сохранить"
    new "> Guardar"

    # game/screens.rpy:368
    old "> Загрузить"
    new "> Cargar"

    # game/screens.rpy:370
    old "> Настройки"
    new "> Ajustes"

    # game/screens.rpy:374
    old "> Галерея\nвоспоминаний"
    new "> Galería\nde recuerdos"
    
    old "> Галерея концовок"
    new "> Galería\nde finales"

    # game/screens.rpy:378
    old "> Завершить повтор"
    new "> Finalizar repetición"

    # game/screens.rpy:382
    old "> Главное меню"
    new "> Menú principal"

    # game/screens.rpy:384
    old "> Об игре"
    new "> Acerca de"

    # game/screens.rpy:395
    old "> Выход"
    new "> Salir"

    # game/screens.rpy:549
    old "Вернуться"
    new "Volver"

    # game/screens.rpy:625
    old "Об игре"
    new "Acerca de"

    # game/screens.rpy:632
    old "Версия [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:638
    old "Сделано с помощью {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:641
    old "Мои соцсети:"
    new "Mis redes sociales:"

    # game/screens.rpy:667
    old "Сохранить"
    new "Guardar"

    # game/screens.rpy:674
    old "Загрузить"
    new "Cargar"

    # game/screens.rpy:679
    old "{} страница"
    new "Página {}"

    # game/screens.rpy:679
    old "Авто-\nсохранения"
    new "Guardados\nautomáticos"

    # game/screens.rpy:679
    old "Быстрые\nсохранения"
    new "Guardados\nrápidos"

    # game/screens.rpy:738
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:738
    old "Пустой слот"
    new "Ranura vacía"

    # game/screens.rpy:756
    old "<"
    new "<"

    # game/screens.rpy:760
    old "{#auto_page}А"
    new "{#auto_page}A"

    # game/screens.rpy:763
    old "{#quick_page}Б"
    new "{#quick_page}Q"

    # game/screens.rpy:768
    old ">"
    new ">"

    # game/screens.rpy:815
    old "Настройки"
    new "Ajustes"

    # game/screens.rpy:826
    old "Режим экрана"
    new "Pantalla"

    # game/screens.rpy:827
    old "Оконный"
    new "Ventana"

    # game/screens.rpy:828
    old "Полный"
    new "Pantalla completa"

    # game/screens.rpy:832
    old "Пропуск"
    new "Saltar"

    # game/screens.rpy:833
    old "Всего текста"
    new "Todo el texto"

    # game/screens.rpy:834
    old "После выборов"
    new "Después de las opciones"

    # game/screens.rpy:835
    old "Переходов"
    new "Transiciones"

    # game/screens.rpy:841
    old "Язык"
    new "Idioma"

    # game/screens.rpy:843
    old "Русский"
    new "Русский"

    # game/screens.rpy:844
    old "English"
    new "English"

    # game/screens.rpy:853
    old "Скорость текста"
    new "Velocidad del texto"

    # game/screens.rpy:857
    old "Скорость авточтения"
    new "Velocidad de avance automático"

    # game/screens.rpy:864
    old "Громкость музыки"
    new "Volumen de la música"

    # game/screens.rpy:871
    old "Громкость звуков"
    new "Volumen de los efectos"

    # game/screens.rpy:877
    old "Тест"
    new "Probar"

    # game/screens.rpy:893
    old "Без звука"
    new "Silenciar"

    # game/screens.rpy:984
    old "История"
    new "Historial"

    # game/screens.rpy:1013
    old "История диалогов пуста."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1072
    old "Помощь"
    new "Ayuda"

    # game/screens.rpy:1081
    old "Клавиатура"
    new "Teclado"

    # game/screens.rpy:1082
    old "Мышь"
    new "Ratón"

    # game/screens.rpy:1085
    old "Геймпад"
    new "Mando"

    # game/screens.rpy:1098
    old "Enter"
    new "Intro"

    # game/screens.rpy:1099
    old "Прохождение диалогов, активация интерфейса."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1102
    old "Пробел"
    new "Espacio"

    # game/screens.rpy:1103
    old "Прохождение диалогов без возможности делать выбор."
    new "Avanza el diálogo sin tomar decisiones."

    # game/screens.rpy:1106
    old "Стрелки"
    new "Flechas"

    # game/screens.rpy:1107
    old "Навигация по интерфейсу."
    new "Navega por la interfaz."

    # game/screens.rpy:1110
    old "Esc"
    new "Esc"

    # game/screens.rpy:1111
    old "Вход в игровое меню."
    new "Abre el menú del juego."

    # game/screens.rpy:1114
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1115
    old "Пропускает диалоги, пока зажат."
    new "Salta el diálogo mientras se mantiene pulsado."

    # game/screens.rpy:1118
    old "Tab"
    new "Tab"

    # game/screens.rpy:1119
    old "Включает режим пропуска."
    new "Activa/desactiva el modo de salto."

    # game/screens.rpy:1122
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1123
    old "Откат назад по сюжету игры."
    new "Retrocede a un punto anterior del juego."

    # game/screens.rpy:1126
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1127
    old "Откатывает предыдущее действие вперёд."
    new "Avanza a un punto posterior."

    # game/screens.rpy:1131
    old "Скрывает интерфейс пользователя."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1135
    old "Делает снимок экрана."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1139
    old "Включает поддерживаемый {a=https://www.renpy.org/l/voicing}синтезатор речи{/a}."
    new "Activa la {a=https://www.renpy.org/l/voicing}lectura en voz alta{/a} compatible."

    # game/screens.rpy:1143
    old "Открывает меню специальных возможностей."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1149
    old "Левый клик"
    new "Clic izquierdo"

    # game/screens.rpy:1153
    old "Клик колёсиком"
    new "Clic central"

    # game/screens.rpy:1157
    old "Правый клик"
    new "Clic derecho"

    # game/screens.rpy:1161
    old "Колёсико вверх"
    new "Rueda del ratón arriba"

    # game/screens.rpy:1165
    old "Колёсико вниз"
    new "Rueda del ratón abajo"

    # game/screens.rpy:1172
    old "Правый триггер\nA/Нижняя кнопка"
    new "Gatillo derecho\nBotón inferior/A"

    # game/screens.rpy:1176
    old "Левый Триггер\nЛевый Бампер"
    new "Gatillo izquierdo\nParachoques izquierdo"

    # game/screens.rpy:1180
    old "Правый бампер"
    new "Parachoques derecho"

    # game/screens.rpy:1184
    old "Крестовина, Стики"
    new "Cruceta, palancas"

    # game/screens.rpy:1188
    old "Старт, Гид, B/Правая кнопка"
    new "Inicio, Guía, Botón derecho/B"

    # game/screens.rpy:1192
    old "Y/Верхняя кнопка"
    new "Botón superior/Y"

    # game/screens.rpy:1195
    old "Калибровка"
    new "Calibración"

    # game/screens.rpy:1260
    old "Да"
    new "Sí"

    # game/screens.rpy:1261
    old "Нет"
    new "No"

    # game/screens.rpy:1307
    old "Пропускаю"
    new "Saltando"

