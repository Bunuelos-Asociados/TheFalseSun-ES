﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/options.rpy:15
    old "The False Sun"
    new "The False Sun"

