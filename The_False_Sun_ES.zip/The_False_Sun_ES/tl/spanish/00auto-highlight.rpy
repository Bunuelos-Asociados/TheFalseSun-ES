﻿# TODO: Translation updated at 2026-06-25 20:17

# game/00auto-highlight.rpy:1
translate spanish c7b781ae:

    # "Auto Highlight Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Auto Highlight Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/00auto-highlight.rpy:2
translate spanish 176f8240:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Auto-Highlight itch.io: https://wattson.itch.io/renpy-auto-highlight"
    "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Auto-Highlight itch.io: https://wattson.itch.io/renpy-auto-highlight"

# game/00auto-highlight.rpy:31
translate spanish f3e37507:

    # "Setup (IMPORTANT)"
    "Setup (IMPORTANT)"

# game/00auto-highlight.rpy:58
translate spanish 15d02f4f:

    # "General Note"
    "General Note"

# game/00auto-highlight.rpy:64
translate spanish 2fad2a99:

    # "Variables"
    "Variables"

# game/00auto-highlight.rpy:81
translate spanish b9327469:

    # "Transforms"
    "Transforms"

