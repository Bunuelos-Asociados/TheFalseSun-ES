﻿# TODO: Translation updated at 2026-06-25 20:17

translate spanish strings:

    # game/cream_minigame.rpy:163
    old "Сначала сливки."
    new "Primero la crema."

    # game/cream_minigame.rpy:182
    old "Сейчас сахар."
    new "Ahora el azúcar."

