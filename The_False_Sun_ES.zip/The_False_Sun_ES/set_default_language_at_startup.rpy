init python:
    
    def actualizar_genero():
        
     global pronombre, letra, arti, arti_2, sleepyhead, arti_2_ma, letra_ma

     if persistent.player_gender == "female":
         pronombre = "Ella"
         letra     = "a"
         letra_ma  = "A"
         arti      = "la"
         arti_2    = "una"
         arti_2_ma  = "UNA"
         sleepyhead = "dormilona"

     else:  # male
         pronombre = "Él"
         letra     = "o"
         letra_ma  = "O"
         arti      = "el"
         arti_2    = "un"
         arti_2_ma = "UN"
         sleepyhead = "dormilón"

init 1000 python:
    renpy.game.preferences.language = "spanish"
    
label before_main_menu:
    $ actualizar_genero()
    return    

label after_load:
    $ actualizar_genero()
    return